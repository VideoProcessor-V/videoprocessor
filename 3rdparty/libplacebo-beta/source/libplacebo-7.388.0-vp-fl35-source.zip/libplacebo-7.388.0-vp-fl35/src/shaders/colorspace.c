/*
 * This file is part of libplacebo.
 *
 * libplacebo is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * libplacebo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with libplacebo. If not, see <http://www.gnu.org/licenses/>.
 */

#include <math.h>

#include "cache.h"
#include "colorspace.h"
#include "shaders.h"

#include <libplacebo/shaders/colorspace.h>

void pl_shader_set_alpha(pl_shader sh, struct pl_color_repr *repr,
                         enum pl_alpha_mode mode)
{
    bool src_has_alpha = repr->alpha == PL_ALPHA_INDEPENDENT ||
                         repr->alpha == PL_ALPHA_PREMULTIPLIED;
    bool dst_not_premul = mode == PL_ALPHA_INDEPENDENT ||
                          mode == PL_ALPHA_NONE;

    if (repr->alpha == PL_ALPHA_PREMULTIPLIED && dst_not_premul) {
        GLSL("if (color.a > 1e-6)               \n"
             "    color.rgb /= vec3(color.a);   \n");
        repr->alpha = PL_ALPHA_INDEPENDENT;
    }

    if (repr->alpha == PL_ALPHA_INDEPENDENT && mode == PL_ALPHA_PREMULTIPLIED) {
        GLSL("color.rgb *= vec3(color.a); \n");
        repr->alpha = PL_ALPHA_PREMULTIPLIED;
    }

    if (src_has_alpha && mode == PL_ALPHA_NONE) {
        GLSL("color.a = 1.0; \n");
        repr->alpha = PL_ALPHA_NONE;
    }
}

#ifdef PL_HAVE_DOVI
static inline void reshape_mmr(pl_shader sh, ident_t mmr, bool single,
                               int min_order, int max_order)
{
    if (single) {
        GLSL("const int mmr_idx = 0; \n");
    } else {
        GLSL("int mmr_idx = int(coeffs.y); \n");
    }

    assert(min_order <= max_order);
    if (min_order < max_order)
        GLSL("int order = int(coeffs.w); \n");

    GLSL("vec4 sigX;                            \n"
         "s = coeffs.x;                         \n"
         "sigX.xyz = sig.xxy * sig.yzz;         \n"
         "sigX.w = sigX.x * sig.z;              \n"
         "s += dot("$"[mmr_idx + 0].xyz, sig);  \n"
         "s += dot("$"[mmr_idx + 1], sigX);     \n",
         mmr, mmr);

    if (max_order >= 2) {
        if (min_order < 2)
            GLSL("if (order >= 2) { \n");

        GLSL("vec3 sig2 = sig * sig;                \n"
             "vec4 sigX2 = sigX * sigX;             \n"
             "s += dot("$"[mmr_idx + 2].xyz, sig2); \n"
             "s += dot("$"[mmr_idx + 3], sigX2);    \n",
             mmr, mmr);

        if (max_order == 3) {
            if (min_order < 3)
                GLSL("if (order >= 3) { \n");

            GLSL("s += dot("$"[mmr_idx + 4].xyz, sig2 * sig);   \n"
                 "s += dot("$"[mmr_idx + 5], sigX2 * sigX);     \n",
                 mmr, mmr);

            if (min_order < 3)
                GLSL("} \n");
        }

        if (min_order < 2)
            GLSL("} \n");
    }
}

static inline void reshape_poly(pl_shader sh)
{
    GLSL("s = (coeffs.z * s + coeffs.y) * s + coeffs.x; \n");
}
#endif

void sh_dovi_compose_nlq(pl_shader sh, const struct pl_dovi_metadata *data,
                         ident_t el_signal)
{
#ifdef PL_HAVE_DOVI
    if (!data || !data->nlq_active)
        return;

    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    float offset[3], slope[3], threshold[3], hdr_max[3];
    for (int c = 0; c < 3; c++) {
        offset[c] = data->nlq[c].offset;
        slope[c] = data->nlq[c].deadzone_slope;
        threshold[c] = data->nlq[c].deadzone_threshold;
        hdr_max[c] = data->nlq[c].hdr_in_max;
    }

    ident_t off = sh_var(sh, (struct pl_shader_var) {
        .var  = pl_var_vec3("nlq_offset"),
        .data = offset,
    });
    ident_t slp = sh_var(sh, (struct pl_shader_var) {
        .var  = pl_var_vec3("nlq_slope"),
        .data = slope,
    });
    ident_t thr = sh_var(sh, (struct pl_shader_var) {
        .var  = pl_var_vec3("nlq_threshold"),
        .data = threshold,
    });
    ident_t mx = sh_var(sh, (struct pl_shader_var) {
        .var  = pl_var_vec3("nlq_max"),
        .data = hdr_max,
    });

    // LINEAR_DZ dequantization of the EL codes, rounded to integers after
    // the resampling: rr = 0 gives no residual, otherwise
    //   residual = sign(rr) * ((|rr| - 0.5) * slope + threshold)
    // bounded by hdr_in_max
#pragma GLSL /* sh_dovi_compose_nlq */                                  \
    {                                                                   \
    vec3 rr = round($el_signal().rgb - $off);                           \
    vec3 res = sign(rr) * ((abs(rr) - 0.5) * $slp + $thr);              \
    color.rgb += clamp(res, -$mx, $mx);                                 \
    color.rgb = clamp(color.rgb, 0.0, 1.0);                             \
    }
#endif
}

void pl_shader_dovi_reshape(pl_shader sh, const struct pl_dovi_metadata *data)
{
#ifdef PL_HAVE_DOVI
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0) || !data)
        return;

    // Clamp every component to its own pivot range, also for the components
    // that the MMR mapping of another component reads
    float lo[3] = {0.0, 0.0, 0.0}, hi[3] = {1.0, 1.0, 1.0};
    for (int c = 0; c < 3; c++) {
        const struct pl_reshape_data *comp = &data->comp[c];
        if (comp->num_pivots) {
            lo[c] = comp->pivots[0];
            hi[c] = comp->pivots[comp->num_pivots - 1];
        }
    }

    sh_describe(sh, "reshaping");
    GLSL("// pl_shader_reshape                  \n"
         "{                                     \n"
         "vec3 sig;                             \n"
         "vec4 coeffs;                          \n"
         "float s;                              \n"
         "sig = clamp(color.rgb, "$", "$");     \n",
         sh_var(sh, (struct pl_shader_var) {
             .var  = pl_var_vec3("pivot_lo"),
             .data = lo,
         }),
         sh_var(sh, (struct pl_shader_var) {
             .var  = pl_var_vec3("pivot_hi"),
             .data = hi,
         }));

    float coeffs_data[8][4];
    float mmr_packed_data[8*6][4];

    for (int c = 0; c < 3; c++) {
        const struct pl_reshape_data *comp = &data->comp[c];
        if (!comp->num_pivots)
            continue;

        pl_assert(comp->num_pivots >= 2 && comp->num_pivots <= 9);
        GLSL("s = sig[%d]; \n", c);

        // Prepare coefficients for GPU
        bool has_poly = false, has_mmr = false, mmr_single = true;
        int mmr_idx = 0, min_order = 3, max_order = 1;
        memset(coeffs_data, 0, sizeof(coeffs_data));
        for (int i = 0; i < comp->num_pivots - 1; i++) {
            switch (comp->method[i]) {
            case 0: // polynomial
                has_poly = true;
                coeffs_data[i][3] = 0.0; // order=0 signals polynomial
                for (int k = 0; k < 3; k++)
                    coeffs_data[i][k] = comp->poly_coeffs[i][k];
                break;

            case 1:
                min_order = PL_MIN(min_order, comp->mmr_order[i]);
                max_order = PL_MAX(max_order, comp->mmr_order[i]);
                mmr_single = !has_mmr;
                has_mmr = true;
                coeffs_data[i][3] = (float) comp->mmr_order[i];
                coeffs_data[i][0] = comp->mmr_constant[i];
                coeffs_data[i][1] = (float) mmr_idx;
                for (int j = 0; j < comp->mmr_order[i]; j++) {
                    // store weights per order as two packed vec4s
                    float *mmr = &mmr_packed_data[mmr_idx][0];
                    mmr[0] = comp->mmr_coeffs[i][j][0];
                    mmr[1] = comp->mmr_coeffs[i][j][1];
                    mmr[2] = comp->mmr_coeffs[i][j][2];
                    mmr[3] = 0.0; // unused
                    mmr[4] = comp->mmr_coeffs[i][j][3];
                    mmr[5] = comp->mmr_coeffs[i][j][4];
                    mmr[6] = comp->mmr_coeffs[i][j][5];
                    mmr[7] = comp->mmr_coeffs[i][j][6];
                    mmr_idx += 2;
                }
                break;

            default:
                pl_unreachable();
            }
        }

        if (comp->num_pivots > 2) {

            // Skip the (irrelevant) lower and upper bounds
            float pivots_data[7];
            memcpy(pivots_data, comp->pivots + 1,
                   (comp->num_pivots - 2) * sizeof(pivots_data[0]));

            // Fill the remainder with a quasi-infinite sentinel pivot
            for (int i = comp->num_pivots - 2; i < PL_ARRAY_SIZE(pivots_data); i++)
                pivots_data[i] = 1e9f;

            ident_t pivots = sh_var(sh, (struct pl_shader_var) {
                .data = pivots_data,
                .var = {
                    .name = "pivots",
                    .type = PL_VAR_FLOAT,
                    .dim_v = 1,
                    .dim_m = 1,
                    .dim_a = PL_ARRAY_SIZE(pivots_data),
                },
            });

            ident_t coeffs = sh_var(sh, (struct pl_shader_var) {
                .data = coeffs_data,
                .var = {
                    .name = "coeffs",
                    .type = PL_VAR_FLOAT,
                    .dim_v = 4,
                    .dim_m = 1,
                    .dim_a = PL_ARRAY_SIZE(coeffs_data),
                },
            });

            // Efficiently branch into the correct set of coefficients
            GLSL("#define test(i) bvec4(s >= "$"[i])                \n"
                 "#define coef(i) "$"[i]                            \n"
                 "coeffs = mix(mix(mix(coef(0), coef(1), test(0)),  \n"
                 "                 mix(coef(2), coef(3), test(2)),  \n"
                 "                 test(1)),                        \n"
                 "             mix(mix(coef(4), coef(5), test(4)),  \n"
                 "                 mix(coef(6), coef(7), test(6)),  \n"
                 "                 test(5)),                        \n"
                 "             test(3));                            \n"
                 "#undef test                                       \n"
                 "#undef coef                                       \n",
                 pivots, coeffs);

        } else {

            // No need for a single pivot, just set the coeffs directly
            GLSL("coeffs = "$"; \n", sh_var(sh, (struct pl_shader_var) {
                .var = pl_var_vec4("coeffs"),
                .data = coeffs_data,
            }));

        }

        ident_t mmr = NULL_IDENT;
        if (has_mmr) {
            mmr = sh_var(sh, (struct pl_shader_var) {
                .data = mmr_packed_data,
                .var = {
                    .name = "mmr",
                    .type = PL_VAR_FLOAT,
                    .dim_v = 4,
                    .dim_m = 1,
                    .dim_a = mmr_idx,
                },
            });
        }

        if (has_mmr && has_poly) {
            GLSL("if (coeffs.w == 0.0) { \n");
            reshape_poly(sh);
            GLSL("} else { \n");
            reshape_mmr(sh, mmr, mmr_single, min_order, max_order);
            GLSL("} \n");
        } else if (has_poly) {
            reshape_poly(sh);
        } else {
            assert(has_mmr);
            GLSL("{ \n");
            reshape_mmr(sh, mmr, mmr_single, min_order, max_order);
            GLSL("} \n");
        }

        GLSL("color[%d] = clamp(s, 0.0, 1.0); \n", c);
    }

    GLSL("} \n");
#else
    SH_FAIL(sh, "libplacebo was compiled without support for dolbyvision reshaping");
#endif
}

void pl_shader_decode_color_ex(pl_shader sh,
                               const struct pl_color_decode_args *args)
{
    struct pl_color_repr *repr = args->repr;
    const struct pl_color_adjustment *params = args->color_adjustment;

    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    sh_describe(sh, "color decoding");
    GLSL("// pl_shader_decode_color \n"
         "{ \n");

    if (repr->sys == PL_COLOR_SYSTEM_DOLBYVISION) {
        // The reshaping maps the sample code divided by 2^BL_bit_depth
        int depth;
        float scale = pl_color_repr_code_scale(repr, &depth);
        scale = ldexpf(scale, -depth);
        GLSL("color.rgb *= vec3("$"); \n", SH_FLOAT(scale));
    }

    if (repr->sys == PL_COLOR_SYSTEM_DOLBYVISION)
        pl_shader_dovi_reshape(sh, repr->dovi);

    // Dolby Vision FEL composition
    if (args->enhancement_layer && repr->sys == PL_COLOR_SYSTEM_DOLBYVISION &&
        repr->dovi && repr->dovi->nlq_active)
    {
        ident_t el = sh_subpass(sh, args->enhancement_layer);
        if (!el) {
            SH_FAIL(sh, "Failed merging the enhancement layer shader");
            return;
        }
        sh_dovi_compose_nlq(sh, repr->dovi, el);
    }

    enum pl_color_system orig_sys = repr->sys;
    pl_transform3x3 tr = pl_color_repr_decode_ex(repr, pl_color_repr_decode_params(
        .adjustment = params,
        .primaries  = args->primaries,
    ));

    if (memcmp(&tr, &pl_transform3x3_identity, sizeof(tr))) {
        ident_t cmat = sh_var(sh, (struct pl_shader_var) {
            .var  = pl_var_mat3("cmat"),
            .data = PL_TRANSPOSE_3X3(tr.mat.m),
        });

        ident_t cmat_c = sh_var(sh, (struct pl_shader_var) {
            .var  = pl_var_vec3("cmat_c"),
            .data = tr.c,
        });

        GLSL("color.rgb = "$" * color.rgb + "$"; \n", cmat, cmat_c);
    }

    switch (orig_sys) {
    case PL_COLOR_SYSTEM_BT_2020_C:
        // Conversion for C'rcY'cC'bc via the BT.2020 CL system:
        // C'bc = (B'-Y'c) / 1.9404  | C'bc <= 0
        //      = (B'-Y'c) / 1.5816  | C'bc >  0
        //
        // C'rc = (R'-Y'c) / 1.7184  | C'rc <= 0
        //      = (R'-Y'c) / 0.9936  | C'rc >  0
        //
        // as per the BT.2020 specification, table 4. This is a non-linear
        // transformation because (constant) luminance receives non-equal
        // contributions from the three different channels.
        GLSL("// constant luminance conversion                              \n"
             "color.br = color.br * mix(vec2(1.5816, 0.9936),               \n"
             "                          vec2(1.9404, 1.7184),               \n"
             "                          lessThanEqual(color.br, vec2(0.0))) \n"
             "           + color.gg;                                        \n");
        // Expand channels to camera-linear light. This shader currently just
        // assumes everything uses the BT.2020 12-bit gamma function, since the
        // difference between 10 and 12-bit is negligible for anything other
        // than 12-bit content.
        GLSL("vec3 lin = mix(color.rgb * vec3(1.0/4.5),                        \n"
             "                pow((color.rgb + vec3(0.0993))*vec3(1.0/1.0993), \n"
             "                    vec3(1.0/0.45)),                             \n"
             "                lessThanEqual(vec3(0.08145), color.rgb));        \n");
        // Calculate the green channel from the expanded RYcB, and recompress to G'
        // The BT.2020 specification says Yc = 0.2627*R + 0.6780*G + 0.0593*B
        GLSL("color.g = (lin.g - 0.2627*lin.r - 0.0593*lin.b)*1.0/0.6780;   \n"
             "color.g = mix(color.g * 4.5,                                  \n"
             "              1.0993 * pow(color.g, 0.45) - 0.0993,           \n"
             "              0.0181 <= color.g);                             \n");
        break;

    case PL_COLOR_SYSTEM_BT_2100_PQ:;
        // Conversion process from the spec:
        //
        // 1. L'M'S' = cmat * ICtCp
        // 2. LMS = linearize(L'M'S')  (EOTF for PQ, inverse OETF for HLG)
        // 3. RGB = lms2rgb * LMS
        //
        // After this we need to invert step 2 to arrive at non-linear RGB.
        // (It's important we keep the transfer function conversion separate
        // from the color system decoding, so we have to partially undo our
        // work here even though we will end up linearizing later on anyway)

        GLSL(// PQ EOTF
             "color.rgb = pow(max(color.rgb, 0.0), vec3(1.0/%f));           \n"
             "color.rgb = max(color.rgb - vec3(%f), 0.0)                    \n"
             "             / (vec3(%f) - vec3(%f) * color.rgb);             \n"
             "color.rgb = pow(color.rgb, vec3(1.0/%f));                     \n"
             // LMS matrix
             "color.rgb = mat3( 3.43661, -0.79133, -0.0259499,              \n"
             "                 -2.50645,  1.98360, -0.0989137,              \n"
             "                  0.06984, -0.192271, 1.12486) * color.rgb;   \n"
             // PQ OETF
             "color.rgb = pow(max(color.rgb, 0.0), vec3(%f));               \n"
             "color.rgb = (vec3(%f) + vec3(%f) * color.rgb)                 \n"
             "             / (vec3(1.0) + vec3(%f) * color.rgb);            \n"
             "color.rgb = pow(color.rgb, vec3(%f));                         \n",
             PQ_M2, PQ_C1, PQ_C2, PQ_C3, PQ_M1,
             PQ_M1, PQ_C1, PQ_C2, PQ_C3, PQ_M2);
        break;

    case PL_COLOR_SYSTEM_BT_2100_HLG:
        GLSL(// HLG OETF^-1
             "color.rgb = mix(vec3(4.0) * color.rgb * color.rgb,                \n"
             "                exp((color.rgb - vec3(%f)) * vec3(1.0/%f))        \n"
             "                    + vec3(%f),                                   \n"
             "                lessThan(vec3(0.5), color.rgb));                  \n"
             // LMS matrix
             "color.rgb = mat3( 3.43661, -0.79133, -0.0259499,                  \n"
             "                 -2.50645,  1.98360, -0.0989137,                  \n"
             "                  0.06984, -0.192271, 1.12486) * color.rgb;       \n"
            // HLG OETF
             "color.rgb = mix(vec3(0.5) * sqrt(color.rgb),                      \n"
             "                vec3(%f) * log(color.rgb - vec3(%f)) + vec3(%f),  \n"
             "                lessThan(vec3(1.0), color.rgb));                  \n",
             HLG_C, HLG_A, HLG_B,
             HLG_A, HLG_B, HLG_C);
        break;

    case PL_COLOR_SYSTEM_DOLBYVISION:;
#ifdef PL_HAVE_DOVI
        // Dolby Vision always outputs BT.2020-referred HPE LMS, so hard-code
        // the inverse LMS->RGB matrix corresponding to this color space.
        pl_matrix3x3 dovi_lms2rgb = {{
            { 3.06441879, -2.16597676,  0.10155818},
            {-0.65612108,  1.78554118, -0.12943749},
            { 0.01736321, -0.04725154,  1.03004253},
        }};

        pl_matrix3x3_mul(&dovi_lms2rgb, &repr->dovi->linear);
        ident_t mat = sh_var(sh, (struct pl_shader_var) {
            .var = pl_var_mat3("lms2rgb"),
            .data = PL_TRANSPOSE_3X3(dovi_lms2rgb.m),
        });

        // PQ EOTF
        GLSL("color.rgb = pow(clamp(color.rgb, 0.0, 1.0), vec3(1.0/%f)); \n"
             "color.rgb = max(color.rgb - vec3(%f), 0.0)            \n"
             "             / (vec3(%f) - vec3(%f) * color.rgb);     \n"
             "color.rgb = pow(color.rgb, vec3(1.0/%f));             \n",
             PQ_M2, PQ_C1, PQ_C2, PQ_C3, PQ_M1);
        // LMS matrix
        GLSL("color.rgb = "$" * color.rgb; \n", mat);
        // PQ OETF
        GLSL("color.rgb = pow(max(color.rgb, 0.0), vec3(%f));       \n"
             "color.rgb = (vec3(%f) + vec3(%f) * color.rgb)         \n"
             "             / (vec3(1.0) + vec3(%f) * color.rgb);    \n"
             "color.rgb = pow(color.rgb, vec3(%f));                 \n",
             PQ_M1, PQ_C1, PQ_C2, PQ_C3, PQ_M2);
        break;
#else
        SH_FAIL(sh, "libplacebo was compiled without support for dolbyvision reshaping");
        return;
#endif

    case PL_COLOR_SYSTEM_UNKNOWN:
    case PL_COLOR_SYSTEM_RGB:
    case PL_COLOR_SYSTEM_XYZ:
    case PL_COLOR_SYSTEM_BT_601:
    case PL_COLOR_SYSTEM_BT_709:
    case PL_COLOR_SYSTEM_SMPTE_240M:
    case PL_COLOR_SYSTEM_BT_2020_NC:
    case PL_COLOR_SYSTEM_YCGCO:
    case PL_COLOR_SYSTEM_YCGCO_RE:
    case PL_COLOR_SYSTEM_YCGCO_RO:
        break; // no special post-processing needed

    case PL_COLOR_SYSTEM_COUNT:
        pl_unreachable();
    }

    // Gamma adjustment. Doing this here (in non-linear light) is technically
    // somewhat wrong, but this is just an aesthetic parameter and not really
    // meant for colorimetric precision, so we don't care too much.
    if (params && params->gamma == 0) {
        // Avoid division by zero
        GLSL("color.rgb = vec3(0.0); \n");
    } else if (params && params->gamma != 1) {
        ident_t gamma = sh_var(sh, (struct pl_shader_var) {
            .var = pl_var_float("gamma"),
            .data = &(float){ 1 / params->gamma },
        });
        GLSL("color.rgb = pow(max(color.rgb, vec3(0.0)), vec3("$")); \n", gamma);
    }

    pl_shader_set_alpha(sh, repr, PL_ALPHA_INDEPENDENT);
    GLSL("}\n");
}

void pl_shader_decode_color(pl_shader sh, struct pl_color_repr *repr,
                            const struct pl_color_adjustment *params)
{
    pl_shader_decode_color_ex(sh, pl_color_decode_args(
        .repr             = repr,
        .color_adjustment = params,
    ));
}

void pl_shader_encode_color(pl_shader sh, const struct pl_color_repr *repr)
{
    pl_shader_encode_color_ex(sh, pl_color_encode_args( .repr = repr ));
}

void pl_shader_encode_color_ex(pl_shader sh, const struct pl_color_encode_args *args)
{
    const struct pl_color_repr *repr = args->repr;
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    sh_describe(sh, "color encoding");
    GLSL("// pl_shader_encode_color \n"
         "{ \n");

    if (repr->alpha == PL_ALPHA_PREMULTIPLIED)
        GLSL("color.rgb *= vec3(color.a); \n");

    switch (repr->sys) {
    case PL_COLOR_SYSTEM_BT_2020_C:
        // Expand R'G'B' to RGB
        GLSL("vec3 lin = mix(color.rgb * vec3(1.0/4.5),                        \n"
             "                pow((color.rgb + vec3(0.0993))*vec3(1.0/1.0993), \n"
             "                    vec3(1.0/0.45)),                             \n"
             "                lessThanEqual(vec3(0.08145), color.rgb));        \n");

        // Compute Yc from RGB and compress to R'Y'cB'
        GLSL("color.g = dot(vec3(0.2627, 0.6780, 0.0593), lin);     \n"
             "color.g = mix(color.g * 4.5,                          \n"
             "              1.0993 * pow(color.g, 0.45) - 0.0993,   \n"
             "              0.0181 <= color.g);                     \n");

        // Compute C'bc and C'rc into color.br
        GLSL("color.br = color.br - color.gg;                       \n"
             "color.br *= mix(vec2(1.0/1.5816, 1.0/0.9936),         \n"
             "                vec2(1.0/1.9404, 1.0/1.7184),         \n"
             "                lessThanEqual(color.br, vec2(0.0)));  \n");
        break;

    case PL_COLOR_SYSTEM_BT_2100_PQ:;
        GLSL("color.rgb = pow(max(color.rgb, 0.0), vec3(1.0/%f));           \n"
             "color.rgb = max(color.rgb - vec3(%f), 0.0)                    \n"
             "             / (vec3(%f) - vec3(%f) * color.rgb);             \n"
             "color.rgb = pow(color.rgb, vec3(1.0/%f));                     \n"
             "color.rgb = mat3(0.412109, 0.166748, 0.024170,                \n"
             "                 0.523925, 0.720459, 0.075440,                \n"
             "                 0.063965, 0.112793, 0.900394) * color.rgb;   \n"
             "color.rgb = pow(color.rgb, vec3(%f));                         \n"
             "color.rgb = (vec3(%f) + vec3(%f) * color.rgb)                 \n"
             "             / (vec3(1.0) + vec3(%f) * color.rgb);            \n"
             "color.rgb = pow(color.rgb, vec3(%f));                         \n",
             PQ_M2, PQ_C1, PQ_C2, PQ_C3, PQ_M1,
             PQ_M1, PQ_C1, PQ_C2, PQ_C3, PQ_M2);
        break;

    case PL_COLOR_SYSTEM_BT_2100_HLG:
        GLSL("color.rgb = mix(vec3(4.0) * color.rgb * color.rgb,                \n"
             "                exp((color.rgb - vec3(%f)) * vec3(1.0/%f))        \n"
             "                    + vec3(%f),                                   \n"
             "                lessThan(vec3(0.5), color.rgb));                  \n"
             "color.rgb = mat3(0.412109, 0.166748, 0.024170,                    \n"
             "                 0.523925, 0.720459, 0.075440,                    \n"
             "                 0.063965, 0.112793, 0.900394) * color.rgb;       \n"
             "color.rgb = mix(vec3(0.5) * sqrt(color.rgb),                      \n"
             "                vec3(%f) * log(color.rgb - vec3(%f)) + vec3(%f),  \n"
             "                lessThan(vec3(1.0), color.rgb));                  \n",
             HLG_C, HLG_A, HLG_B,
             HLG_A, HLG_B, HLG_C);
        break;

    case PL_COLOR_SYSTEM_DOLBYVISION:
        SH_FAIL(sh, "Cannot un-apply dolbyvision yet (no inverse reshaping)!");
        return;

    case PL_COLOR_SYSTEM_UNKNOWN:
    case PL_COLOR_SYSTEM_RGB:
    case PL_COLOR_SYSTEM_XYZ:
    case PL_COLOR_SYSTEM_BT_601:
    case PL_COLOR_SYSTEM_BT_709:
    case PL_COLOR_SYSTEM_SMPTE_240M:
    case PL_COLOR_SYSTEM_BT_2020_NC:
    case PL_COLOR_SYSTEM_YCGCO:
    case PL_COLOR_SYSTEM_YCGCO_RE:
    case PL_COLOR_SYSTEM_YCGCO_RO:
        break; // no special pre-processing needed

    case PL_COLOR_SYSTEM_COUNT:
        pl_unreachable();
    }

    // Since this is a relatively rare operation, bypass it as much as possible
    bool skip = true;
    skip &= PL_DEF(repr->sys, PL_COLOR_SYSTEM_RGB) == PL_COLOR_SYSTEM_RGB;
    skip &= PL_DEF(repr->levels, PL_COLOR_LEVELS_FULL) == PL_COLOR_LEVELS_FULL;
    skip &= !repr->bits.sample_depth || !repr->bits.color_depth ||
             repr->bits.sample_depth == repr->bits.color_depth;
    skip &= !repr->bits.bit_shift;

    if (!skip) {
        struct pl_color_repr copy = *repr;
        pl_transform3x3 tr = pl_color_repr_decode_ex(&copy, pl_color_repr_decode_params(
            .primaries = args->primaries,
        ));
        pl_transform3x3_invert(&tr);

        ident_t cmat = sh_var(sh, (struct pl_shader_var) {
            .var  = pl_var_mat3("cmat"),
            .data = PL_TRANSPOSE_3X3(tr.mat.m),
        });

        ident_t cmat_c = sh_var(sh, (struct pl_shader_var) {
            .var  = pl_var_vec3("cmat_c"),
            .data = tr.c,
        });

        GLSL("color.rgb = "$" * color.rgb + "$"; \n", cmat, cmat_c);
    }

    GLSL("}\n");
}

static ident_t sh_luma_coeffs(pl_shader sh, const struct pl_raw_primaries *prim)
{
    pl_matrix3x3 rgb2xyz;
    rgb2xyz = pl_get_rgb2xyz_matrix(prim);

    // Cannot use `const vec3` because SH_FLOAT might not be a compile-time constant
    ident_t coeffs = sh_fresh(sh, "luma_coeffs");
    GLSLH("#define "$" vec3("$", "$", "$") \n", coeffs,
          SH_FLOAT(rgb2xyz.m[1][0]), // RGB->Y vector
          SH_FLOAT(rgb2xyz.m[1][1]),
          SH_FLOAT(rgb2xyz.m[1][2]));
    return coeffs;
}

void pl_shader_linearize(pl_shader sh, const struct pl_color_space *csp)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    if (csp->transfer == PL_COLOR_TRC_LINEAR)
        return;

    float csp_min, csp_max;
    pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
        .color      = csp,
        .metadata   = PL_HDR_METADATA_HDR10,
        .scaling    = PL_HDR_NORM,
        .out_min    = &csp_min,
        .out_max    = &csp_max,
    ));

    csp_min = pl_signal_black(csp_min, PL_HDR_NORM);

    // Note that this clamp may technically violate the definition of
    // ITU-R BT.2100, which allows for sub-blacks and super-whites to be
    // displayed on the display where such would be possible. That said, the
    // problem is that not all gamma curves are well-defined on the values
    // outside this range, so we ignore it and just clamp anyway for sanity.
    GLSL("// pl_shader_linearize \n");
    if (csp->transfer != PL_COLOR_TRC_SCRGB)
        GLSL("color.rgb = max(color.rgb, 0.0); \n");

    switch (csp->transfer) {
    case PL_COLOR_TRC_SRGB:
        GLSL("color.rgb = mix(color.rgb * vec3(1.0/12.92),               \n"
             "                pow((color.rgb + vec3(0.055))/vec3(1.055), \n"
             "                    vec3(2.4)),                            \n"
             "                lessThan(vec3(0.04045), color.rgb));       \n");
        goto scale_out;
    case PL_COLOR_TRC_BT_1886: {
        const float lb = powf(csp_min, 1/2.4f);
        const float lw = powf(csp_max, 1/2.4f);
        const float a = powf(lw - lb, 2.4f);
        const float b = lb / (lw - lb);
        GLSL("color.rgb = "$" * pow(color.rgb + vec3("$"), vec3(2.4)); \n",
             SH_FLOAT(a), SH_FLOAT(b));
        return;
    }
    case PL_COLOR_TRC_GAMMA18:
        GLSL("color.rgb = pow(color.rgb, vec3(1.8));\n");
        goto scale_out;
    case PL_COLOR_TRC_GAMMA20:
        GLSL("color.rgb = pow(color.rgb, vec3(2.0));\n");
        goto scale_out;
    case PL_COLOR_TRC_UNKNOWN:
    case PL_COLOR_TRC_GAMMA22:
        GLSL("color.rgb = pow(color.rgb, vec3(2.2));\n");
        goto scale_out;
    case PL_COLOR_TRC_GAMMA24:
        GLSL("color.rgb = pow(color.rgb, vec3(2.4));\n");
        goto scale_out;
    case PL_COLOR_TRC_GAMMA26:
        GLSL("color.rgb = pow(color.rgb, vec3(2.6));\n");
        goto scale_out;
    case PL_COLOR_TRC_GAMMA28:
        GLSL("color.rgb = pow(color.rgb, vec3(2.8));\n");
        goto scale_out;
    case PL_COLOR_TRC_PRO_PHOTO:
        GLSL("color.rgb = mix(color.rgb * vec3(1.0/16.0),              \n"
             "                pow(color.rgb, vec3(1.8)),               \n"
             "                lessThan(vec3(0.03125), color.rgb));     \n");
        goto scale_out;
    case PL_COLOR_TRC_ST428:
        GLSL("color.rgb = vec3(52.37/48.0) * pow(color.rgb, vec3(2.6));\n");
        goto scale_out;
    case PL_COLOR_TRC_PQ:
        GLSL("color.rgb = pow(min(color.rgb, 1.0), vec3(1.0/%f)); \n"
             "color.rgb = max(color.rgb - vec3(%f), 0.0)        \n"
             "             / (vec3(%f) - vec3(%f) * color.rgb); \n"
             "color.rgb = pow(color.rgb, vec3(1.0/%f));         \n"
             // PQ's output range is 0-10000, but we need it to be relative to
             // to PL_COLOR_SDR_WHITE instead, so rescale
             "color.rgb *= vec3(%f);                            \n",
             PQ_M2, PQ_C1, PQ_C2, PQ_C3, PQ_M1, 10000.0 / PL_COLOR_SDR_WHITE);
        return;
    case PL_COLOR_TRC_HLG: {
        const float y = 1.2f * powf(1.111f, log2f(csp_max / HLG_REF));
        const float b = sqrtf(3 * powf(csp_min / csp_max, 1 / y));
        // OETF^-1
        GLSL("color.rgb = "$" * color.rgb + vec3("$");                  \n"
             "color.rgb = mix(vec3(4.0) * color.rgb * color.rgb,        \n"
             "                exp((color.rgb - vec3(%f)) * vec3(1.0/%f))\n"
             "                    + vec3(%f),                           \n"
             "                lessThan(vec3(0.5), color.rgb));          \n",
             SH_FLOAT(1 - b), SH_FLOAT(b),
             HLG_C, HLG_A, HLG_B);
        // OOTF
        GLSL("color.rgb *= 1.0 / 12.0;                                      \n"
             "color.rgb *= "$" * pow(max(dot("$", color.rgb), 0.0), "$");   \n",
             SH_FLOAT(csp_max),
             sh_luma_coeffs(sh, pl_raw_primaries_get(csp->primaries)),
             SH_FLOAT(y - 1));
        return;
    }
    case PL_COLOR_TRC_V_LOG:
        GLSL("color.rgb = mix((color.rgb - vec3(0.125)) * vec3(1.0/5.6), \n"
             "    pow(vec3(10.0), (color.rgb - vec3(%f)) * vec3(1.0/%f)) \n"
             "              - vec3(%f),                                  \n"
             "    lessThanEqual(vec3(0.181), color.rgb));                \n",
             VLOG_D, VLOG_C, VLOG_B);
        return;
    case PL_COLOR_TRC_S_LOG1:
        GLSL("color.rgb = pow(vec3(10.0), (color.rgb - vec3(%f)) * vec3(1.0/%f)) \n"
             "            - vec3(%f);                                            \n",
             SLOG_C, SLOG_A, SLOG_B);
        return;
    case PL_COLOR_TRC_S_LOG2:
        GLSL("color.rgb = mix((color.rgb - vec3(%f)) * vec3(1.0/%f),      \n"
             "    (pow(vec3(10.0), (color.rgb - vec3(%f)) * vec3(1.0/%f)) \n"
             "              - vec3(%f)) * vec3(1.0/%f),                   \n"
             "    lessThanEqual(vec3(%f), color.rgb));                    \n",
             SLOG_Q, SLOG_P, SLOG_C, SLOG_A, SLOG_B, SLOG_K2, SLOG_Q);
        return;
    case PL_COLOR_TRC_SCRGB:
        GLSL("color.rgb *= vec3(%f); \n",
             PL_COLOR_SCRGB_WHITE / PL_COLOR_SDR_WHITE);
        return;
    case PL_COLOR_TRC_LINEAR:
    case PL_COLOR_TRC_COUNT:
        break;
    }

    pl_unreachable();

scale_out:
    if (csp_max != 1 || csp_min != 0) {
        GLSL("color.rgb = "$" * color.rgb + vec3("$"); \n",
             SH_FLOAT(csp_max - csp_min), SH_FLOAT(csp_min));
    }
}

void pl_shader_delinearize(pl_shader sh, const struct pl_color_space *csp)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    if (csp->transfer == PL_COLOR_TRC_LINEAR)
        return;

    float csp_min, csp_max;
    pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
        .color      = csp,
        .metadata   = PL_HDR_METADATA_HDR10,
        .scaling    = PL_HDR_NORM,
        .out_min    = &csp_min,
        .out_max    = &csp_max,
    ));

    csp_min = pl_signal_black(csp_min, PL_HDR_NORM);

    GLSL("// pl_shader_delinearize \n");
    if (pl_color_space_is_black_scaled(csp) &&
        csp->transfer != PL_COLOR_TRC_HLG &&
        (csp_max != 1 || csp_min != 0))
    {
        GLSL("color.rgb = "$" * color.rgb + vec3("$"); \n",
             SH_FLOAT(1 / (csp_max - csp_min)),
             SH_FLOAT(-csp_min / (csp_max - csp_min)));
    }

    if (csp->transfer != PL_COLOR_TRC_SCRGB)
        GLSL("color.rgb = max(color.rgb, 0.0); \n");

    switch (csp->transfer) {
    case PL_COLOR_TRC_SRGB:
        GLSL("color.rgb = mix(color.rgb * vec3(12.92),                        \n"
             "                vec3(1.055) * pow(color.rgb, vec3(1.0/2.4))     \n"
             "                    - vec3(0.055),                              \n"
             "                lessThanEqual(vec3(0.0031308), color.rgb));     \n");
        return;
    case PL_COLOR_TRC_BT_1886: {
        const float lb = powf(csp_min, 1/2.4f);
        const float lw = powf(csp_max, 1/2.4f);
        const float a = powf(lw - lb, 2.4f);
        const float b = lb / (lw - lb);
        GLSL("color.rgb = pow("$" * color.rgb, vec3(1.0/2.4)) - vec3("$"); \n",
             SH_FLOAT(1.0 / a), SH_FLOAT(b));
        return;
    }
    case PL_COLOR_TRC_GAMMA18:
        GLSL("color.rgb = pow(color.rgb, vec3(1.0/1.8));\n");
        return;
    case PL_COLOR_TRC_GAMMA20:
        GLSL("color.rgb = pow(color.rgb, vec3(1.0/2.0));\n");
        return;
    case PL_COLOR_TRC_UNKNOWN:
    case PL_COLOR_TRC_GAMMA22:
        GLSL("color.rgb = pow(color.rgb, vec3(1.0/2.2));\n");
        return;
    case PL_COLOR_TRC_GAMMA24:
        GLSL("color.rgb = pow(color.rgb, vec3(1.0/2.4));\n");
        return;
    case PL_COLOR_TRC_GAMMA26:
        GLSL("color.rgb = pow(color.rgb, vec3(1.0/2.6));\n");
        return;
    case PL_COLOR_TRC_GAMMA28:
        GLSL("color.rgb = pow(color.rgb, vec3(1.0/2.8));\n");
        return;
    case PL_COLOR_TRC_ST428:
        GLSL("color.rgb = pow(color.rgb * vec3(48.0/52.37), vec3(1.0/2.6));\n");
        return;
    case PL_COLOR_TRC_PRO_PHOTO:
        GLSL("color.rgb = mix(color.rgb * vec3(16.0),                        \n"
             "                pow(color.rgb, vec3(1.0/1.8)),                 \n"
             "                lessThanEqual(vec3(0.001953), color.rgb));     \n");
        return;
    case PL_COLOR_TRC_PQ:
        GLSL("color.rgb *= vec3(1.0/%f);                         \n"
             "color.rgb = pow(color.rgb, vec3(%f));              \n"
             "color.rgb = (vec3(%f) + vec3(%f) * color.rgb)      \n"
             "             / (vec3(1.0) + vec3(%f) * color.rgb); \n"
             "color.rgb = pow(color.rgb, vec3(%f));              \n",
             10000 / PL_COLOR_SDR_WHITE, PQ_M1, PQ_C1, PQ_C2, PQ_C3, PQ_M2);
        return;
    case PL_COLOR_TRC_HLG: {
        const float y = 1.2f * powf(1.111f, log2f(csp_max / HLG_REF));
        const float b = sqrtf(3 * powf(csp_min / csp_max, 1 / y));
        // OOTF^-1
        GLSL("color.rgb *= 1.0 / "$";                                       \n"
             "color.rgb *= 12.0 * pow(max(1e-6, dot("$", color.rgb)), "$"); \n",
             SH_FLOAT(csp_max),
             sh_luma_coeffs(sh, pl_raw_primaries_get(csp->primaries)),
             SH_FLOAT((1 - y) / y));
        // OETF
        GLSL("color.rgb = mix(vec3(0.5) * sqrt(color.rgb),                      \n"
             "                vec3(%f) * log(color.rgb - vec3(%f)) + vec3(%f),  \n"
             "                lessThan(vec3(1.0), color.rgb));                  \n"
             "color.rgb = "$" * color.rgb + vec3("$");                          \n",
             HLG_A, HLG_B, HLG_C,
             SH_FLOAT(1 / (1 - b)), SH_FLOAT(-b / (1 - b)));
        return;
    }
    case PL_COLOR_TRC_V_LOG:
        GLSL("color.rgb = mix(vec3(5.6) * color.rgb + vec3(0.125),       \n"
             "                vec3(%f) * log(color.rgb + vec3(%f))       \n"
             "                    + vec3(%f),                            \n"
             "                lessThanEqual(vec3(0.01), color.rgb));     \n",
             VLOG_C / M_LN10, VLOG_B, VLOG_D);
        return;
    case PL_COLOR_TRC_S_LOG1:
        GLSL("color.rgb = vec3(%f) * log(color.rgb + vec3(%f)) + vec3(%f);\n",
             SLOG_A / M_LN10, SLOG_B, SLOG_C);
        return;
    case PL_COLOR_TRC_S_LOG2:
        GLSL("color.rgb = mix(vec3(%f) * color.rgb + vec3(%f),                \n"
             "                vec3(%f) * log(vec3(%f) * color.rgb + vec3(%f)) \n"
             "                    + vec3(%f),                                 \n"
             "                lessThanEqual(vec3(0.0), color.rgb));           \n",
             SLOG_P, SLOG_Q, SLOG_A / M_LN10, SLOG_K2, SLOG_B, SLOG_C);
        return;
    case PL_COLOR_TRC_SCRGB:
        GLSL("color.rgb *= vec3(%f); \n",
             PL_COLOR_SDR_WHITE / PL_COLOR_SCRGB_WHITE);
        return;
    case PL_COLOR_TRC_LINEAR:
    case PL_COLOR_TRC_COUNT:
        break;
    }

    pl_unreachable();
}

const struct pl_sigmoid_params pl_sigmoid_default_params = { PL_SIGMOID_DEFAULTS };

void pl_shader_sigmoidize(pl_shader sh, const struct pl_sigmoid_params *params)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    params = PL_DEF(params, &pl_sigmoid_default_params);
    float center = PL_DEF(params->center, pl_sigmoid_default_params.center);
    float slope  = PL_DEF(params->slope, pl_sigmoid_default_params.slope);

    // This function needs to go through (0,0) and (1,1), so we compute the
    // values at 1 and 0, and then scale/shift them, respectively.
    float offset = 1.0 / (1 + expf(slope * center));
    float scale  = 1.0 / (1 + expf(slope * (center - 1))) - offset;

    // Use a logit transform with an offset bias. This is algebraically
    // equivalent to the center-based form, but is more numerically stable and
    // avoids the less robust log(1/x - 1).
    GLSL("// pl_shader_sigmoidize                                 \n"
         "{                                                       \n"
         "color.rgb = clamp(color.rgb, 0.0, 1.0);                 \n"
         "vec3 sig = color.rgb * vec3("$") + vec3("$");           \n"
         "color.rgb = (log(sig / (1.0 - sig))                     \n"
         "             - log("$" / (1.0 - "$"))) * vec3("$");     \n"
         "}                                                       \n",
         SH_FLOAT(scale), SH_FLOAT(offset),
         SH_FLOAT(offset), SH_FLOAT(offset),
         SH_FLOAT(1.0 / slope));
}

void pl_shader_unsigmoidize(pl_shader sh, const struct pl_sigmoid_params *params)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    // See: pl_shader_sigmoidize
    params = PL_DEF(params, &pl_sigmoid_default_params);
    float center = PL_DEF(params->center, pl_sigmoid_default_params.center);
    float slope  = PL_DEF(params->slope, pl_sigmoid_default_params.slope);
    float offset = 1.0 / (1 + expf(slope * center));
    float scale  = 1.0 / (1 + expf(slope * (center - 1))) - offset;

    GLSL("// pl_shader_unsigmoidize                                 \n"
         "{                                                         \n"
         "color.rgb = clamp(color.rgb, 0.0, 1.0);                   \n"
         "float bias = log("$" / (1.0 - "$"));                      \n"
         "color.rgb = (vec3(1.0) / (vec3(1.0) +                     \n"
         "                exp(-(color.rgb * vec3("$") + bias)))     \n"
         "             - 1.0 / (1.0 + exp(-bias))) * vec3("$");     \n"
         "}                                                         \n",
         SH_FLOAT(offset), SH_FLOAT(offset),
         SH_FLOAT(slope),
         SH_FLOAT(1.0 / scale));
}

const struct pl_peak_detect_params pl_peak_detect_default_params = { PL_PEAK_DETECT_DEFAULTS };
const struct pl_peak_detect_params pl_peak_detect_high_quality_params = { PL_PEAK_DETECT_HQ_DEFAULTS };

// Decide whether to use the mastering space for tone mapping.
static bool use_mastering_space(const struct pl_color_space *csp,
                                pl_matrix3x3 *out_mat)
{
    const struct pl_raw_primaries *cont = pl_raw_primaries_get(csp->primaries);
    const struct pl_raw_primaries *mast = &csp->hdr.prim;
    if (!pl_primaries_valid(mast) || pl_raw_primaries_equal(mast, cont))
        return false;
    // The mastering gamut must lie within the container.
    const pl_matrix3x3 m2c = pl_get_color_mapping_matrix(mast, cont,
                                        PL_INTENT_RELATIVE_COLORIMETRIC);
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (m2c.m[i][j] < -0.01f)
                return false;
        }
    }
    if (out_mat) {
        // Relative colorimetric, so equal channels mean display-neutral.
        // The adaptation for non-D65 mastering whites cancels against the
        // D65 normalization in `pl_ipt_rgb2lms`, preserving absolute
        // colorimetry end to end.
        *out_mat = pl_get_color_mapping_matrix(cont, mast,
                                               PL_INTENT_RELATIVE_COLORIMETRIC);
    }
    return true;
}

static bool peak_detect_params_eq(const struct pl_peak_detect_params *a,
                                  const struct pl_peak_detect_params *b)
{
    return a->smoothing_period     == b->smoothing_period     &&
           a->scene_threshold_low  == b->scene_threshold_low  &&
           a->scene_threshold_high == b->scene_threshold_high &&
           a->percentile           == b->percentile;
    // don't compare `allow_delayed` because it doesn't change measurement
}

enum {
    // Split the peak buffer into several independent slices to reduce pressure
    // on global atomics
    SLICES = 12,

    // How many bits to use for storing PQ data. Be careful when setting this
    // too high, as it may overflow `unsigned int` on large video sources.
    //
    // The value chosen is enough to guarantee no overflow for an 8K x 4K frame
    // consisting entirely of 100% 10k nits PQ values, with 16x16 workgroups.
    PQ_BITS     = 14,
    PQ_MAX      = (1 << PQ_BITS) - 1,

    // Fixed-point bits for the linear-light scene average accumulator.
    // 16 bits is safe for frames up to 16K x 8K with 16x16 workgroups.
    LIN_BITS    = 16,
    LIN_MAX     = (1 << LIN_BITS) - 1,

    // How many bits to use for the histogram. We bias the histogram down
    // by half the PQ range (~90 nits), effectively clumping the SDR part
    // of the image into a single histogram bin.
    HIST_BITS   = 7,
    HIST_BIAS   = 1 << (HIST_BITS - 1),
    HIST_BINS   = (1 << HIST_BITS) - HIST_BIAS,

    // Convert from histogram bin to (starting) PQ value
#define HIST_PQ(bin) (((bin) + HIST_BIAS) << (PQ_BITS - HIST_BITS))
};


pl_static_assert(PQ_BITS >= HIST_BITS);

struct peak_buf_data {
    unsigned frame_wg_count[SLICES]; // number of work groups processed
    unsigned frame_wg_active[SLICES];// number of active (nonzero) work groups
    unsigned frame_sum_pq[SLICES];   // sum of PQ Y values over all WGs (PQ_BITS)
    unsigned frame_max_pq[SLICES];   // maximum PQ Y value among these WGs (PQ_BITS)
    unsigned frame_sum_lin[SLICES];  // sum of linear maxRGB means (LIN_BITS)
    unsigned frame_max_rgb[SLICES];  // maximum linear maxRGB (LIN_BITS)
    unsigned frame_hist[SLICES][HIST_BINS]; // always allocated, conditionally used
};

static const struct pl_buffer_var peak_buf_vars[] = {
#define VAR(field) {                                                            \
    .var = {                                                                    \
        .name = #field,                                                         \
        .type = PL_VAR_UINT,                                                    \
        .dim_v = 1,                                                             \
        .dim_m = 1,                                                             \
        .dim_a = sizeof(((struct peak_buf_data *) NULL)->field) /               \
                 sizeof(unsigned),                                              \
    },                                                                          \
    .layout = {                                                                 \
        .offset = offsetof(struct peak_buf_data, field),                        \
        .size   = sizeof(((struct peak_buf_data *) NULL)->field),               \
        .stride = sizeof(unsigned),                                             \
    },                                                                          \
}
    VAR(frame_wg_count),
    VAR(frame_wg_active),
    VAR(frame_sum_pq),
    VAR(frame_max_pq),
    VAR(frame_sum_lin),
    VAR(frame_max_rgb),
    VAR(frame_hist),
#undef VAR
};

struct sh_color_map_obj {
    // Tone map state
    struct {
        struct pl_tone_map_params params;
        float exposure;                     // last dynamic-target exposure
        pl_shader_obj lut;
    } tone;

    // Gamut map state
    struct {
        pl_shader_obj lut;
    } gamut;


    // Peak detection state
    struct {
        struct pl_peak_detect_params params;    // currently active parameters
        pl_buf buf;                             // pending peak detection buffer
        pl_buf readback;                        // readback buffer (fallback)
        float avg_pq;                           // current (smoothed) values
        float max_pq;
        float scene_avg_pq;                     // scene average light level
                                                // (mean of linear maxRGB),
                                                // stored as PQ of the mean
        float scene_max_pq;                     // scene peak light level in PQ
                                                // (maximum of maxRGB), in PQ
        float max_y_pq;                         // maximum PQ luminance
    } peak;
};

// Excluding size, since this is checked by sh_lut
static uint64_t gamut_map_signature(const struct pl_gamut_map_params *par)
{
    uint64_t sig = CACHE_KEY_GAMUT_LUT;
    pl_hash_merge(&sig, pl_str0_hash(par->function->name));
    pl_hash_merge(&sig, pl_var_hash(par->input_gamut));
    pl_hash_merge(&sig, pl_var_hash(par->output_gamut));
    pl_hash_merge(&sig, pl_var_hash(par->min_luma));
    pl_hash_merge(&sig, pl_var_hash(par->max_luma));
    pl_hash_merge(&sig, pl_var_hash(par->constants));
    return sig;
}

static void sh_color_map_uninit(pl_gpu gpu, void *ptr)
{
    struct sh_color_map_obj *obj = ptr;
    pl_shader_obj_destroy(&obj->tone.lut);
    pl_shader_obj_destroy(&obj->gamut.lut);
    pl_buf_destroy(gpu, &obj->peak.buf);
    pl_buf_destroy(gpu, &obj->peak.readback);
    memset(obj, 0, sizeof(*obj));
}

static inline float iir_coeff(float rate)
{
    if (!rate)
        return 1.0f;
    return 1.0f - expf(-1.0f / rate);
}

static float measure_peak(const struct peak_buf_data *data, float percentile,
                          float frame_max)
{
    if (percentile <= 0 || percentile >= 100)
        return frame_max;
    unsigned total_pixels = 0;
    for (int k = 0; k < SLICES; k++) {
        for (int i = 0; i < HIST_BINS; i++)
            total_pixels += data->frame_hist[k][i];
    }
    if (!total_pixels) // no histogram data available?
        return frame_max;

    const unsigned target_pixel = ceilf(percentile / 100.0f * total_pixels);
    if (target_pixel >= total_pixels)
        return frame_max;

    unsigned sum = 0;
    for (int i = 0; i < HIST_BINS; i++) {
        unsigned next = sum;
        for (int k = 0; k < SLICES; k++)
            next += data->frame_hist[k][i];
        if (next < target_pixel) {
            sum = next;
            continue;
        }

        // Upper and lower frequency boundaries of the matching histogram bin
        const unsigned count_low  = sum;      // last pixel of previous bin
        const unsigned count_high = next + 1; // first pixel of next bin
        pl_assert(count_low < target_pixel && target_pixel < count_high);

        // PQ luminance associated with count_low/high respectively
        const float pq_low  = (float) HIST_PQ(i)     / PQ_MAX;
        float pq_high       = (float) HIST_PQ(i + 1) / PQ_MAX;
        if (count_high > total_pixels) // special case for last histogram bin
            pq_high = fmaxf(frame_max, pq_low);

        // Position of `target_pixel` inside this bin, assumes pixels are
        // equidistributed inside a histogram bin
        const float ratio = (float) (target_pixel - count_low) /
                                    (count_high - count_low);
        return PL_MIX(pq_low, pq_high, ratio);
    }

    pl_unreachable();
}

// if `force` is true, ensures the buffer is read, even if `allow_delayed`
static void update_peak_buf(pl_gpu gpu, struct sh_color_map_obj *obj, bool force)
{
    const struct pl_peak_detect_params *params = &obj->peak.params;
    if (!obj->peak.buf)
        return;

    if (!force && params->allow_delayed && pl_buf_poll(gpu, obj->peak.buf, 0))
        return; // buffer not ready yet

    bool ok;
    struct peak_buf_data data = {0};
    if (obj->peak.readback) {
        pl_buf_copy(gpu, obj->peak.readback, 0, obj->peak.buf, 0, sizeof(data));
        ok = pl_buf_read(gpu, obj->peak.readback, 0, &data, sizeof(data));
    } else {
        ok = pl_buf_read(gpu, obj->peak.buf, 0, &data, sizeof(data));
    }
    if (ok && data.frame_wg_count[0] > 0) {
        // Peak detection completed successfully
        pl_buf_destroy(gpu, &obj->peak.buf);
    } else {
        // No data read? Possibly this peak obj has not been executed yet
        if (!ok) {
            PL_ERR(gpu, "Failed reading peak detection buffer!");
        } else if (params->allow_delayed) {
            PL_TRACE(gpu, "Peak detection buffer not yet ready, ignoring..");
        } else {
            PL_WARN(gpu, "Peak detection usage error: attempted detecting peak "
                    "and using detected peak in the same shader program, "
                    "but `params->allow_delayed` is false! Ignoring, but "
                    "expect incorrect output.");
        }
        if (force || !ok)
            pl_buf_destroy(gpu, &obj->peak.buf);
        return;
    }

    uint64_t frame_sum_pq = 0u, frame_sum_lin = 0u,
             frame_wg_count = 0u, frame_wg_active = 0u;
    unsigned frame_max_rgb = 0u;
    for (int k = 0; k < SLICES; k++) {
        frame_sum_pq    += data.frame_sum_pq[k];
        frame_sum_lin   += data.frame_sum_lin[k];
        frame_max_rgb    = PL_MAX(frame_max_rgb, data.frame_max_rgb[k]);
        frame_wg_count  += data.frame_wg_count[k];
        frame_wg_active += data.frame_wg_active[k];
    }
    float avg_pq, max_pq, scene_avg_pq, scene_max_pq, max_y_pq;
    if (frame_wg_active) {
        unsigned frame_max_y = data.frame_max_pq[0];
        for (int k = 1; k < SLICES; k++)
            frame_max_y = PL_MAX(frame_max_y, data.frame_max_pq[k]);
        max_y_pq = (float) frame_max_y / PQ_MAX;
        scene_avg_pq = pl_hdr_rescale(PL_HDR_NITS, PL_HDR_PQ, 10000.0f *
                                      frame_sum_lin / (frame_wg_active * (float) LIN_MAX));
        avg_pq = (float) frame_sum_pq / (frame_wg_active * PQ_MAX);
        max_pq = pl_hdr_rescale(PL_HDR_NITS, PL_HDR_PQ, 10000.0f *
                                frame_max_rgb / (float) LIN_MAX);
        max_pq = measure_peak(&data, params->percentile, max_pq);
        scene_max_pq = max_pq;
    } else {
        // Solid black frame
        avg_pq = max_pq = scene_avg_pq = scene_max_pq = max_y_pq = PL_COLOR_HDR_BLACK;
    }

    if (!obj->peak.avg_pq) {
        // Set the initial value accordingly if it contains no data
        obj->peak.avg_pq = avg_pq;
        obj->peak.max_pq = max_pq;
        obj->peak.scene_avg_pq = scene_avg_pq;
        obj->peak.scene_max_pq = scene_max_pq;
        obj->peak.max_y_pq = max_y_pq;
    } else {
        // Ignore small deviations from existing peak (rounding error)
        static const float epsilon = 1.0f / PQ_MAX;
        if (fabsf(avg_pq - obj->peak.avg_pq) < epsilon)
            avg_pq = obj->peak.avg_pq;
        if (fabsf(max_pq - obj->peak.max_pq) < epsilon)
            max_pq = obj->peak.max_pq;
        if (fabsf(scene_avg_pq - obj->peak.scene_avg_pq) < epsilon)
            scene_avg_pq = obj->peak.scene_avg_pq;
        if (fabsf(scene_max_pq - obj->peak.scene_max_pq) < epsilon)
            scene_max_pq = obj->peak.scene_max_pq;
        if (fabsf(max_y_pq - obj->peak.max_y_pq) < epsilon)
            max_y_pq = obj->peak.max_y_pq;
    }

    // Use an IIR low-pass filter to smooth out the detected values
    const float coeff = iir_coeff(params->smoothing_period);
    obj->peak.avg_pq += coeff * (avg_pq - obj->peak.avg_pq);
    obj->peak.max_pq += coeff * (max_pq - obj->peak.max_pq);
    obj->peak.scene_avg_pq += coeff * (scene_avg_pq - obj->peak.scene_avg_pq);
    obj->peak.scene_max_pq += coeff * (scene_max_pq - obj->peak.scene_max_pq);
    obj->peak.max_y_pq += coeff * (max_y_pq - obj->peak.max_y_pq);

    // Scene change hysteresis
    if (params->scene_threshold_low > 0 && params->scene_threshold_high > 0) {
        const float log10_pq = 1e-2f; // experimentally determined approximate
        const float thresh_low = params->scene_threshold_low * log10_pq;
        const float thresh_high = params->scene_threshold_high * log10_pq;
        const float bias = (float) frame_wg_active / frame_wg_count;
        const float delta = bias * fabsf(avg_pq - obj->peak.avg_pq);
        const float mix_coeff = pl_smoothstep(thresh_low, thresh_high, delta);
        obj->peak.avg_pq = PL_MIX(obj->peak.avg_pq, avg_pq, mix_coeff);
        obj->peak.max_pq = PL_MIX(obj->peak.max_pq, max_pq, mix_coeff);
        obj->peak.scene_avg_pq = PL_MIX(obj->peak.scene_avg_pq, scene_avg_pq,
                                        mix_coeff);
        obj->peak.scene_max_pq = PL_MIX(obj->peak.scene_max_pq, scene_max_pq,
                                        mix_coeff);
        obj->peak.max_y_pq = PL_MIX(obj->peak.max_y_pq, max_y_pq, mix_coeff);
    }
}

bool pl_shader_detect_peak(pl_shader sh, struct pl_color_space csp,
                           pl_shader_obj *state,
                           const struct pl_peak_detect_params *params)
{
    params = PL_DEF(params, &pl_peak_detect_default_params);
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return false;

    pl_gpu gpu = SH_GPU(sh);
    if (!gpu || gpu->limits.max_ssbo_size < sizeof(struct peak_buf_data)) {
        PL_ERR(sh, "HDR peak detection requires a GPU with support for at "
               "least %zu bytes of SSBO data (supported: %zu)",
               sizeof(struct peak_buf_data), gpu ? gpu->limits.max_ssbo_size : 0);
        return false;
    }

    const bool use_histogram = params->percentile > 0 && params->percentile < 100;
    size_t shmem_req = 6 * sizeof(uint32_t);
    if (use_histogram)
        shmem_req += sizeof(uint32_t[HIST_BINS]);

    if (!sh_try_compute(sh, 16, 16, true, shmem_req)) {
        PL_ERR(sh, "HDR peak detection requires compute shaders with support "
               "for at least %zu bytes of shared memory! (avail: %zu)",
               shmem_req, sh_glsl(sh).max_shmem_size);
        return false;
    }

    pl_rect2df analysis_crop = params->analysis_crop;
    const bool use_analysis_crop = analysis_crop.x0 || analysis_crop.y0 ||
                                   analysis_crop.x1 || analysis_crop.y1;
    ident_t analysis_pos = NULL_IDENT;
    if (use_analysis_crop) {
        pl_rect2df_normalize(&analysis_crop);
        analysis_crop.x0 = PL_CLAMP(analysis_crop.x0, 0.0f, 1.0f);
        analysis_crop.y0 = PL_CLAMP(analysis_crop.y0, 0.0f, 1.0f);
        analysis_crop.x1 = PL_CLAMP(analysis_crop.x1, 0.0f, 1.0f);
        analysis_crop.y1 = PL_CLAMP(analysis_crop.y1, 0.0f, 1.0f);
        if (analysis_crop.x0 >= analysis_crop.x1 ||
            analysis_crop.y0 >= analysis_crop.y1)
        {
            PL_ERR(sh, "Invalid peak detection analysis crop: "
                   "{%f, %f, %f, %f}", params->analysis_crop.x0,
                   params->analysis_crop.y0, params->analysis_crop.x1,
                   params->analysis_crop.y1);
            return false;
        }

        analysis_pos = sh_attr_vec2(sh, "peak_detect_pos", &(pl_rect2df) {
            .x1 = 1.0f,
            .y1 = 1.0f,
        });
    }

    struct sh_color_map_obj *obj;
    obj = SH_OBJ(sh, state, PL_SHADER_OBJ_COLOR_MAP, struct sh_color_map_obj,
                 sh_color_map_uninit);
    if (!obj)
        return false;

    if (peak_detect_params_eq(&obj->peak.params, params)) {
        update_peak_buf(gpu, obj, true); // prevent over-writing previous frame
    } else {
        pl_reset_detected_peak(*state);
    }

    pl_assert(!obj->peak.buf);
    static const struct peak_buf_data zero = {0};

retry_ssbo:
    if (obj->peak.readback) {
        obj->peak.buf = pl_buf_create(gpu, pl_buf_params(
            .size           = sizeof(struct peak_buf_data),
            .storable       = true,
            .initial_data   = &zero,
        ));
    } else {
        obj->peak.buf = pl_buf_create(gpu, pl_buf_params(
            .size           = sizeof(struct peak_buf_data),
            .memory_type    = PL_BUF_MEM_DEVICE,
            .host_readable  = true,
            .storable       = true,
            .initial_data   = &zero,
        ));
    }

    if (!obj->peak.buf && !obj->peak.readback) {
        PL_WARN(sh, "Failed creating host-readable peak detection SSBO, "
                "retrying with fallback buffer");
        obj->peak.readback = pl_buf_create(gpu, pl_buf_params(
            .size           = sizeof(struct peak_buf_data),
            .host_readable  = true,
        ));
        if (obj->peak.readback)
            goto retry_ssbo;
    }

    if (!obj->peak.buf) {
        SH_FAIL(sh, "Failed creating peak detection SSBO!");
        return false;
    }

    obj->peak.params = *params;

    sh_desc(sh, (struct pl_shader_desc) {
        .desc = {
            .name   = "PeakBuf",
            .type   = PL_DESC_BUF_STORAGE,
            .access = PL_DESC_ACCESS_READWRITE,
        },
        .binding.object  = obj->peak.buf,
        .buffer_vars     = (struct pl_buffer_var *) peak_buf_vars,
        .num_buffer_vars = PL_ARRAY_SIZE(peak_buf_vars),
    });

    // For performance, we want to do as few atomic operations on global
    // memory as possible, so use an atomic in shmem for the work group.
    ident_t wg_sum   = sh_fresh(sh, "wg_sum"),
            wg_max   = sh_fresh(sh, "wg_max"),
            wg_black = sh_fresh(sh, "wg_black"),
            wg_lin   = sh_fresh(sh, "wg_lin"),
            wg_rgb   = sh_fresh(sh, "wg_rgb"),
            wg_excluded = sh_fresh(sh, "wg_excluded"),
            wg_hist  = NULL_IDENT;
    GLSLH("shared uint "$", "$", "$", "$", "$", "$"; \n",
          wg_sum, wg_max, wg_black, wg_lin, wg_rgb, wg_excluded);
    if (use_histogram) {
        wg_hist = sh_fresh(sh, "wg_hist");
        GLSLH("shared uint "$"[%u]; \n", wg_hist, HIST_BINS);
    }

    sh_describe(sh, "peak detection");
#pragma GLSL /* pl_shader_detect_peak */                                        \
    {                                                                           \
    const uint wg_size = gl_WorkGroupSize.x * gl_WorkGroupSize.y;               \
    const uint wg_idx = gl_WorkGroupID.y * gl_NumWorkGroups.x + gl_WorkGroupID.x;\
    const uint local_idx = gl_LocalInvocationIndex;                             \
    const uint slice = wg_idx % ${const uint: SLICES};                          \
    const uint hist_base = slice * ${const uint: HIST_BINS};                    \
    const vec4 color_orig = color;                                              \
    if (local_idx == 0u)                                                        \
        $wg_sum = $wg_max = $wg_black = $wg_lin = $wg_rgb = $wg_excluded = 0u;                 \
    @if (use_histogram) {                                                       \
        for (uint i = local_idx; i < ${const uint: HIST_BINS}; i += wg_size)    \
            $wg_hist[i] = 0u;                                                   \
    @}                                                                          \
    barrier();

    // Decode color into linear light representation
    pl_color_space_infer(&csp);
    pl_shader_linearize(sh, &csp);

    pl_matrix3x3 space_mat;
    const struct pl_raw_primaries *space = pl_raw_primaries_get(csp.primaries);
    if (use_mastering_space(&csp, &space_mat)) {
        space = &csp.hdr.prim;
        GLSL("color.rgb = "$" * color.rgb; \n", SH_MAT3(space_mat));
    }

    bool has_subgroups = sh_glsl(sh).subgroup_size > 0;
    const float cutoff = fmaxf(params->black_cutoff, 0.0f) * 1e-2f;
#pragma GLSL /* Measure luminance as N-bit PQ */                                \
    float luma = dot(${sh_luma_coeffs(sh, space)}, color.rgb);                  \
    luma *= ${const float: PL_COLOR_SDR_WHITE / 10000.0};                       \
    float mrgb = clamp(${const float: PL_COLOR_SDR_WHITE / 10000.0} *           \
        max(color.r, max(color.g, color.b)), 0.0, 1.0);                         \
    uint m_lin = uint(${const float: LIN_MAX} * mrgb);                          \
    luma = pow(clamp(luma, 0.0, 1.0), ${const float: PQ_M1});                   \
    luma = (${const float: PQ_C1} + ${const float: PQ_C2} * luma) /             \
           (1.0 + ${const float: PQ_C3} * luma);                                \
    luma = pow(luma, ${const float: PQ_M2});                                    \
    @if (cutoff)                                                                \
        luma *= smoothstep(0.0, ${float: cutoff}, luma);                        \
    uint y_pq = uint(${const float: PQ_MAX} * luma);                            \
    bool analysis_sample = true;                                                \
    @if (use_analysis_crop) {                                                   \
        analysis_sample =                                                       \
            $analysis_pos.x >= ${float: analysis_crop.x0} &&                    \
            $analysis_pos.x <  ${float: analysis_crop.x1} &&                    \
            $analysis_pos.y >= ${float: analysis_crop.y0} &&                    \
            $analysis_pos.y <  ${float: analysis_crop.y1};                      \
    @}                                                                          \
    bool eligible = analysis_sample;                                            \
    @if (cutoff)                                                                \
        eligible = eligible && y_pq != 0u;                                      \
    const uint sample_lin = analysis_sample ? m_lin : 0u;                      \
    const uint sample_pq = eligible ? y_pq : 0u;                                \
                                                                                \
    /* Update the work group's shared atomics */                                \
    @if (use_histogram) {                                                       \
        float mpq = pow(mrgb, ${const float: PQ_M1});                           \
        mpq = (${const float: PQ_C1} + ${const float: PQ_C2} * mpq) /           \
              (1.0 + ${const float: PQ_C3} * mpq);                              \
        mpq = pow(mpq, ${const float: PQ_M2});                                  \
        int bin = int(${const float: PQ_MAX} * mpq) >>                          \
                  ${const int: PQ_BITS - HIST_BITS};                            \
        bin -= ${const int: HIST_BIAS};                                         \
        bin = clamp(bin, 0, ${const int: HIST_BINS - 1});                       \
        @if (cutoff)                                                            \
            bin = y_pq == 0u ? 0 : bin;                                         \
        @if (has_subgroups) {                                                   \
            uvec4 e = subgroupBallot(eligible);                                 \
            /* Optimize for the very common case of identical histogram bins */ \
            if (subgroupAllEqual(bin)) {                                        \
                if (subgroupElect())                                            \
                    atomicAdd($wg_hist[bin], subgroupBallotBitCount(e));         \
            } else if (eligible) {                                              \
                atomicAdd($wg_hist[bin], 1u);                                   \
            }                                                                   \
        @} else {                                                               \
            if (eligible)                                                       \
                atomicAdd($wg_hist[bin], 1u);                                   \
        @}                                                                      \
    @}                                                                          \
                                                                                \
    @if (has_subgroups) {                                                       \
        uvec4 e = subgroupBallot(!analysis_sample);                            \
        uint group_sum = subgroupAdd(sample_pq);                                     \
        uint group_max = subgroupMax(sample_pq);                                     \
        uint group_lin = subgroupAdd(sample_lin);                                    \
        uint group_rgb = subgroupMax(sample_lin);                                    \
        @if (cutoff)                                                            \
            uvec4 b = subgroupBallot(analysis_sample && y_pq == 0u);                               \
        if (subgroupElect()) {                                                  \
            atomicAdd($wg_excluded, subgroupBallotBitCount(e));                \
            atomicAdd($wg_sum, group_sum);                                      \
            atomicMax($wg_max, group_max);                                      \
            atomicAdd($wg_lin, group_lin);                                      \
            atomicMax($wg_rgb, group_rgb);                                      \
            @if (cutoff)                                                        \
                atomicAdd($wg_black, subgroupBallotBitCount(b));                \
        }                                                                       \
    @} else {                                                                   \
        if (!analysis_sample)                                                  \
            atomicAdd($wg_excluded, 1u);                                       \
        atomicAdd($wg_sum, sample_pq);                                               \
        atomicMax($wg_max, sample_pq);                                               \
        atomicAdd($wg_lin, sample_lin);                                              \
        atomicMax($wg_rgb, sample_lin);                                              \
        @if (cutoff) {                                                          \
            if (analysis_sample && y_pq == 0u)                                                     \
                atomicAdd($wg_black, 1u);                                       \
        @}                                                                      \
    @}                                                                          \
    barrier();                                                                  \
                                                                                \
    @if (use_histogram) {                                                       \
        /* Update the histogram with a cooperative loop */                      \
        for (uint i = local_idx; i < ${const uint: HIST_BINS}; i += wg_size)    \
            atomicAdd(frame_hist[hist_base + i], $wg_hist[i]);                  \
    @}                                                                          \
                                                                                \
    /* Have one thread per work group update the global atomics */              \
    if (gl_LocalInvocationIndex == 0u) {                                        \
        uint analyzed = wg_size - $wg_excluded;                                 \
        uint num = analyzed - $wg_black;                                        \
        atomicAdd(frame_wg_count[slice], min(analyzed, 1u));                    \
        atomicAdd(frame_wg_active[slice], min(num, 1u));                        \
        if (num > 0u) {                                                         \
            atomicAdd(frame_sum_pq[slice], $wg_sum / num);                      \
            atomicAdd(frame_sum_lin[slice], $wg_lin / num);                     \
            atomicMax(frame_max_pq[slice], $wg_max);                            \
            atomicMax(frame_max_rgb[slice], $wg_rgb);                           \
        }                                                                       \
    }                                                                           \
    color = color_orig;                                                         \
    }

    return true;
}

bool pl_get_detected_hdr_metadata(const pl_shader_obj state,
                                  struct pl_hdr_metadata *out)
{
    if (!state || state->type != PL_SHADER_OBJ_COLOR_MAP)
        return false;

    struct sh_color_map_obj *obj = state->priv;
    update_peak_buf(state->gpu, obj, false);
    if (!obj->peak.avg_pq)
        return false;

    const float scene_avg = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS,
                                           obj->peak.scene_avg_pq);
    const float scene_max = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS,
                                           obj->peak.scene_max_pq);
    // peak.max_y_pq is not percentile-bounded, so fallback to maxRGB in case
    // it has some bogus value, it should be strictly <= maxRGB.
    // TODO: Resolve this maxRGB vs maxY discrepancy, DV L1 metadata is based on
    // maxRGB, not maxY. HDR10+ though is maxY. Our API exposes maxY.
    out->max_pq_y  = PL_MIN(obj->peak.max_y_pq, obj->peak.max_pq);
    out->avg_pq_y  = obj->peak.avg_pq;
    out->scene_avg = scene_avg;
    for (int i = 0; i < PL_ARRAY_SIZE(out->scene_max); i++)
        out->scene_max[i] = scene_max;
    return true;
}

void pl_reset_detected_peak(pl_shader_obj state)
{
    if (!state || state->type != PL_SHADER_OBJ_COLOR_MAP)
        return;

    struct sh_color_map_obj *obj = state->priv;
    pl_buf readback = obj->peak.readback;
    pl_buf_destroy(state->gpu, &obj->peak.buf);
    memset(&obj->peak, 0, sizeof(obj->peak));
    obj->peak.readback = readback;
}

void pl_shader_extract_features(pl_shader sh, struct pl_color_space csp)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    sh_describe(sh, "feature extraction");
    pl_shader_linearize(sh, &csp);
    GLSL("// pl_shader_extract_features             \n"
         "{                                         \n"
         "vec3 lms = %f * "$" * color.rgb;          \n"
         "lms = pow(max(lms, 0.0), vec3(%f));       \n"
         "lms = (vec3(%f) + %f * lms)               \n"
         "        / (vec3(1.0) + %f * lms);         \n"
         "lms = pow(lms, vec3(%f));                 \n"
         "float I = dot(vec3(%f, %f, %f), lms);     \n"
         "color.rgb = vec3(I, 0.0, 0.0);            \n"
         "}                                         \n",
         PL_COLOR_SDR_WHITE / 10000,
         SH_MAT3(pl_ipt_rgb2lms(pl_raw_primaries_get(csp.primaries))),
         PQ_M1, PQ_C1, PQ_C2, PQ_C3, PQ_M2,
         pl_ipt_lms2ipt.m[0][0], pl_ipt_lms2ipt.m[0][1], pl_ipt_lms2ipt.m[0][2]);
}

const struct pl_color_map_params pl_color_map_default_params = { PL_COLOR_MAP_DEFAULTS };
const struct pl_color_map_params pl_color_map_high_quality_params = { PL_COLOR_MAP_HQ_DEFAULTS };

static ident_t rect_pos(pl_shader sh, pl_rect2df rc)
{
    if (!rc.x0 && !rc.x1)
        rc.x1 = 1.0f;
    if (!rc.y0 && !rc.y1)
        rc.y1 = 1.0f;

    return sh_attr_vec2(sh, "tone_map_coords", &(pl_rect2df) {
        .x0 = -rc.x0         / (rc.x1 - rc.x0),
        .x1 = (1.0f - rc.x0) / (rc.x1 - rc.x0),
        .y0 = -rc.y1         / (rc.y0 - rc.y1),
        .y1 = (1.0f - rc.y1) / (rc.y0 - rc.y1),
    });
}

static void visualize_tone_map(pl_shader sh, pl_rect2df rc, float alpha,
                               const struct pl_tone_map_params *params)
{
    pl_assert(params->input_scaling  == PL_HDR_PQ);
    pl_assert(params->output_scaling == PL_HDR_PQ);

    GLSL("// Visualize tone mapping                 \n"
         "{                                         \n"
         "vec2 pos = "$";                           \n"
         "if (min(pos.x, pos.y) >= 0.0 &&           \n" // visualizer rect
         "    max(pos.x, pos.y) <= 1.0)             \n"
         "{                                         \n"
         "float xmin = "$";                         \n"
         "float xmax = "$";                         \n"
         "float xavg = "$";                         \n"
         "float ymin = "$";                         \n"
         "float ymax = "$";                         \n"
         "float alpha = 0.8 * "$";                  \n"
         "vec3 viz = color.rgb;                     \n"
         "float vv = tone_map(pos.x);               \n"
         // Color based on region
         "if (pos.x < xmin || pos.x > xmax) {       \n" // outside source
         "} else if (pos.y < ymin || pos.y > ymax) {\n" // outside target
         "    if (pos.y < xmin || pos.y > xmax) {   \n" //  and also source
         "        viz = vec3(0.1, 0.1, 0.5);        \n"
         "    } else {                              \n"
         "        viz = vec3(0.2, 0.05, 0.05);      \n" //  but inside source
         "    }                                     \n"
         "} else {                                  \n" // inside domain
         "    if (abs(pos.x - pos.y) < 1e-3) {      \n" // main diagonal
         "        viz = vec3(0.2);                  \n"
         "    } else if (pos.y < vv) {              \n" // inside function
         "        alpha *= 0.6;                     \n"
         "        viz = vec3(0.05);                 \n"
         "        if (vv > pos.x && pos.y > pos.x)  \n" // output brighter than input
         "            viz.rg = vec2(0.5, 0.7);      \n"
         "    } else {                              \n" // outside function
         "        if (vv < pos.x && pos.y < pos.x)  \n" // output darker than input
         "            viz = vec3(0.0, 0.1, 0.2);    \n"
         "    }                                     \n"
         "    if (pos.y > xmax) {                   \n" // inverse tone-mapping region
         "        vec3 hi = vec3(0.2, 0.5, 0.8);    \n"
         "        viz = mix(viz, hi, 0.5);          \n"
         "    } else if (pos.y < xmin) {            \n" // black point region
         "        viz = mix(viz, vec3(0.0), 0.3);   \n"
         "    }                                     \n"
         "    if (xavg > 0.0 && abs(pos.x - xavg) < 1e-3)\n" // source avg brightness
         "        viz = vec3(0.5);                  \n"
         "}                                         \n"
         "color.rgb = mix(color.rgb, viz, alpha);   \n"
         "}                                         \n"
         "}                                         \n",
         rect_pos(sh, rc),
         SH_FLOAT_DYN(params->input_min),
         SH_FLOAT_DYN(params->input_max),
         SH_FLOAT_DYN(params->input_avg),
         SH_FLOAT(params->output_min),
         SH_FLOAT_DYN(params->output_max),
         SH_FLOAT_DYN(alpha));
}

static void visualize_gamut_map(pl_shader sh, pl_rect2df rc,
                                ident_t lut, float hue, float theta,
                                const struct pl_gamut_map_params *params)
{
    ident_t ipt2lms = SH_MAT3(pl_ipt_ipt2lms);
    ident_t lms2rgb_src = SH_MAT3(pl_ipt_lms2rgb(&params->input_gamut));
    ident_t lms2rgb_dst = SH_MAT3(pl_ipt_lms2rgb(&params->output_gamut));

    GLSL("// Visualize gamut mapping                            \n"
         "vec2 pos = "$";                                       \n"
         "float pqmin = "$";                                    \n"
         "float pqmax = "$";                                    \n"
         "float rgbmin = "$";                                   \n"
         "float rgbmax = "$";                                   \n"
         "vec3 orig = ipt;                                      \n"
         "if (min(pos.x, pos.y) >= 0.0 &&                       \n"
         "    max(pos.x, pos.y) <= 1.0)                         \n"
         "{                                                     \n"
         // Source color to visualize
         "float mid = mix(pqmin, pqmax, 0.6);                   \n"
         "vec3 base = vec3(0.5, 0.0, 0.0);                      \n"
         "float hue = "$", theta = "$";                         \n"
         "base.x = mix(base.x, mid, sin(theta));                \n"
         "mat3 rot1 = mat3(1.0,    0.0,      0.0,               \n"
         "                 0.0,  cos(hue), sin(hue),            \n"
         "                 0.0, -sin(hue), cos(hue));           \n"
         "mat3 rot2 = mat3( cos(theta), 0.0, sin(theta),        \n"
         "                     0.0,     1.0,    0.0,            \n"
         "                 -sin(theta), 0.0, cos(theta));       \n"
         "vec3 dir = vec3(pos.yx - vec2(0.5), 0.0);             \n"
         "ipt = base + rot1 * rot2 * dir;                       \n"
         // Convert back to RGB (for gamut boundary testing)
         "lmspq = "$" * ipt;                                    \n"
         "lms = pow(max(lmspq, 0.0), vec3(1.0/%f));             \n"
         "lms = max(lms - vec3(%f), 0.0)                        \n"
         "             / (vec3(%f) - %f * lms);                 \n"
         "lms = pow(lms, vec3(1.0/%f));                         \n"
         "lms *= %f;                                            \n"
         // Check against src/dst gamut boundaries
         "vec3 rgbsrc = "$" * lms;                              \n"
         "vec3 rgbdst = "$" * lms;                              \n"
         "bool insrc, indst;                                    \n"
         "insrc = all(lessThan(rgbsrc, vec3(rgbmax))) &&        \n"
         "              all(greaterThan(rgbsrc, vec3(rgbmin))); \n"
         "indst = all(lessThan(rgbdst, vec3(rgbmax))) &&        \n"
         "              all(greaterThan(rgbdst, vec3(rgbmin))); \n"
         // Sample from gamut mapping 3DLUT
         "idx.x = (ipt.x - pqmin) / (pqmax - pqmin);            \n"
         "idx.y = 2.0 * length(ipt.yz);                         \n"
         "idx.z = %f * atan(ipt.z, ipt.y) + 0.5;                \n"
         "vec3 mapped = "$"(idx).xyz;                           \n"
         "mapped.yz -= vec2(32768.0/65535.0);                   \n"
         "float mappedhue = atan(mapped.z, mapped.y);           \n"
         "float mappedchroma = length(mapped.yz);               \n"
         "ipt = mapped;                                         \n"
         // Visualize gamuts
         "if (!insrc && !indst) {                               \n"
         "    ipt = orig;                                       \n"
         "} else if (insrc && !indst) {                         \n"
         "    ipt.x -= 0.1;                                     \n"
         "} else if (indst && !insrc) {                         \n"
         "    ipt.x += 0.1;                                     \n"
         "}                                                     \n"
         // Visualize iso-luminance and iso-hue lines
         "vec3 line;                                            \n"
         "if (insrc && fract(50.0 * mapped.x) < 1e-1) {         \n"
         "    float k = smoothstep(0.1, 0.0, abs(sin(theta)));  \n"
         "    line.x = mix(mapped.x, 0.3, 0.5);                 \n"
         "    line.yz = sqrt(length(mapped.yz)) *               \n"
         "              normalize(mapped.yz);                   \n"
         "    ipt = mix(ipt, line, k);                          \n"
         "}                                                     \n"
         "if (insrc && fract(10.0 * (mappedhue - hue)) < 1e-1) {\n"
         "    float k = smoothstep(0.3, 0.0, abs(cos(theta)));  \n"
         "    line.x = mapped.x - 0.05;                         \n"
         "    line.yz = 1.2 * mapped.yz;                        \n"
         "    ipt = mix(ipt, line, k);                          \n"
         "}                                                     \n"
         "if (insrc && fract(100.0 * mappedchroma) < 1e-1) {    \n"
         "    line.x = mapped.x + 0.1;                          \n"
         "    line.yz = 0.4 * mapped.yz;                        \n"
         "    ipt = mix(ipt, line, 0.5);                        \n"
         "}                                                     \n"
         "}                                                     \n",
         rect_pos(sh, rc),
         SH_FLOAT(params->min_luma), SH_FLOAT(params->max_luma),
         SH_FLOAT(pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NORM, params->min_luma)),
         SH_FLOAT(pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NORM, params->max_luma)),
         SH_FLOAT_DYN(hue), SH_FLOAT_DYN(theta),
         ipt2lms,
         PQ_M2, PQ_C1, PQ_C2, PQ_C3, PQ_M1,
         10000 / PL_COLOR_SDR_WHITE,
         lms2rgb_src,
         lms2rgb_dst,
         0.5f / M_PI,
         lut);
}

static void ipt_convert(pl_shader sh, ident_t rgb2lms, ident_t lms2ipt,
                        bool declare)
{
    const char *v = declare ? "vec3 " : "";
    GLSL("%s""lms = "$" * color.rgb;                \n"
         "%s""lmspq = %f * lms;                     \n"
         "lmspq = pow(max(lmspq, 0.0), vec3(%f));   \n"
         "lmspq = (vec3(%f) + %f * lmspq)           \n"
         "        / (vec3(1.0) + %f * lmspq);       \n"
         "lmspq = pow(lmspq, vec3(%f));             \n"
         "%s""ipt = "$" * lmspq;                    \n",
         v, rgb2lms,
         v, PL_COLOR_SDR_WHITE / 10000,
         PQ_M1, PQ_C1, PQ_C2, PQ_C3, PQ_M2,
         v, lms2ipt);
}

static void sample_feature_map(pl_shader sh, pl_tex feature_map)
{
    ident_t pos, pt;
    ident_t lowres = sh_bind(sh, feature_map, PL_TEX_ADDRESS_CLAMP,
                             PL_TEX_SAMPLE_LINEAR, "feature_map",
                             NULL, &pos, &pt);
    GLSL("vec2 lpos  = "$";                                 \n"
         "vec2 lpt   = "$";                                 \n"
         "vec2 lsize = vec2(textureSize("$", 0));           \n"
         "vec2 frac  = fract(lpos * lsize + vec2(0.5));     \n"
         "vec2 frac2 = frac * frac;                         \n"
         "vec2 inv   = vec2(1.0) - frac;                    \n"
         "vec2 inv2  = inv * inv;                           \n"
         "vec2 w0 = 1.0/6.0 * inv2 * inv;                   \n"
         "vec2 w1 = 2.0/3.0 - 0.5 * frac2 * (2.0 - frac);   \n"
         "vec2 w2 = 2.0/3.0 - 0.5 * inv2  * (2.0 - inv);    \n"
         "vec2 w3 = 1.0/6.0 * frac2 * frac;                 \n"
         "vec4 g = vec4(w0 + w1, w2 + w3);                  \n"
         "vec4 h = vec4(w1, w3) / g + inv.xyxy;             \n"
         "h.xy -= vec2(2.0);                                \n"
         "vec4 p = lpos.xyxy + lpt.xyxy * h;                \n"
         "float l00 = textureLod("$", p.xy, 0.0).r;         \n"
         "float l01 = textureLod("$", p.xw, 0.0).r;         \n"
         "float l0 = mix(l01, l00, g.y);                    \n"
         "float l10 = textureLod("$", p.zy, 0.0).r;         \n"
         "float l11 = textureLod("$", p.zw, 0.0).r;         \n"
         "float l1 = mix(l11, l10, g.y);                    \n"
         "float luma = mix(l1, l0, g.x);                    \n",
         pos, pt, lowres,
         lowres, lowres, lowres, lowres);
}

static void fill_tone_lut(void *data, const struct sh_lut_params *params)
{
    const struct pl_tone_map_params *lut_params = params->priv;
    pl_tone_map_generate(data, lut_params);
}

static void fill_gamut_lut(void *data, const struct sh_lut_params *params)
{
    const struct pl_gamut_map_params *lut_params = params->priv;
    const int lut_size = params->width * params->height * params->depth;
    void *tmp = pl_alloc(NULL, lut_size * sizeof(float) * lut_params->lut_stride);
    pl_gamut_map_generate(tmp, lut_params);

    // Convert to 16-bit unsigned integer for GPU texture
    const float *in = tmp;
    uint16_t *out = data;
    pl_assert(lut_params->lut_stride == 3);
    pl_assert(params->comps == 4);
    for (int i = 0; i < lut_size; i++) {
        out[0] = PL_CLAMP(roundf(in[0] * UINT16_MAX), 0, UINT16_MAX);
        out[1] = PL_CLAMP(roundf(in[1] * UINT16_MAX + 32768), 0, UINT16_MAX);
        out[2] = PL_CLAMP(roundf(in[2] * UINT16_MAX + 32768), 0, UINT16_MAX);
        out[3] = 0;
        in  += 3;
        out += 4;
    }

    pl_free(tmp);
}



void pl_shader_color_map_ex(pl_shader sh, const struct pl_color_map_params *params,
                            const struct pl_color_map_args *args)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;

    struct pl_color_space src = args->src, dst = args->dst;
    struct sh_color_map_obj *obj = NULL;
    if (args->state) {
        // Authored dynamic metadata takes precedence over the measurement,
        // which only fills in what the source did not provide
        struct pl_hdr_metadata detected = {0};
        if (pl_get_detected_hdr_metadata(*args->state, &detected)) {
            src.hdr.max_pq_y  = PL_DEF(src.hdr.max_pq_y,  detected.max_pq_y);
            src.hdr.avg_pq_y  = PL_DEF(src.hdr.avg_pq_y,  detected.avg_pq_y);
            src.hdr.scene_avg = PL_DEF(src.hdr.scene_avg, detected.scene_avg);
            for (int i = 0; i < PL_ARRAY_SIZE(src.hdr.scene_max); i++) {
                src.hdr.scene_max[i] = PL_DEF(src.hdr.scene_max[i],
                                              detected.scene_max[i]);
            }
        }
        obj = SH_OBJ(sh, args->state, PL_SHADER_OBJ_COLOR_MAP, struct sh_color_map_obj,
                     sh_color_map_uninit);
        if (!obj)
            return;
    }

    pl_color_space_infer_map(&src, &dst);
    if (pl_color_space_equal(&src, &dst)) {
        if (args->prelinearized)
            pl_shader_delinearize(sh, &dst);
        return;
    }

    params = PL_DEF(params, &pl_color_map_default_params);
    GLSL("// pl_shader_color_map \n"
         "{                      \n");

    struct pl_tone_map_params tone = {
        .function       = PL_DEF(params->tone_mapping_function, &pl_tone_map_clip),
        .constants      = params->tone_constants,
        .param          = params->tone_mapping_param,
        .input_scaling  = PL_HDR_PQ,
        .output_scaling = PL_HDR_PQ,
        .lut_size       = PL_DEF(params->lut_size, pl_color_map_default_params.lut_size),
        .hdr            = src.hdr,
    };

    pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
        .color      = &src,
        .metadata   = params->metadata,
        .scaling    = tone.input_scaling,
        .out_min    = &tone.input_min,
        .out_max    = &tone.input_max,
        .out_avg    = &tone.input_avg,
    ));

    pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
        .color      = &dst,
        .metadata   = PL_HDR_METADATA_HDR10,
        .scaling    = tone.output_scaling,
        .out_min    = &tone.output_min,
        .out_max    = &tone.output_max,
    ));

    pl_tone_map_params_infer(&tone);

    // Round sufficiently similar values
    if (fabs(tone.input_max - tone.output_max) < 1e-6)
        tone.output_max = tone.input_max;
    if (fabs(tone.input_min - tone.output_min) < 1e-6)
        tone.output_min = tone.input_min;

    // Don't clamp/anchor the tone curve to the infinite-contrast sentinel,
    // otherwise an active tone map re-lifts true black off zero.
    tone.input_min  = pl_signal_black(tone.input_min,  tone.input_scaling);
    tone.output_min = pl_signal_black(tone.output_min, tone.output_scaling);

    if (!params->inverse_tone_mapping) {
        // Never exceed the source unless requested, but still allow
        // black point adaptation. Adjust the input lumiance, such that the BPC
        // is calculated correctly, for the output dynamic range. This also
        // fixes clipping if the metadata is under-reported, which is actually
        // quite common for Dolby Vision content.
        tone.input_max = PL_MAX(tone.input_max, tone.output_max);

        // The curve must cover the tone mapping metric's actual range, not
        // just the luminance range. Chromatic content carries channel values
        // far above its CIE Y.
        const float scene_max = PL_MAX(src.hdr.scene_max[0],
                PL_MAX(src.hdr.scene_max[1], src.hdr.scene_max[2]));
        if (scene_max > 0) {
            tone.input_max = PL_MAX(tone.input_max,
                pl_hdr_rescale(PL_HDR_NITS, tone.input_scaling, scene_max));
        }
    }

    // Physical output floor: under an active dynamic target the curve maps
    // into a virtual range, and the display black adaptation must keep
    // referring to the display's real range.
    const float out_min_phys = tone.output_min;
    float dt_exposure = 1.0f;

    float scene_avg = src.hdr.scene_avg;
    if (!(scene_avg > 0) && src.hdr.avg_pq_y > 0)
        scene_avg = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, src.hdr.avg_pq_y);

    // Tone map into a virtual target T between the display peak P and the
    // source peak S, and apply the remaining P/T factor as a pure exposure
    // change in the gain. An exposure change scales the entire image
    // linearly: trading some average brightness buys headroom for the tone
    // mapping and the highlights, which gives far better results than
    // compressing e.g. a 10000 nits source directly into a 203 nits target.
    if (params->dynamic_target && obj && scene_avg > 0 && !params->inverse_tone_mapping &&
        tone.input_max > tone.output_max + 1e-4f)
    {
        // Smooth maximum of the display peak and a fixed perceptual (PQ)
        // distance below the scene average: scenes that fit the display
        // render statically, and only content whose average genuinely
        // exceeds the display trades brightness for headroom, bounding how
        // far a bright scene may drift from its native brightness.
        const float dt_dim = 0.09f, dt_soft = 0.04f;
        const float p_pq = tone.output_max;
        const float s_pq = tone.input_max;
        const float p_nits = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, p_pq);
        const float f_pq = pl_hdr_rescale(PL_HDR_NITS, PL_HDR_PQ, scene_avg);
        const float dt_u = p_pq;
        const float dt_v = f_pq - dt_dim;
        const float t_pq =
            PL_CLAMP(0.5f * (dt_u + dt_v) +
                     hypotf(0.5f * (dt_u - dt_v), dt_soft),
                     p_pq, s_pq);
        if (t_pq > p_pq + 1e-4f && t_pq < s_pq - 1e-4f) {
            const float t_nits = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, t_pq);
            dt_exposure = p_nits / t_nits;
            tone.output_max = t_pq;

            // Keep the black-point compensation inside the virtual curve,
            // with the floor pre-divided by the exposure so it lands on the
            // display black after the exposure applies. The curve then
            // redistributes shadow range perceptually.
            tone.output_min = pl_hdr_rescale(PL_HDR_NITS, PL_HDR_PQ,
                pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, out_min_phys) /
                dt_exposure);

            if (fabsf(dt_exposure - obj->tone.exposure) > 1e-3f) {
                PL_DEBUG(sh, "Dynamic tone map target: %.0f nits "
                         "(display %.0f nits, exposure %.3fx, "
                         "scene avg %.1f nits)",
                         t_nits, p_nits, dt_exposure, scene_avg);
            }
        }
    }

    const int *lut3d_size_def = pl_color_map_default_params.lut3d_size;
    // Tone mapping and the gamut-mapping source extent share this space
    pl_matrix3x3 space_mat;
    const bool use_mast_space = use_mastering_space(&src, &space_mat);
    const struct pl_raw_primaries *src_space = use_mast_space
        ? &src.hdr.prim : pl_raw_primaries_get(src.primaries);

    struct pl_gamut_map_params gamut = {
        .function        = PL_DEF(params->gamut_mapping, &pl_gamut_map_clip),
        .constants       = params->gamut_constants,
        .input_gamut     = *src_space,
        .output_gamut    = dst.hdr.prim,
        .lut_size_I      = PL_DEF(params->lut3d_size[0], lut3d_size_def[0]),
        .lut_size_C      = PL_DEF(params->lut3d_size[1], lut3d_size_def[1]),
        .lut_size_h      = PL_DEF(params->lut3d_size[2], lut3d_size_def[2]),
        .lut_stride      = 3,
    };

    float src_peak_static;
    pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
        .color      = &src,
        .metadata   = PL_HDR_METADATA_HDR10,
        .scaling    = PL_HDR_PQ,
        .out_max    = &src_peak_static,
    ));

    pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
        .color      = &dst,
        .metadata   = PL_HDR_METADATA_HDR10,
        .scaling    = PL_HDR_PQ,
        .out_min    = &gamut.min_luma,
        .out_max    = &gamut.max_luma,
    ));

    gamut.min_luma = pl_signal_black(gamut.min_luma, PL_HDR_PQ);

    // Clip the gamut mapping output to the input gamut if disabled
    if (!params->gamut_expansion && gamut.function->bidirectional) {
        if (pl_primaries_compatible(&gamut.input_gamut, &gamut.output_gamut)) {
            gamut.output_gamut = pl_primaries_clip(&gamut.output_gamut,
                                                   &gamut.input_gamut);
        }
    }

    // Backwards compatibility with older API
    switch (params->gamut_mode) {
    case PL_GAMUT_CLIP:
        switch (params->intent) {
        case PL_INTENT_AUTO:
        case PL_INTENT_PERCEPTUAL:
        case PL_INTENT_RELATIVE_COLORIMETRIC:
            break; // leave default
        case PL_INTENT_SATURATION:
            gamut.function = &pl_gamut_map_saturation;
            break;
        case PL_INTENT_ABSOLUTE_COLORIMETRIC:
            gamut.function = &pl_gamut_map_absolute;
            break;
        }
        break;
    case PL_GAMUT_DARKEN:
        gamut.function = &pl_gamut_map_darken;
        break;
    case PL_GAMUT_WARN:
        gamut.function = &pl_gamut_map_highlight;
        break;
    case PL_GAMUT_DESATURATE:
        gamut.function = &pl_gamut_map_desaturate;
        break;
    case PL_GAMUT_MODE_COUNT:
        pl_unreachable();
    }

    bool can_fast = !params->force_tone_mapping_lut;
    if (!args->state) {
        // No state object provided, forcibly disable advanced methods
        can_fast = true;
        if (tone.function != &pl_tone_map_clip)
            tone.function = &pl_tone_map_linear;
        if (gamut.function != &pl_gamut_map_clip)
            gamut.function = &pl_gamut_map_saturation;
    }

    pl_fmt gamut_fmt = pl_find_fmt(SH_GPU(sh), PL_FMT_UNORM, 4, 16, 16, PL_FMT_CAP_LINEAR);
    if (!gamut_fmt) {
        gamut.function = &pl_gamut_map_saturation;
        can_fast = true;
    }

    bool need_tone_map = !pl_tone_map_params_noop(&tone) ||
                         dt_exposure != 1.0f;
    bool need_gamut_map = !pl_gamut_map_params_noop(&gamut);

    if (!args->prelinearized)
        pl_shader_linearize(sh, &src);

    pl_matrix3x3 rgb2lms = pl_ipt_rgb2lms(pl_raw_primaries_get(src.primaries));
    pl_matrix3x3 lms2rgb = pl_ipt_lms2rgb(pl_raw_primaries_get(dst.primaries));
    ident_t lms2ipt = SH_MAT3(pl_ipt_lms2ipt);
    ident_t ipt2lms = SH_MAT3(pl_ipt_ipt2lms);

    if (need_gamut_map && gamut.function == &pl_gamut_map_saturation && can_fast) {
        const pl_matrix3x3 lms2src = pl_ipt_lms2rgb(&gamut.input_gamut);
        const pl_matrix3x3 dst2lms = pl_ipt_rgb2lms(&gamut.output_gamut);
        sh_describe(sh, "gamut map (saturation)");
        pl_matrix3x3_mul(&lms2rgb, &dst2lms);
        pl_matrix3x3_mul(&lms2rgb, &lms2src);
        need_gamut_map = false;
    }

    // Fast path: simply convert between primaries (if needed)
    if (!need_tone_map && !need_gamut_map) {
        if (src.primaries != dst.primaries) {
            sh_describe(sh, "colorspace conversion");
            pl_matrix3x3_mul(&lms2rgb, &rgb2lms);
            GLSL("color.rgb = "$" * color.rgb; \n", SH_MAT3(lms2rgb));
        }
        goto done;
    }

    // Convert the pixel into the tone-mapping RGB space.
    if (use_mast_space) {
        GLSL("color.rgb = "$" * color.rgb; \n", SH_MAT3(space_mat));
        rgb2lms = pl_ipt_rgb2lms(src_space);
    }

    // Mastering-peak soft clip: reproduce the as-mastered appearance by
    // folding per-channel excursions above the mastering display's peak
    // back toward it.
    float mclip = PL_CLAMP(params->mastering_clip, 0.0f, 1.0f);
    const float master_nits = args->src.hdr.max_luma;
    if (mclip > 0.0f && master_nits > 0.0f && master_nits < 9999.0f &&
        obj && obj->peak.max_y_pq > 0.0f)
    {
        // Trust the mastering peak only while the measured scene luminance
        // stays below it; badly mastered content with wrong metadata would
        // otherwise be clipped. The trust fades out continuously as the
        // measurement exceeds the peak, and the measurement is already
        // temporally smoothed, so a scene brightening past the peak (or a
        // fade-in ending above it) cannot toggle the clip on and off.
        const float measured =
            pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, obj->peak.max_y_pq);
        mclip *= 1.0f - pl_smoothstep(1.1f, 1.4f, measured / master_nits);
    } else {
        mclip = 0.0f;
    }
    if (mclip > 1e-3f) {
        const float knee = 0.95f; // fraction of the peak where rolloff starts
        const float m_norm = pl_hdr_rescale(PL_HDR_NITS, PL_HDR_NORM, master_nits);
        #pragma GLSL /* mastering-peak soft clip */                             \
        {                                                                       \
        vec3 mcn = color.rgb * ${dynamic float: 1.0f / m_norm};                 \
        vec3 mct = max(mcn - vec3(${float: knee}), 0.0) *                       \
                   ${float: 1.0f / (1.0f - knee)};                              \
        mcn = min(mcn, vec3(${float: knee})) +                                  \
              ${float: 1.0f - knee} * mct / (1.0 + mct);                        \
        color.rgb = mix(color.rgb, ${dynamic float: m_norm} * mcn,              \
                        ${dynamic float: mclip});                               \
        }
    }

    // Full path: convert input from normalized RGB to IPT
    ident_t rgb2lms_i = SH_MAT3(rgb2lms);
    ipt_convert(sh, rgb2lms_i, lms2ipt, true);

    if (params->show_clipping) {
        const float eps = 1e-6f;
        GLSL("bool clip_hi, clip_lo;                            \n"
             "clip_hi = any(greaterThan(color.rgb, vec3("$"))); \n"
             "clip_lo = any(lessThan(color.rgb, vec3("$")));    \n"
             "clip_hi = clip_hi || ipt.x > "$";                 \n"
             "clip_lo = clip_lo || ipt.x < "$";                 \n",
             SH_FLOAT_DYN(pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NORM, tone.input_max) + eps),
             SH_FLOAT(pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NORM, tone.input_min) - eps),
             SH_FLOAT_DYN(tone.input_max + eps),
             SH_FLOAT(tone.input_min - eps));
    }

    if (need_tone_map) {
        const struct pl_tone_map_function *fun = tone.function;
        sh_describef(sh, "%s tone map (%.0f -> %.0f)", fun->name,
                     pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, tone.input_max),
                     pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, tone.output_max));

        if (fun == &pl_tone_map_clip && can_fast) {

            GLSL("#define tone_map(x) clamp((x), "$", "$") \n",
                 SH_FLOAT(tone.input_min),
                 SH_FLOAT_DYN(tone.input_max));

        } else if (fun == &pl_tone_map_linear && can_fast) {

            const float gain = tone.constants.exposure;
            const float scale = tone.input_max - tone.input_min;

            ident_t linfun = sh_fresh(sh, "linear_pq");
            GLSLH("float "$"(float x) {                         \n"
                 // Stretch the input range (while clipping)
                 "    x = "$" * x + "$";                        \n"
                 "    x = clamp(x, 0.0, 1.0);                   \n"
                 "    x = "$" * x + "$";                        \n"
                 "    return x;                                 \n"
                 "}                                             \n",
                 linfun,
                 SH_FLOAT_DYN(gain / scale),
                 SH_FLOAT_DYN(-gain / scale * tone.input_min),
                 SH_FLOAT_DYN(tone.output_max - tone.output_min),
                 SH_FLOAT_DYN(tone.output_min));

            GLSL("#define tone_map(x) ("$"(x)) \n", linfun);

        } else {

            pl_assert(obj);
            ident_t lut = sh_lut(sh, sh_lut_params(
                .object     = &obj->tone.lut,
                .var_type   = PL_VAR_FLOAT,
                .lut_type   = SH_LUT_AUTO,
                .method     = SH_LUT_LINEAR,
                .width      = tone.lut_size,
                .comps      = 1,
                .update     = !pl_tone_map_params_equal(&tone, &obj->tone.params),
                .dynamic    = tone.input_avg > 0, // dynamic metadata
                .fill       = fill_tone_lut,
                .priv       = &tone,
            ));
            obj->tone.params = tone;
            obj->tone.exposure = dt_exposure;
            if (!lut) {
                SH_FAIL(sh, "Failed generating tone-mapping LUT!");
                return;
            }

            const float lut_range = tone.input_max - tone.input_min;
            GLSL("#define tone_map(x) ("$"("$" * (x) + "$")) \n",
                 lut, SH_FLOAT_DYN(1.0f / lut_range),
                 SH_FLOAT_DYN(-tone.input_min / lut_range));

        }

        bool need_recovery = tone.input_max >= tone.output_max;
        // Tone application in the cone (LMS) stage of the IPT model. The
        // curve is evaluated per cone channel, and the resulting cone
        // ratios are blended between the source's (chromaticity
        // preserving) and the converged result (the film response, which
        // whitens compressed emissive gradients along physiologically
        // plausible paths) by `film_strength`. Below the knee the curve
        // is linear, so both endpoints coincide and the application is
        // exact regardless of strength.
        const bool use_cr = need_recovery && params->contrast_recovery &&
                            args->feature_map;
        if (use_cr)
            sample_feature_map(sh, args->feature_map);

        const float flare_nits =
            pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS, tone.output_min);
        const float flare_frac = flare_nits / 10000.0f;
        const float film_str = PL_CLAMP(params->film_strength, 0.0f, 2.0f);
        const pl_matrix3x3 lms2rgb_src = pl_ipt_lms2rgb(src_space);

        const struct pl_tone_map_constants *tc = &tone.constants;
        float knee = tone.input_avg ? tone.input_avg
                   : PL_MIX(tone.input_min, tone.input_max, tc->knee_default);
        knee = PL_CLAMP(knee,
            PL_MIX(tone.input_min, tone.input_max, tc->knee_minimum),
            PL_MIX(tone.input_min, tone.input_max, tc->knee_maximum));
        const float knee_in  = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS,
                                              knee) / 10000.0f;
        const float knee_out = pl_hdr_rescale(PL_HDR_PQ, PL_HDR_NITS,
            pl_tone_map_sample(knee, &tone)) / 10000.0f;
        const float knee_gain = fmaxf(knee_out - flare_frac, 1e-9f) /
                                fmaxf(knee_in, 1e-9f);

#pragma GLSL /* tone mapping */                                             \
        @if (use_cr) {                                                      \
            /* Detail-preserving recovery: shift down to the low-frequency  \
             * level, tone map there, re-add the detail. */                 \
            float tm_d = clamp(ipt.x, 0.0, 1.0) -                           \
                         clamp(luma, 0.0, 1.0);                             \
            vec3 tm_lo = clamp(lmspq - vec3(tm_d), 0.0, 1.0);               \
            vec3 tm_o = mix(vec3(tone_map(lmspq.x), tone_map(lmspq.y),      \
                                 tone_map(lmspq.z)),                        \
                            vec3(tone_map(tm_lo.x), tone_map(tm_lo.y),      \
                                 tone_map(tm_lo.z)) + (lmspq - tm_lo),      \
                            ${float: params->contrast_recovery});           \
            tm_o = clamp(tm_o, ${dynamic float: tone.output_min},           \
                         ${dynamic float: tone.output_max});                \
        @} else {                                                           \
            vec3 tm_o = vec3(tone_map(lmspq.x), tone_map(lmspq.y),          \
                             tone_map(lmspq.z));                            \
        @}                                                                  \
        tm_o = pow(tm_o, vec3(1.0 / ${const float: PQ_M2}));                \
        tm_o = pow(max(tm_o - ${const float: PQ_C1}, 0.0) /                 \
                   (${const float: PQ_C2} - ${const float: PQ_C3} * tm_o),  \
                   vec3(1.0 / ${const float: PQ_M1}));                      \
        /* Chromaticity-preserving endpoint: the maximum RGB channel's      \
         * gain, so the output channel range is bounded by the curve for    \
         * any hue */                                                       \
        float tm_lx = clamp(${const float: PL_COLOR_SDR_WHITE / 10000.0} *  \
                            max(color.r, max(color.g, color.b)), 0.0, 1.0); \
        float tm_vx = pow(tm_lx, ${const float: PQ_M1});                    \
        tm_vx = (${const float: PQ_C1} + ${const float: PQ_C2} * tm_vx) /   \
                (1.0 + ${const float: PQ_C3} * tm_vx);                      \
        float tm_ox = tone_map(pow(tm_vx, ${const float: PQ_M2}));          \
        tm_ox = pow(tm_ox, 1.0 / ${const float: PQ_M2});                    \
        tm_ox = pow(max(tm_ox - ${const float: PQ_C1}, 0.0) /               \
                    (${const float: PQ_C2} - ${const float: PQ_C3} * tm_ox),\
                    1.0 / ${const float: PQ_M1});                           \
        float tm_fl = ${dynamic float: flare_frac};                         \
        float tm_ga = max(tm_ox - tm_fl, 0.0) / max(tm_lx, 1e-9);           \
        /* The film response weight, per cone channel: proportional to the  \
         * cone's own source ratio, ramping to the full response as the     \
         * shoulder attenuation deepens. */                                 \
        float tm_u = tm_lx > ${dynamic float: knee_in}                      \
            ? clamp(1.0 - tm_ga * ${dynamic float: 1.0f / knee_gain}, 0.0, 1.0) \
            : 0.0;                                                          \
        tm_u *= tm_u;                                                       \
        vec3 tm_s = clamp(lms * (1.0 /                                      \
                          max(max(lms.x, max(lms.y, lms.z)), 1e-9)),        \
                          0.0, 1.0);                                        \
        vec3 tm_w = ${const float: film_str} * mix(tm_s, vec3(1.0), tm_u);  \
        vec3 tm_r = mix(lms * (tm_ga *                                      \
                               ${const float: PL_COLOR_SDR_WHITE / 10000.0}),\
                        tm_o - vec3(tm_fl), tm_w);                          \
        float tm_e = ${dynamic float: dt_exposure * 10000.0f / PL_COLOR_SDR_WHITE}; \
        color.rgb = tm_e * (${SH_MAT3(lms2rgb_src)} *                       \
                            (vec3(tm_fl) + tm_r));

        ipt_convert(sh, rgb2lms_i, lms2ipt, false);
    }

    if (need_gamut_map) {
        const struct pl_gamut_map_function *fun = gamut.function;
        sh_describef(sh, "gamut map (%s)", fun->name);

        pl_assert(obj);
        ident_t lut = sh_lut(sh, sh_lut_params(
            .object     = &obj->gamut.lut,
            .var_type   = PL_VAR_FLOAT,
            .lut_type   = SH_LUT_TEXTURE,
            .fmt        = gamut_fmt,
            .method     = params->lut3d_tricubic ? SH_LUT_CUBIC : SH_LUT_LINEAR,
            .width      = gamut.lut_size_I,
            .height     = gamut.lut_size_C,
            .depth      = gamut.lut_size_h,
            .comps      = 4,
            .signature  = gamut_map_signature(&gamut),
            .cache      = SH_CACHE(sh),
            .fill       = fill_gamut_lut,
            .priv       = &gamut,
        ));
        if (!lut) {
            SH_FAIL(sh, "Failed generating gamut-mapping LUT!");
            return;
        }

        // 3D LUT lookup (in ICh space)
        const float lut_range = gamut.max_luma - gamut.min_luma;
        GLSL("vec3 idx;                             \n"
             "idx.x = "$" * ipt.x + "$";            \n"
             "idx.y = 2.0 * length(ipt.yz);         \n"
             "idx.z = %f * atan(ipt.z, ipt.y) + 0.5;\n"
             "ipt = "$"(idx).xyz;                   \n"
             "ipt.yz -= vec2(32768.0/65535.0);      \n",
             SH_FLOAT(1.0f / lut_range),
             SH_FLOAT(-gamut.min_luma / lut_range),
             0.5f / M_PI, lut);

        if (params->show_clipping) {
            GLSL("clip_lo = clip_lo || any(lessThan(idx, vec3(0.0)));    \n"
                 "clip_hi = clip_hi || any(greaterThan(idx, vec3(1.0))); \n");
        }

        if (params->visualize_lut) {
            visualize_gamut_map(sh, params->visualize_rect, lut,
                                params->visualize_hue, params->visualize_theta,
                                &gamut);
        }
    }

    // Convert IPT back to linear RGB
    GLSL("lmspq = "$" * ipt;                        \n"
         "lms = pow(max(lmspq, 0.0), vec3(1.0/%f)); \n"
         "lms = max(lms - vec3(%f), 0.0)            \n"
         "             / (vec3(%f) - %f * lms);     \n"
         "lms = pow(lms, vec3(1.0/%f));             \n"
         "lms *= %f;                                \n"
         "color.rgb = "$" * lms;                    \n",
         ipt2lms,
         PQ_M2, PQ_C1, PQ_C2, PQ_C3, PQ_M1,
         10000 / PL_COLOR_SDR_WHITE,
         SH_MAT3(lms2rgb));

    // Correct residual physical-target overflow after the selected original
    // gamut mapping. The default-off path emits no additional shader code.
    if (need_tone_map && params->vp_gamut_compression &&
        !params->inverse_tone_mapping)
    {
        const struct pl_raw_primaries *signal = pl_raw_primaries_get(dst.primaries);
        const struct pl_raw_primaries *physical = &dst.hdr.prim;
        const bool same = pl_raw_primaries_equal(signal, physical);
        const pl_matrix3x3 xyz = pl_get_rgb2xyz_matrix(physical);
        const float sum = xyz.m[1][0] + xyz.m[1][1] + xyz.m[1][2];
        float black, peak;
        pl_color_space_nominal_luma_ex(pl_nominal_luma_params(
            .color = &dst, .metadata = PL_HDR_METADATA_HDR10,
            .scaling = PL_HDR_NITS, .out_min = &black, .out_max = &peak));
        if (!(isfinite(black) && black >= 0 && isfinite(peak) && peak > black &&
              xyz.m[1][0] > 0 && xyz.m[1][1] > 0 && xyz.m[1][2] > 0 &&
              isfinite(sum)))
        {
            SH_FAIL(sh, "Gamut overflow correction requires a finite target and positive luminance weights");
            return;
        }

        pl_matrix3x3 to_physical = pl_get_xyz2rgb_matrix(physical);
        const pl_matrix3x3 signal_xyz = pl_get_rgb2xyz_matrix(signal);
        pl_matrix3x3_mul(&to_physical, &signal_xyz);
        pl_matrix3x3 to_signal = pl_get_xyz2rgb_matrix(signal);
        pl_matrix3x3_mul(&to_signal, &xyz);
        sh_describe(sh, "VP gamut overflow correction");
        GLSL("{ vec3 physical = color.rgb; \n");
        if (!same)
            GLSL("physical = "$" * physical; \n", SH_MAT3(to_physical));
        GLSL("  float black = "$", span = "$";                         \n"
             "  vec3 a = (physical - vec3(black)) / span;               \n"
             "  float m = min(min(min(a.r, a.g), a.b), 0.0);          \n"
             "  vec3 v = a - vec3(m);                                \n"
             "  float M = max(max(v.r, v.g), v.b);                    \n"
             "  float lo = min(min(v.r, v.g), v.b);                   \n"
             "  float saturation = M > 0.0 ? (M - lo) / M : 0.0;      \n"
             "  float reserve = 0.02 * saturation;                   \n"
             "  float q = 1.0 - reserve;                             \n"
             // Preserve the original signal, avoiding an extra matrix roundtrip
             // throughout the legal interior (including the entire gray ramp).
             "  if (m < 0.0 || M > q) {                              \n"
             "    float over = max(M - q, 0.0);                     \n"
             "    float den = sqrt(reserve * reserve + over * over); \n"
             "    float f = den > 0.0 ? over / den : 0.0;           \n"
             "    float s = M <= q ? M : 1.0 - reserve * (1.0 - f); \n"
             // This order stays bounded in float32 even when the shoulder
             // approaches one. A channel clamp is not the gamut operation.
             "    vec3 b = M > 0.0 ? (v / M) * s : vec3(0.0);      \n"
             "    vec3 w = vec3("$", "$", "$");                       \n"
             "    float yin = dot(w, a), yb = dot(w, b);            \n"
             // The uniform negative-channel lift must never create luminance.
             "    float cap = yb > 0.0 ? min(1.0, max(yin, 0.0) / yb) : 1.0; \n"
             "    physical = vec3(black) + span * (b * cap);         \n",
             SH_FLOAT(black / PL_COLOR_SDR_WHITE),
             SH_FLOAT((peak - black) / PL_COLOR_SDR_WHITE),
             SH_FLOAT(xyz.m[1][0] / sum), SH_FLOAT(xyz.m[1][1] / sum),
             SH_FLOAT(xyz.m[1][2] / sum));
        if (!same)
            GLSL("    physical = "$" * physical; \n", SH_MAT3(to_signal));
        GLSL("    color.rgb = physical; \n"
             "  } \n"
             "} \n");
    }

    if (params->show_clipping) {
        GLSL("if (clip_hi) {                                                \n"
             "    float k = dot(color.rgb, vec3(2.0 / 3.0));                \n"
             "    color.rgb = clamp(vec3(k) - color.rgb, 0.0, 1.0);         \n"
             "    float cmin = min(min(color.r, color.g), color.b);         \n"
             "    float cmax = max(max(color.r, color.g), color.b);         \n"
             "    float delta = cmax - cmin;                                \n"
             "    vec3 sat = smoothstep(cmin - 1e-6, cmax, color.rgb);      \n"
             "    const vec3 red = vec3(1.0, 0.0, 0.0);                     \n"
             "    color.rgb = mix(red, sat, smoothstep(0.0, 0.3, delta));   \n"
             "} else if (clip_lo) {                                         \n"
             "    vec3 hi = vec3(0.0, 0.3, 0.3);                            \n"
             "    color.rgb = mix(color.rgb, hi, 0.5);                      \n"
             "}                                                             \n");
    }

    if (need_tone_map) {
        if (params->visualize_lut) {
            float alpha = need_gamut_map ? powf(cosf(params->visualize_theta), 5.0f) : 1.0f;
            visualize_tone_map(sh, params->visualize_rect, alpha, &tone);
        }
        GLSL("#undef tone_map \n");
    }

done:
    pl_shader_delinearize(sh, &dst);
    GLSL("}\n");
}

// Backwards compatibility wrapper around `pl_shader_color_map_ex`
void pl_shader_color_map(pl_shader sh, const struct pl_color_map_params *params,
                         struct pl_color_space src, struct pl_color_space dst,
                         pl_shader_obj *state, bool prelinearized)
{
    pl_shader_color_map_ex(sh, params, pl_color_map_args(
        .src           = src,
        .dst           = dst,
        .prelinearized = prelinearized,
        .state         = state,
        .feature_map   = NULL
    ));
}

void pl_shader_cone_distort(pl_shader sh, struct pl_color_space csp,
                            const struct pl_cone_params *params)
{
    if (!sh_require(sh, PL_SHADER_SIG_COLOR, 0, 0))
        return;
    if (!params || !params->cones)
        return;

    sh_describe(sh, "cone distortion");
    GLSL("// pl_shader_cone_distort\n");
    GLSL("{\n");

    pl_color_space_infer(&csp);
    pl_shader_linearize(sh, &csp);

    pl_matrix3x3 cone_mat;
    cone_mat = pl_get_cone_matrix(params, pl_raw_primaries_get(csp.primaries));
    GLSL("color.rgb = "$" * color.rgb; \n", sh_var(sh, (struct pl_shader_var) {
        .var = pl_var_mat3("cone_mat"),
        .data = PL_TRANSPOSE_3X3(cone_mat.m),
    }));

    pl_shader_delinearize(sh, &csp);
    GLSL("}\n");
}
