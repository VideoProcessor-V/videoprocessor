#include "gpu_tests.h"
#include "shaders.h"

#include <libplacebo/renderer.h>
#include <libplacebo/utils/frame_queue.h>
#include <libplacebo/utils/upload.h>

#include "dispatch.h"

//#define PRINT_OUTPUT

void pl_buffer_tests(pl_gpu gpu)
{
    const size_t buf_size = 1024;
    if (buf_size > gpu->limits.max_buf_size)
        return;
    printf("pl_buffer_tests:\n");

    uint8_t *test_src = malloc(buf_size * 2);
    uint8_t *test_dst = test_src + buf_size;
    assert(test_src && test_dst);
    memset(test_dst, 0, buf_size);
    for (int i = 0; i < buf_size; i++)
        test_src[i] = RANDOM_U8;

    pl_buf buf = NULL, tbuf = NULL;

    printf("- test buffer static creation and readback\n");
    buf = pl_buf_create(gpu, pl_buf_params(
        .size = buf_size,
        .host_readable = true,
        .initial_data = test_src,
    ));

    REQUIRE(buf);
    REQUIRE(pl_buf_read(gpu, buf, 0, test_dst, buf_size));
    REQUIRE_MEMEQ(test_src, test_dst, buf_size);
    pl_buf_destroy(gpu, &buf);

    printf("- test buffer empty creation, update and readback\n");
    memset(test_dst, 0, buf_size);
    buf = pl_buf_create(gpu, pl_buf_params(
        .size = buf_size,
        .host_writable = true,
        .host_readable = true,
    ));

    REQUIRE(buf);
    pl_buf_write(gpu, buf, 0, test_src, buf_size);
    REQUIRE(pl_buf_read(gpu, buf, 0, test_dst, buf_size));
    REQUIRE_MEMEQ(test_src, test_dst, buf_size);
    pl_buf_destroy(gpu, &buf);

    printf("- test buffer-buffer copy and readback\n");
    memset(test_dst, 0, buf_size);
    buf = pl_buf_create(gpu, pl_buf_params(
        .size = buf_size,
        .initial_data = test_src,
    ));

    tbuf = pl_buf_create(gpu, pl_buf_params(
        .size = buf_size,
        .host_readable = true,
    ));

    REQUIRE(buf && tbuf);
    pl_buf_copy(gpu, tbuf, 0, buf, 0, buf_size);
    REQUIRE(pl_buf_read(gpu, tbuf, 0, test_dst, buf_size));
    REQUIRE_MEMEQ(test_src, test_dst, buf_size);
    pl_buf_destroy(gpu, &buf);
    pl_buf_destroy(gpu, &tbuf);

    if (buf_size <= gpu->limits.max_mapped_size) {
        printf("- test host mapped buffer readback\n");
        buf = pl_buf_create(gpu, pl_buf_params(
            .size = buf_size,
            .host_mapped = true,
            .initial_data = test_src,
        ));

        REQUIRE(buf);
        REQUIRE(!pl_buf_poll(gpu, buf, 0));
        REQUIRE_MEMEQ(test_src, buf->data, buf_size);
        pl_buf_destroy(gpu, &buf);
    }

    // `compute_queues` check is to exclude dummy GPUs here
    if (buf_size <= gpu->limits.max_ssbo_size && gpu->limits.compute_queues)
    {
        printf("- test endian swapping\n");
        buf = pl_buf_create(gpu, pl_buf_params(
            .size = buf_size,
            .storable = true,
            .initial_data = test_src,
        ));

        tbuf = pl_buf_create(gpu, pl_buf_params(
            .size = buf_size,
            .storable = true,
            .host_readable = true,
        ));

        REQUIRE(buf && tbuf);
        REQUIRE(pl_buf_copy_swap(gpu, &(struct pl_buf_copy_swap_params) {
            .src = buf,
            .dst = tbuf,
            .size = buf_size,
            .wordsize = 2,
        }));
        REQUIRE(pl_buf_read(gpu, tbuf, 0, test_dst, buf_size));
        for (int i = 0; i < buf_size / 2; i++) {
            REQUIRE_CMP(test_src[2 * i + 0], ==, test_dst[2 * i + 1], PRIu8);
            REQUIRE_CMP(test_src[2 * i + 1], ==, test_dst[2 * i + 0], PRIu8);
        }
        // test endian swap in-place
        REQUIRE(pl_buf_copy_swap(gpu, &(struct pl_buf_copy_swap_params) {
            .src = tbuf,
            .dst = tbuf,
            .size = buf_size,
            .wordsize = 4,
        }));
        REQUIRE(pl_buf_read(gpu, tbuf, 0, test_dst, buf_size));
        for (int i = 0; i < buf_size / 4; i++) {
            REQUIRE_CMP(test_src[4 * i + 0], ==, test_dst[4 * i + 2], PRIu8);
            REQUIRE_CMP(test_src[4 * i + 1], ==, test_dst[4 * i + 3], PRIu8);
            REQUIRE_CMP(test_src[4 * i + 2], ==, test_dst[4 * i + 0], PRIu8);
            REQUIRE_CMP(test_src[4 * i + 3], ==, test_dst[4 * i + 1], PRIu8);
        }
        pl_buf_destroy(gpu, &buf);
        pl_buf_destroy(gpu, &tbuf);
    }

    free(test_src);
}

static void test_cb(void *priv)
{
    bool *flag = priv;
    *flag = true;
}

static void pl_test_roundtrip(pl_gpu gpu, pl_tex tex[2],
                              uint8_t *src, uint8_t *dst)
{
    if (!tex[0] || !tex[1]) {
        printf("failed creating test textures... skipping this test\n");
        return;
    }

    int texels = tex[0]->params.w;
    texels *= tex[0]->params.h ? tex[0]->params.h : 1;
    texels *= tex[0]->params.d ? tex[0]->params.d : 1;

    pl_fmt fmt = tex[0]->params.format;
    size_t bytes = texels * fmt->texel_size;
    memset(src, 0, bytes);
    memset(dst, 0, bytes);

    for (int i = 0; i < texels; i++) {
        uint8_t *data = &src[i * fmt->texel_size];
        if (fmt->type == PL_FMT_FLOAT) {
            for (int n = 0; n < fmt->num_components; n++) {
                switch (fmt->component_depth[n]) {
                case 16: *(uint16_t *) data = RANDOM_F16; data += 2; break;
                case 32: *(float *)    data = RANDOM_F32; data += 4; break;
                case 64: *(double *)   data = RANDOM_F64; data += 8; break;
                }
            }
        } else {
            for (int n = 0; n < fmt->texel_size; n++)
                data[n] = RANDOM_U8;
        }
    }

    pl_timer ul, dl;
    ul = pl_timer_create(gpu);
    dl = pl_timer_create(gpu);

    bool ran_ul = false, ran_dl = false;

    REQUIRE(pl_tex_upload(gpu, &(struct pl_tex_transfer_params){
        .tex = tex[0],
        .ptr = src,
        .timer = ul,
        .callback = gpu->limits.callbacks ? test_cb : NULL,
        .priv = &ran_ul,
    }));

    // Test blitting, if possible for this format
    pl_tex dst_tex = tex[0];
    if (tex[0]->params.blit_src && tex[1]->params.blit_dst) {
        pl_tex_clear_ex(gpu, tex[1], (union pl_clear_color){0}); // for testing
        pl_tex_blit(gpu, &(struct pl_tex_blit_params) {
            .src = tex[0],
            .dst = tex[1],
        });
        dst_tex = tex[1];
    }

    REQUIRE(pl_tex_download(gpu, &(struct pl_tex_transfer_params){
        .tex = dst_tex,
        .ptr = dst,
        .timer = dl,
        .callback = gpu->limits.callbacks ? test_cb : NULL,
        .priv = &ran_dl,
    }));

    pl_gpu_finish(gpu);
    if (gpu->limits.callbacks)
        REQUIRE(ran_ul && ran_dl);

    if (fmt->emulated && fmt->type == PL_FMT_FLOAT) {
        // TODO: can't memcmp here because bits might be lost due to the
        // emulated 16/32 bit upload paths, figure out a better way to
        // generate data and verify the roundtrip!
    } else {
        REQUIRE_MEMEQ(src, dst, bytes);
    }

    // Exercise timer queries
    (void) pl_timer_query(gpu, ul);
    (void) pl_timer_query(gpu, dl);

    pl_timer_destroy(gpu, &ul);
    pl_timer_destroy(gpu, &dl);
}

void pl_texture_tests(pl_gpu gpu)
{
    const size_t max_size = 16*16*16 * 4 *sizeof(double);
    uint8_t *test_src = malloc(max_size * 2);
    uint8_t *test_dst = test_src + max_size;
    printf("pl_texture_tests:\n");

    for (int f = 0; f < gpu->num_formats; f++) {
        pl_fmt fmt = gpu->formats[f];
        if (fmt->opaque || !(fmt->caps & PL_FMT_CAP_HOST_READABLE))
            continue;

        printf("- testing texture roundtrip for format %s\n", fmt->name);
        assert(fmt->texel_size <= 4 * sizeof(double));

        struct pl_tex_params ref_params = {
            .format        = fmt,
            .blit_src      = (fmt->caps & PL_FMT_CAP_BLITTABLE),
            .blit_dst      = (fmt->caps & PL_FMT_CAP_BLITTABLE),
            .host_writable = true,
            .host_readable = true,
            .debug_tag     = PL_DEBUG_TAG,
        };

        pl_tex tex[2];

        if (gpu->limits.max_tex_1d_dim >= 16) {
            struct pl_tex_params params = ref_params;
            params.w = 16;
            if (!gpu->limits.blittable_1d_3d)
                params.blit_src = params.blit_dst = false;
            for (int i = 0; i < PL_ARRAY_SIZE(tex); i++)
                tex[i] = pl_tex_create(gpu, &params);
            pl_test_roundtrip(gpu, tex, test_src, test_dst);
            for (int i = 0; i < PL_ARRAY_SIZE(tex); i++)
                pl_tex_destroy(gpu, &tex[i]);
        }

        if (gpu->limits.max_tex_2d_dim >= 16) {
            struct pl_tex_params params = ref_params;
            params.w = params.h = 16;
            for (int i = 0; i < PL_ARRAY_SIZE(tex); i++)
                tex[i] = pl_tex_create(gpu, &params);
            pl_test_roundtrip(gpu, tex, test_src, test_dst);
            for (int i = 0; i < PL_ARRAY_SIZE(tex); i++)
                pl_tex_destroy(gpu, &tex[i]);
        }

        if (gpu->limits.max_tex_3d_dim >= 16) {
            struct pl_tex_params params = ref_params;
            params.w = params.h = params.d = 16;
            if (!gpu->limits.blittable_1d_3d)
                params.blit_src = params.blit_dst = false;
            for (int i = 0; i < PL_ARRAY_SIZE(tex); i++)
                tex[i] = pl_tex_create(gpu, &params);
            pl_test_roundtrip(gpu, tex, test_src, test_dst);
            for (int i = 0; i < PL_ARRAY_SIZE(tex); i++)
                pl_tex_destroy(gpu, &tex[i]);
        }
    }

    free(test_src);
}

static void pl_planar_tests(pl_gpu gpu)
{
    pl_fmt fmt = pl_find_named_fmt(gpu, "g8_b8_r8_420");
    if (!fmt)
        return;
    printf("pl_planar_tests:\n");
    REQUIRE_CMP(fmt->num_planes, ==, 3, "d");

    const int width = 64, height = 32;
    pl_tex tex = pl_tex_create(gpu, pl_tex_params(
        .w              = width,
        .h              = height,
        .format         = fmt,
        .blit_dst       = true,
        .host_readable  = true,
    ));
    if (!tex)
        return;
    for (int i = 0; i < fmt->num_planes; i++)
        REQUIRE(tex->planes[i]);

    pl_tex plane = tex->planes[1];
    uint8_t data[(width * height) >> 2];
    REQUIRE_CMP(plane->params.w * plane->params.h, ==, PL_ARRAY_SIZE(data), "d");

    pl_tex_clear(gpu, plane, (float[]){ (float) 0x80 / 0xFF, 0.0, 0.0, 1.0 });
    REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(
        .tex = plane,
        .ptr = data,
    )));

    uint8_t ref[PL_ARRAY_SIZE(data)];
    memset(ref, 0x80, sizeof(ref));
    REQUIRE_MEMEQ(data, ref, PL_ARRAY_SIZE(data));

    pl_tex_destroy(gpu, &tex);
}

static void pl_shader_tests(pl_gpu gpu)
{
    if (gpu->glsl.version < 410)
        return;
    printf("pl_shader_tests:\n");

    const char *vert_shader =
        "#version 410                               \n"
        "layout(location=0) in vec2 vertex_pos;     \n"
        "layout(location=1) in vec3 vertex_color;   \n"
        "layout(location=0) out vec3 frag_color;    \n"
        "void main() {                              \n"
        "    gl_Position = vec4(vertex_pos, 0, 1);  \n"
        "    frag_color = vertex_color;             \n"
        "}";

    const char *frag_shader =
        "#version 410                               \n"
        "layout(location=0) in vec3 frag_color;     \n"
        "layout(location=0) out vec4 out_color;     \n"
        "void main() {                              \n"
        "    out_color = vec4(frag_color, 1.0);     \n"
        "}";

    pl_fmt fbo_fmt;
    enum pl_fmt_caps caps = PL_FMT_CAP_RENDERABLE | PL_FMT_CAP_BLITTABLE |
                            PL_FMT_CAP_LINEAR;

    fbo_fmt = pl_find_fmt(gpu, PL_FMT_FLOAT, 4, 16, 32, caps);
    if (!fbo_fmt)
        return;

#define FBO_W 16
#define FBO_H 16

    pl_tex fbo;
    fbo = pl_tex_create(gpu, &(struct pl_tex_params) {
        .format         = fbo_fmt,
        .w              = FBO_W,
        .h              = FBO_H,
        .renderable     = true,
        .storable       = !!(fbo_fmt->caps & PL_FMT_CAP_STORABLE),
        .host_readable  = true,
        .blit_dst       = true,
    });
    REQUIRE(fbo);

    pl_tex_clear_ex(gpu, fbo, (union pl_clear_color){0});

    pl_fmt vert_fmt;
    vert_fmt = pl_find_vertex_fmt(gpu, PL_FMT_FLOAT, 3);
    REQUIRE(vert_fmt);

    static const struct vertex { float pos[2]; float color[3]; } vertices[] = {
        {{-1.0, -1.0}, {0, 0, 0}},
        {{ 1.0, -1.0}, {1, 0, 0}},
        {{-1.0,  1.0}, {0, 1, 0}},
        {{ 1.0,  1.0}, {1, 1, 0}},
    };

    pl_pass pass;
    pass = pl_pass_create(gpu, &(struct pl_pass_params) {
        .type           = PL_PASS_RASTER,
        .target_format  = fbo_fmt,
        .vertex_shader  = vert_shader,
        .glsl_shader    = frag_shader,

        .vertex_type    = PL_PRIM_TRIANGLE_STRIP,
        .vertex_stride  = sizeof(struct vertex),
        .num_vertex_attribs = 2,
        .vertex_attribs = (struct pl_vertex_attrib[]) {{
            .name     = "vertex_pos",
            .fmt      = pl_find_vertex_fmt(gpu, PL_FMT_FLOAT, 2),
            .location = 0,
            .offset   = offsetof(struct vertex, pos),
        }, {
            .name     = "vertex_color",
            .fmt      = pl_find_vertex_fmt(gpu, PL_FMT_FLOAT, 3),
            .location = 1,
            .offset   = offsetof(struct vertex, color),
        }},
    });
    REQUIRE(pass);
    if (pass->params.cached_program || pass->params.cached_program_len) {
        // Ensure both are set if either one is set
        REQUIRE(pass->params.cached_program);
        REQUIRE(pass->params.cached_program_len);
    }

    pl_timer timer = pl_timer_create(gpu);
    pl_pass_run(gpu, &(struct pl_pass_run_params) {
        .pass           = pass,
        .target         = fbo,
        .vertex_count   = PL_ARRAY_SIZE(vertices),
        .vertex_data    = vertices,
        .timer          = timer,
    });

    // Wait until this pass is complete and report the timer result
    pl_gpu_finish(gpu);
    printf("timer query result: %"PRIu64"\n", pl_timer_query(gpu, timer));
    pl_timer_destroy(gpu, &timer);

    static float test_data[FBO_H * FBO_W * 4] = {0};

    // Test against the known pattern of `src`, only useful for roundtrip tests
#define TEST_FBO_PATTERN(eps, fmt, ...)                                     \
    do {                                                                    \
        printf("- testing pattern of " fmt "\n", __VA_ARGS__);                \
        REQUIRE(pl_tex_download(gpu, &(struct pl_tex_transfer_params) {     \
            .tex = fbo,                                                     \
            .ptr = test_data,                                               \
        }));                                                                \
                                                                            \
        for (int y = 0; y < FBO_H; y++) {                                   \
            for (int x = 0; x < FBO_W; x++) {                               \
                float *color = &test_data[(y * FBO_W + x) * 4];             \
                REQUIRE_FEQ(color[0], (x + 0.5) / FBO_W, eps);              \
                REQUIRE_FEQ(color[1], (y + 0.5) / FBO_H, eps);              \
                REQUIRE_FEQ(color[2], 0.0, eps);                            \
                REQUIRE_FEQ(color[3], 1.0, eps);                            \
            }                                                               \
        }                                                                   \
    } while (0)

    TEST_FBO_PATTERN(1e-6, "%s", "initial rendering");

    if (sizeof(vertices) <= gpu->limits.max_vbo_size) {
        // Test the use of an explicit vertex buffer
        pl_buf vert = pl_buf_create(gpu, &(struct pl_buf_params) {
            .size = sizeof(vertices),
            .initial_data = vertices,
            .drawable = true,
        });

        REQUIRE(vert);
        pl_pass_run(gpu, &(struct pl_pass_run_params) {
            .pass           = pass,
            .target         = fbo,
            .vertex_count   = sizeof(vertices) / sizeof(struct vertex),
            .vertex_buf     = vert,
            .buf_offset     = 0,
        });

        pl_buf_destroy(gpu, &vert);
        TEST_FBO_PATTERN(1e-6, "%s", "using vertex buffer");
    }

    // Test the use of index buffers
    static const uint16_t indices[] = { 3, 2, 1, 0 };
    pl_pass_run(gpu, &(struct pl_pass_run_params) {
        .pass           = pass,
        .target         = fbo,
        .vertex_count   = PL_ARRAY_SIZE(indices),
        .vertex_data    = vertices,
        .index_data     = indices,
    });

    pl_pass_destroy(gpu, &pass);
    TEST_FBO_PATTERN(1e-6, "%s", "using indexed rendering");

    // Test the use of pl_dispatch
    pl_dispatch dp = pl_dispatch_create(gpu->log, gpu);
    pl_shader sh = pl_dispatch_begin(dp);
    REQUIRE(pl_shader_custom(sh, &(struct pl_custom_shader) {
        .body       = "color = vec4(col, 1.0);",
        .input      = PL_SHADER_SIG_NONE,
        .output     = PL_SHADER_SIG_COLOR,
    }));

    REQUIRE(pl_dispatch_vertex(dp, &(struct pl_dispatch_vertex_params) {
        .shader         = &sh,
        .target         = fbo,
        .vertex_stride  = sizeof(struct vertex),
        .vertex_position_idx = 0,
        .num_vertex_attribs = 2,
        .vertex_attribs = (struct pl_vertex_attrib[]) {{
            .name   = "pos",
            .fmt    = pl_find_vertex_fmt(gpu, PL_FMT_FLOAT, 2),
            .offset = offsetof(struct vertex, pos),
        }, {
            .name   = "col",
            .fmt    = pl_find_vertex_fmt(gpu, PL_FMT_FLOAT, 3),
            .offset = offsetof(struct vertex, color),
        }},

        .vertex_type    = PL_PRIM_TRIANGLE_STRIP,
        .vertex_coords  = PL_COORDS_NORMALIZED,
        .vertex_count   = PL_ARRAY_SIZE(vertices),
        .vertex_data    = vertices,
    }));

    TEST_FBO_PATTERN(1e-6, "%s", "using custom vertices");

    static float src_data[FBO_H * FBO_W * 4] = {0};
    memcpy(src_data, test_data, sizeof(src_data));

    pl_tex src;
    src = pl_tex_create(gpu, &(struct pl_tex_params) {
        .format         = fbo_fmt,
        .w              = FBO_W,
        .h              = FBO_H,
        .storable       = fbo->params.storable,
        .sampleable     = true,
        .initial_data   = src_data,
    });

    if (fbo->params.storable) {
        // Test 1x1 blit, to make sure the scaling code runs
        REQUIRE(pl_tex_blit_compute(gpu, &(struct pl_tex_blit_params) {
            .src = src,
            .dst = fbo,
            .src_rc = {0, 0, 0, 1, 1, 1},
            .dst_rc = {0, 0, 0, FBO_W, FBO_H, 1},
            .sample_mode = PL_TEX_SAMPLE_NEAREST,
        }));

        // Test non-resizing blit, which uses the efficient imageLoad path
        REQUIRE(pl_tex_blit_compute(gpu, &(struct pl_tex_blit_params) {
            .src = src,
            .dst = fbo,
            .src_rc = {0, 0, 0, FBO_W, FBO_H, 1},
            .dst_rc = {0, 0, 0, FBO_W, FBO_H, 1},
            .sample_mode = PL_TEX_SAMPLE_NEAREST,
        }));

        TEST_FBO_PATTERN(1e-6, "%s", "pl_tex_blit_compute");
    }

    // Test encoding/decoding of all gamma functions, color spaces, etc.
    for (enum pl_color_transfer trc = 0; trc < PL_COLOR_TRC_COUNT; trc++) {
        struct pl_color_space test_csp = {
            .transfer = trc,
            .hdr.min_luma = PL_COLOR_HDR_BLACK,
        };
        sh = pl_dispatch_begin(dp);
        pl_shader_sample_nearest(sh, pl_sample_src( .tex = src ));
        pl_shader_delinearize(sh, &test_csp);
        pl_shader_linearize(sh, &test_csp);
        REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(
            .shader = &sh,
            .target = fbo,
        )));

        float epsilon = pl_color_transfer_is_hdr(trc) ? 1e-4 : 1e-6;
        TEST_FBO_PATTERN(epsilon, "transfer function: %s", pl_color_transfer_name(trc));
    }

    // Test scRGB. Mostly to make sure we output correct scale and out-of-gamut values.
    // BT.2020 LINEAR to scRGB with Display P3 display primaries.
    {
        static const float bt2020_in[][4] = {
            { 1.0f, 1.0f, 1.0f, 1.0f }, // white
            { 1.0f, 0.0f, 0.0f, 1.0f }, // red
            { 0.0f, 1.0f, 0.0f, 1.0f }, // green
            { 0.0f, 0.0f, 1.0f, 1.0f }, // blue
            { 0.5f, 0.5f, 0.5f, 1.0f }, // grays
            { 0.01f, 0.01f, 0.01f, 1.0f },
            { 0.0f, 0.0f, 0.0f, 1.0f },
        };

        static const float clip_ref[][3] = {
            {  2.5375f,   2.5375f,   2.5375f  },
            {  4.2135f,  -0.3160f,  -0.0461f  },
            { -1.4911f,   2.8747f,  -0.2552f  },
            { -0.1849f,  -0.0212f,   2.8388f  },
        };

        static const float sat_ref[][3] = {
            {  2.5375f,   2.5375f,   2.5375f  },
            {  3.1083f,  -0.1067f,  -0.0464f  },
            { -0.5708f,   2.6442f,  -0.1995f  },
            {  0.0000f,   0.0000f,   2.7834f  },
        };

        const int N = PL_ARRAY_SIZE(bt2020_in);

        pl_tex bt2020_tex = pl_tex_create(gpu, &(struct pl_tex_params) {
            .format       = fbo_fmt,
            .w            = N,
            .h            = 1,
            .sampleable   = true,
            .initial_data = bt2020_in,
        });
        REQUIRE(bt2020_tex);

        pl_tex ref_fbo = pl_tex_create(gpu, &(struct pl_tex_params) {
            .format        = fbo_fmt,
            .w             = N,
            .h             = 1,
            .renderable    = true,
            .storable      = !!(fbo_fmt->caps & PL_FMT_CAP_STORABLE),
            .host_readable = true,
        });
        REQUIRE(ref_fbo);

        for (int g = 0; g < pl_num_gamut_map_functions; g++) {
            const float (*ref)[3] = NULL;
            if (pl_gamut_map_functions[g] == &pl_gamut_map_clip)
                ref = clip_ref;
            else if (pl_gamut_map_functions[g] == &pl_gamut_map_saturation)
                ref = sat_ref;

            pl_shader_obj gmap_state = NULL;
            sh = pl_dispatch_begin(dp);
            pl_shader_sample_nearest(sh, pl_sample_src( .tex = bt2020_tex ));
            pl_shader_color_map(sh, &(struct pl_color_map_params) {
                                    .gamut_mapping = pl_gamut_map_functions[g],
                                },
                                (struct pl_color_space) {
                                    .primaries = PL_COLOR_PRIM_BT_2020,
                                    .transfer  = PL_COLOR_TRC_LINEAR,
                                },
                                (struct pl_color_space) {
                                    .primaries = PL_COLOR_PRIM_BT_709,
                                    .transfer  = PL_COLOR_TRC_SCRGB,
                                    .hdr.prim  = *pl_raw_primaries_get(PL_COLOR_PRIM_DISPLAY_P3),
                                }, &gmap_state, false);
            REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(
                .shader = &sh,
                .target = ref_fbo,
            )));
            pl_shader_obj_destroy(&gmap_state);

            static float p3_out[PL_ARRAY_SIZE(bt2020_in) * 4];
            REQUIRE(pl_tex_download(gpu, &(struct pl_tex_transfer_params) {
                .tex = ref_fbo,
                .ptr = p3_out,
            }));

            for (int i = 0; i < N; i++) {
                const float *c = &p3_out[i * 4], *in = bt2020_in[i];
                if (ref && i < PL_ARRAY_SIZE(clip_ref)) {
                    REQUIRE_FEQ(c[0], ref[i][0], 1e-4f);
                    REQUIRE_FEQ(c[1], ref[i][1], 1e-4f);
                    REQUIRE_FEQ(c[2], ref[i][2], 1e-4f);
                }

                // Grays stay neutral and scale like white in every mapping
                if (in[0] == in[1] && in[1] == in[2]) {
                    REQUIRE_FEQ(c[0], c[1], 1e-4f);
                    REQUIRE_FEQ(c[1], c[2], 1e-4f);
                    REQUIRE_FEQ(c[1], in[1] * p3_out[1], 2e-3f);
                }
            }
        }

        pl_tex_destroy(gpu, &bt2020_tex);
        pl_tex_destroy(gpu, &ref_fbo);
    }

    for (enum pl_color_system sys = 0; sys < PL_COLOR_SYSTEM_COUNT; sys++) {
        if (sys == PL_COLOR_SYSTEM_DOLBYVISION)
            continue; // requires metadata
        sh = pl_dispatch_begin(dp);
        pl_shader_sample_nearest(sh, pl_sample_src( .tex = src ));
        pl_shader_encode_color(sh, &(struct pl_color_repr) { .sys = sys });
        pl_shader_decode_color_ex(sh, pl_color_decode_args(
            .repr = &(struct pl_color_repr) { .sys = sys },
        ));
        REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
            .shader = &sh,
            .target = fbo,
        }));

        float epsilon;
        switch (sys) {
        case PL_COLOR_SYSTEM_BT_2020_C:
        case PL_COLOR_SYSTEM_XYZ:
            epsilon = 1e-5;
            break;

        case PL_COLOR_SYSTEM_BT_2100_PQ:
        case PL_COLOR_SYSTEM_BT_2100_HLG:
            // These seem to be horrifically noisy and prone to breaking on
            // edge cases for some reason
            // TODO: figure out why!
            continue;

        default: epsilon = 1e-6; break;
        }

        TEST_FBO_PATTERN(epsilon, "color system: %s", pl_color_system_name(sys));
    }

    // XYZ roundtrip through explicit (non-default) primaries
    sh = pl_dispatch_begin(dp);
    pl_shader_sample_nearest(sh, pl_sample_src( .tex = src ));
    pl_shader_encode_color_ex(sh, pl_color_encode_args(
        .repr       = &(struct pl_color_repr) { .sys = PL_COLOR_SYSTEM_XYZ },
        .primaries  = PL_COLOR_PRIM_BT_2020,
    ));
    pl_shader_decode_color_ex(sh, pl_color_decode_args(
        .repr       = &(struct pl_color_repr) { .sys = PL_COLOR_SYSTEM_XYZ },
        .primaries  = PL_COLOR_PRIM_BT_2020,
    ));
    REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
        .shader = &sh,
        .target = fbo,
    }));
    TEST_FBO_PATTERN(1e-5, "%s", "color system: XYZ (BT.2020 primaries)");

    // Repeat this a few times to test the caching
    pl_cache cache = pl_cache_create(pl_cache_params( .log = gpu->log ));
    pl_gpu_set_cache(gpu, cache);
    for (int i = 0; i < 10; i++) {
        if (i == 5) {
            printf("Recreating pl_dispatch to test the caching\n");
            size_t size = pl_dispatch_save(dp, NULL);
            REQUIRE(size);
            uint8_t *cache_data = malloc(size);
            REQUIRE(cache_data);
            REQUIRE_CMP(pl_dispatch_save(dp, cache_data), ==, size, "zu");

            pl_dispatch_destroy(&dp);
            dp = pl_dispatch_create(gpu->log, gpu);
            pl_dispatch_load(dp, cache_data);

            // Test to make sure the pass regenerates the same cache
            uint64_t hash = pl_str_hash((pl_str) { cache_data, size });
            REQUIRE_CMP(pl_dispatch_save(dp, NULL), ==, size, "zu");
            REQUIRE_CMP(pl_dispatch_save(dp, cache_data), ==, size, "zu");
            REQUIRE_CMP(pl_str_hash((pl_str) { cache_data, size }), ==, hash, PRIu64);
            free(cache_data);
        }

        sh = pl_dispatch_begin(dp);

        // For testing, force the use of CS if possible
        if (gpu->glsl.compute) {
            sh->type = SH_COMPUTE;
            sh->group_size[0] = 8;
            sh->group_size[1] = 8;
        }

        pl_shader_deband(sh, pl_sample_src( .tex = src ), pl_deband_params(
            .iterations     = 0,
            .grain          = 0.0,
        ));

        REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
            .shader = &sh,
            .target = fbo,
        }));
        TEST_FBO_PATTERN(1e-6, "deband iter %d", i);
    }

    pl_gpu_set_cache(gpu, NULL);
    pl_cache_destroy(&cache);

    // Test peak detection and readback if possible
    sh = pl_dispatch_begin(dp);
    pl_shader_sample_nearest(sh, pl_sample_src( .tex = src ));

    pl_shader_obj peak_state = NULL;
    struct pl_color_space csp_gamma22 = { .transfer = PL_COLOR_TRC_GAMMA22 };
    struct pl_peak_detect_params peak_params = { .minimum_peak = 0.01 };
    if (pl_shader_detect_peak(sh, csp_gamma22, &peak_state, &peak_params)) {
        REQUIRE(pl_dispatch_compute(dp, &(struct pl_dispatch_compute_params) {
            .shader = &sh,
            .width = fbo->params.w,
            .height = fbo->params.h,
        }));

        struct pl_hdr_metadata hdr;
        REQUIRE(pl_get_detected_hdr_metadata(peak_state, &hdr));

        float real_peak = 0, real_avg = 0;
        for (int y = 0; y < FBO_H; y++) {
            for (int x = 0; x < FBO_W; x++) {
                float *color = &src_data[(y * FBO_W + x) * 4];
                float luma = 0.212639f * powf(color[0], 2.2f) +
                             0.715169f * powf(color[1], 2.2f) +
                             0.072192f * powf(color[2], 2.2f);
                luma = pl_hdr_rescale(PL_HDR_NORM, PL_HDR_PQ, luma);
                real_peak = PL_MAX(real_peak, luma);
                real_avg += luma;
            }
        }
        real_avg = real_avg / (FBO_W * FBO_H);
        REQUIRE_FEQ(hdr.max_pq_y, real_peak, 1e-4);
        REQUIRE_FEQ(hdr.avg_pq_y, real_avg,  1e-3);
        const float full_peak = real_peak;
        const float full_avg = real_avg;
        const float full_scene_avg = hdr.scene_avg;
        const float full_scene_max = hdr.scene_max[0];

        // Restrict detection to the left half and verify that pixels outside
        // the crop contribute to neither the maximum nor the average.
        peak_params.analysis_crop = (pl_rect2df) { 0.0f, 0.0f, 0.5f, 1.0f };
        sh = pl_dispatch_begin(dp);
        pl_shader_sample_nearest(sh, pl_sample_src( .tex = src ));
        REQUIRE(pl_shader_detect_peak(sh, csp_gamma22, &peak_state, &peak_params));
        REQUIRE(pl_dispatch_compute(dp, &(struct pl_dispatch_compute_params) {
            .shader = &sh,
            .width = fbo->params.w,
            .height = fbo->params.h,
        }));
        REQUIRE(pl_get_detected_hdr_metadata(peak_state, &hdr));

        real_peak = 0;
        real_avg = 0;
        int crop_pixels = 0;
        float crop_scene_avg = 0, crop_scene_max = 0;
        for (int y = 0; y < FBO_H; y++) {
            for (int x = 0; x < FBO_W / 2; x++) {
                float *color = &src_data[(y * FBO_W + x) * 4];
                float luma = 0.212639f * powf(color[0], 2.2f) +
                             0.715169f * powf(color[1], 2.2f) +
                             0.072192f * powf(color[2], 2.2f);
                luma = pl_hdr_rescale(PL_HDR_NORM, PL_HDR_PQ, luma);
                real_peak = PL_MAX(real_peak, luma);
                real_avg += luma;
                const float max_rgb = PL_MAX(powf(color[0], 2.2f),
                    PL_MAX(powf(color[1], 2.2f), powf(color[2], 2.2f))) * PL_COLOR_SDR_WHITE;
                crop_scene_avg += max_rgb;
                crop_scene_max = PL_MAX(crop_scene_max, max_rgb);
                crop_pixels++;
            }
        }
        real_avg /= crop_pixels;
        REQUIRE_FEQ(hdr.scene_avg, crop_scene_avg / crop_pixels, 1.0);
        REQUIRE_FEQ(hdr.scene_max[0], crop_scene_max, 1.0);
        REQUIRE(hdr.scene_avg < full_scene_avg);
        REQUIRE(hdr.scene_max[0] <= full_scene_max);
        REQUIRE_FEQ(hdr.max_pq_y, real_peak, 1e-4);
        // The CPU reference omits the small decoded-RGB black-level
        // normalization performed by the shader, which is more visible for
        // this darker half of the test pattern.
        REQUIRE_FEQ(hdr.avg_pq_y, real_avg,  2e-3);
        printf("- peak analysis crop: full max/avg %.6f/%.6f, "
               "left-half detected max/avg %.6f/%.6f, reference %.6f/%.6f\n",
               full_peak, full_avg, hdr.max_pq_y, hdr.avg_pq_y,
               real_peak, real_avg);
    }

    pl_dispatch_abort(dp, &sh);
    pl_shader_obj_destroy(&peak_state);
    if (getenv("PL_TEST_PEAK_ANALYSIS_CROP_ONLY"))
        goto cleanup;

    // Dynamic target changes compressed HDR output, and toggling back must
    // restore the same output even when reusing the shader object/LUT cache.
    {
        pl_shader_obj tone_state = NULL;
        struct pl_color_space source = pl_color_space_hdr10;
        struct pl_color_space target = pl_color_space_hdr10;
        source.hdr.max_luma = 4000;
        source.hdr.scene_avg = 500;
        source.hdr.scene_max[0] = source.hdr.scene_max[1] = source.hdr.scene_max[2] = 4000;
        target.hdr.max_luma = 100;
        static float on_data[FBO_H * FBO_W * 4];
        static float off_data[FBO_H * FBO_W * 4];
        for (int iteration = 0; iteration < 3; iteration++) {
            struct pl_color_map_params map = pl_color_map_default_params;
            map.dynamic_target = iteration != 1;
            sh = pl_dispatch_begin(dp);
            pl_shader_sample_nearest(sh, pl_sample_src(.tex = src));
            pl_shader_color_map(sh, &map, source, target, &tone_state, false);
            REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(.shader = &sh, .target = fbo)));
            REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = fbo, .ptr = test_data)));
            for (int i = 0; i < PL_ARRAY_SIZE(test_data); i++) {
                REQUIRE(isfinite(test_data[i]));
                if (iteration == 0) on_data[i] = test_data[i];
                if (iteration == 1) off_data[i] = test_data[i];
                if (iteration == 2) REQUIRE_FEQ(test_data[i], on_data[i], 1e-5);
            }
        }
        float difference = 0;
        for (int i = 0; i < PL_ARRAY_SIZE(test_data); i++)
            difference = PL_MAX(difference, fabsf(on_data[i] - off_data[i]));
        REQUIRE(difference > 1e-4f);
        printf("- dynamic target on/off output difference: %f\n", difference);
        pl_shader_obj_destroy(&tone_state);
    }

    // VP comparison is opt-in. Original/custom/original must restore exact
    // output while reusing the original tone/gamut state.
    {
        pl_shader_obj tone_state = NULL;
        struct pl_color_space source = pl_color_space_hdr10;
        struct pl_color_space target = pl_color_space_hdr10;
        source.hdr.max_luma = 4000;
        source.hdr.scene_avg = 500;
        source.hdr.scene_max[0] = source.hdr.scene_max[1] = source.hdr.scene_max[2] = 4000;
        target.hdr.max_luma = 100;
        // Exercise feature extraction and contrast recovery in the A/B path.
        struct pl_tex_params feature_params = fbo->params;
        feature_params.sampleable = true;
        pl_tex feature = pl_tex_create(gpu, &feature_params);
        REQUIRE(feature);
        sh = pl_dispatch_begin(dp);
        pl_shader_sample_nearest(sh, pl_sample_src(.tex = src));
        pl_shader_extract_features(sh, source);
        REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(.shader = &sh, .target = feature)));
        REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = feature, .ptr = test_data)));
        for (int i = 0; i < FBO_H * FBO_W; i++) {
            REQUIRE(isfinite(test_data[4*i]) && test_data[4*i] >= 0 && test_data[4*i] <= 1);
            REQUIRE(test_data[4*i+1] == 0 && test_data[4*i+2] == 0);
        }
        static float on_data[FBO_H * FBO_W * 4];
        static float off_data[FBO_H * FBO_W * 4];
        for (int iteration = 0; iteration < 3; iteration++) {
            struct pl_color_map_params map = pl_color_map_default_params;
            map.vp_gamut_compression = iteration == 1;
            map.contrast_recovery = 0.3f;
            sh = pl_dispatch_begin(dp);
            pl_shader_sample_nearest(sh, pl_sample_src(.tex = src));
            pl_shader_color_map_ex(sh, &map, pl_color_map_args(
                .src = source, .dst = target, .state = &tone_state,
                .feature_map = feature));
            REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(.shader = &sh, .target = fbo)));
            REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = fbo, .ptr = test_data)));
            for (int i = 0; i < PL_ARRAY_SIZE(test_data); i++) {
                REQUIRE(isfinite(test_data[i]));
                if (iteration == 0) on_data[i] = test_data[i];
                if (iteration == 1) off_data[i] = test_data[i];
                if (iteration == 2) REQUIRE(test_data[i] == on_data[i]);
            }
        }
        float difference = 0;
        for (int i = 0; i < PL_ARRAY_SIZE(test_data); i++)
            difference = PL_MAX(difference, fabsf(on_data[i] - off_data[i]));
        REQUIRE(difference > 1e-4f);
        printf("- VP original/overflow-correction output difference: %f\n", difference);
        pl_shader_obj_destroy(&tone_state);
        pl_tex_destroy(gpu, &feature);
    }

    // Test film grain synthesis
    pl_shader_obj grain = NULL;
    struct pl_film_grain_params grain_params = {
        .tex = src,
        .components = 3,
        .component_mapping = { 0, 1, 2},
        .repr = &(struct pl_color_repr) {
            .sys = PL_COLOR_SYSTEM_BT_709,
            .levels = PL_COLOR_LEVELS_LIMITED,
            .bits = { .color_depth = 10, .sample_depth = 10 },
        },
    };

    for (int i = 0; i < 2; i++) {
        grain_params.data.type = PL_FILM_GRAIN_AV1;
        grain_params.data.params.av1 = av1_grain_data;
        grain_params.data.params.av1.overlap = !!i;
        grain_params.data.seed = rand();

        sh = pl_dispatch_begin(dp);
        pl_shader_film_grain(sh, &grain, &grain_params);
        REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
            .shader = &sh,
            .target = fbo,
        }));
    }

    if (gpu->glsl.compute) {
        grain_params.data.type = PL_FILM_GRAIN_H274;
        grain_params.data.params.h274 = h274_grain_data;
        grain_params.data.seed = rand();

        sh = pl_dispatch_begin(dp);
        pl_shader_film_grain(sh, &grain, &grain_params);
        REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
            .shader = &sh,
            .target = fbo,
        }));
    }
    pl_shader_obj_destroy(&grain);

    // Test custom shaders
    struct pl_custom_shader custom = {
        .prelude =
            "#extension GL_ARB_texture_gather : enable  \n"
            "#define INVERT invert                      \n",

        .header =
            "vec3 invert(vec3 color)            \n"
            "{                                  \n"
            "    return vec3(1.0) - color;      \n"
            "}                                  \n",

        .body =
            "color = vec4(gl_FragCoord.xy, 0.0, 1.0);   \n"
            "color.rgb = INVERT(color.rgb) + offset;    \n",

        .input = PL_SHADER_SIG_NONE,
        .output = PL_SHADER_SIG_COLOR,

        .num_variables = 1,
        .variables = &(struct pl_shader_var) {
            .var = pl_var_float("offset"),
            .data = &(float) { 0.1 },
        },
    };

    sh = pl_dispatch_begin(dp);
    REQUIRE(pl_shader_custom(sh, &custom));
    REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
        .shader = &sh,
        .target = fbo,
    }));

    // Test dolbyvision
    struct pl_color_repr repr = {
        .sys = PL_COLOR_SYSTEM_DOLBYVISION,
        .dovi = &dovi_meta,
    };

    sh = pl_dispatch_begin(dp);
    pl_shader_sample_direct(sh, pl_sample_src( .tex = src ));
    pl_shader_decode_color_ex(sh, pl_color_decode_args( .repr = &repr ));
    REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
        .shader = &sh,
        .target = fbo,
    }));

    // Test deinterlacing
    sh = pl_dispatch_begin(dp);
    pl_shader_deinterlace(sh, pl_deinterlace_source( .cur = pl_field_pair(src) ), NULL);
    REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(
        .shader = &sh,
        .target = fbo,
    )));

    // Test error diffusion
    if (fbo->params.storable) {
        for (int i = 0; i < pl_num_error_diffusion_kernels; i++) {
            const struct pl_error_diffusion_kernel *k = pl_error_diffusion_kernels[i];
            printf("- testing error diffusion kernel '%s'\n", k->name);
            sh = pl_dispatch_begin(dp);
            bool ok = pl_shader_error_diffusion(sh, pl_error_diffusion_params(
                .input_tex  = src,
                .output_tex = fbo,
                .new_depth  = 8,
                .kernel     = k,
            ));

            if (!ok) {
                fprintf(stderr, "kernel '%s' exceeds GPU limits, skipping...\n", k->name);
                continue;
            }

            REQUIRE(pl_dispatch_compute(dp, pl_dispatch_compute_params(
                .shader = &sh,
                .dispatch_size = {1, 1, 1},
            )));
        }
    }

cleanup:
    pl_dispatch_destroy(&dp);
    pl_tex_destroy(gpu, &src);
    pl_tex_destroy(gpu, &fbo);
}

static void pl_scaler_tests(pl_gpu gpu)
{
    pl_fmt src_fmt = pl_find_fmt(gpu, PL_FMT_FLOAT, 1, 16, 32, PL_FMT_CAP_LINEAR);
    pl_fmt fbo_fmt = pl_find_fmt(gpu, PL_FMT_FLOAT, 1, 16, 32, PL_FMT_CAP_RENDERABLE);
    if (!src_fmt || !fbo_fmt)
        return;
    printf("pl_scaler_tests:\n");

    float *fbo_data = NULL;
    pl_shader_obj lut = NULL;

    static float data_5x5[5][5] = {
        { 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0 },
        { 0, 0, 1, 0, 0 },
        { 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0 },
    };

    pl_tex dot5x5 = pl_tex_create(gpu, &(struct pl_tex_params) {
        .w              = 5,
        .h              = 5,
        .format         = src_fmt,
        .sampleable     = true,
        .initial_data   = &data_5x5[0][0],
    });

    struct pl_tex_params fbo_params = {
        .w              = 100,
        .h              = 100,
        .format         = fbo_fmt,
        .renderable     = true,
        .storable       = fbo_fmt->caps & PL_FMT_CAP_STORABLE,
        .host_readable  = fbo_fmt->caps & PL_FMT_CAP_HOST_READABLE,
    };

    pl_tex fbo = pl_tex_create(gpu, &fbo_params);
    pl_dispatch dp = pl_dispatch_create(gpu->log, gpu);
    if (!dot5x5 || !fbo || !dp)
        goto error;

    pl_shader sh = pl_dispatch_begin(dp);
    REQUIRE(pl_shader_sample_polar(sh,
        pl_sample_src(
            .tex        = dot5x5,
            .new_w      = fbo->params.w,
            .new_h      = fbo->params.h,
        ),
        pl_sample_filter_params(
            .filter     = pl_filter_ewa_lanczos,
            .lut        = &lut,
            .no_compute = !fbo->params.storable,
        )
    ));
    REQUIRE(pl_dispatch_finish(dp, &(struct pl_dispatch_params) {
        .shader = &sh,
        .target = fbo,
    }));

    if (fbo->params.host_readable) {
        fbo_data = malloc(fbo->params.w * fbo->params.h * sizeof(float));
        REQUIRE(pl_tex_download(gpu, &(struct pl_tex_transfer_params) {
            .tex            = fbo,
            .ptr            = fbo_data,
        }));

#ifdef PRINT_OUTPUT
        int max = 255;
        printf("P2\n%d %d\n%d\n", fbo->params.w, fbo->params.h, max);
        for (int y = 0; y < fbo->params.h; y++) {
            for (int x = 0; x < fbo->params.w; x++) {
                float v = fbo_data[y * fbo->params.h + x];
                printf("%d ", (int) round(fmin(fmax(v, 0.0), 1.0) * max));
            }
            printf("\n");
        }
#endif
    }

error:
    free(fbo_data);
    pl_shader_obj_destroy(&lut);
    pl_dispatch_destroy(&dp);
    pl_tex_destroy(gpu, &dot5x5);
    pl_tex_destroy(gpu, &fbo);
}

static const char *user_shader_tests[] = {
    // Test hooking, saving and loading
    "// Example of a comment at the beginning                               \n"
    "                                                                       \n"
    "//!HOOK NATIVE                                                         \n"
    "//!DESC upscale image                                                  \n"
    "//!BIND HOOKED                                                         \n"
    "//!WIDTH HOOKED.w 10 *                                                 \n"
    "//!HEIGHT HOOKED.h 10 *                                                \n"
    "//!SAVE NATIVEBIG                                                      \n"
    "//!WHEN NATIVE.w 500 <                                                 \n"
    "                                                                       \n"
    "vec4 hook()                                                            \n"
    "{                                                                      \n"
    "    return HOOKED_texOff(0);                                           \n"
    "}                                                                      \n"
    "                                                                       \n"
    "//!HOOK MAIN                                                           \n"
    "//!DESC downscale bigger image                                         \n"
    "//!WHEN NATIVE.w 500 <                                                 \n"
    "//!BIND NATIVEBIG                                                      \n"
    "                                                                       \n"
    "vec4 hook()                                                            \n"
    "{                                                                      \n"
    "    return NATIVEBIG_texOff(0);                                        \n"
    "}                                                                      \n",

    // Test use of textures
    "//!HOOK MAIN                                                           \n"
    "//!DESC turn everything into colorful pixels                           \n"
    "//!BIND HOOKED                                                         \n"
    "//!BIND DISCO                                                          \n"
    "//!COMPONENTS 3                                                        \n"
    "                                                                       \n"
    "vec4 hook()                                                            \n"
    "{                                                                      \n"
    "    return vec4(DISCO_tex(HOOKED_pos * 10.0).rgb, 1);                  \n"
    "}                                                                      \n"
    "                                                                       \n"
    "//!TEXTURE DISCO                                                       \n"
    "//!SIZE 3 3                                                            \n"
    "//!FORMAT rgba8                                                        \n"
    "//!FILTER NEAREST                                                      \n"
    "//!BORDER REPEAT                                                       \n"
    "ff0000ff00ff00ff0000ffff00ffffffff00ffffffff00ff4c4c4cff999999ffffffffff\n"

    // Test custom parameters
    "//!PARAM test                                                          \n"
    "//!DESC test parameter                                                 \n"
    "//!TYPE DYNAMIC float                                                  \n"
    "//!MINIMUM 0.0                                                         \n"
    "//!MAXIMUM 100.0                                                       \n"
    "1.0                                                                    \n"
    "                                                                       \n"
    "//!PARAM testconst                                                     \n"
    "//!TYPE CONSTANT uint                                                  \n"
    "//!MAXIMUM 16                                                          \n"
    "3                                                                      \n"
    "                                                                       \n"
    "//!PARAM testdefine                                                    \n"
    "//!TYPE DEFINE                                                         \n"
    "100                                                                    \n"
    "                                                                       \n"
    "//!PARAM testenum                                                      \n"
    "//!TYPE ENUM DEFINE                                                    \n"
    "FOO                                                                    \n"
    "BAR                                                                    \n"
    "                                                                       \n"
    "//!HOOK MAIN                                                           \n"
    "//!WHEN testconst 30 >                                                 \n"
    "#error should not be run                                               \n"
    "                                                                       \n"
    "//!HOOK MAIN                                                           \n"
    "//!WHEN testenum FOO =                                                 \n"
    "#if testenum == BAR                                                    \n"
    " #error bad                                                            \n"
    "#endif                                                                 \n"
    "vec4 hook() { return vec4(0.0); }                                      \n"
};

static const char *compute_shader_tests[] = {
    // Test use of storage/buffer resources
    "//!HOOK MAIN                                                           \n"
    "//!DESC attach some storage objects                                    \n"
    "//!BIND tex_storage                                                    \n"
    "//!BIND buf_uniform                                                    \n"
    "//!BIND buf_storage                                                    \n"
    "//!COMPONENTS 4                                                        \n"
    "                                                                       \n"
    "vec4 hook()                                                            \n"
    "{                                                                      \n"
    "    return vec4(foo, bar, bat);                                        \n"
    "}                                                                      \n"
    "                                                                       \n"
    "//!TEXTURE tex_storage                                                 \n"
    "//!SIZE 100 100                                                        \n"
    "//!FORMAT r32f                                                         \n"
    "//!STORAGE                                                             \n"
    "                                                                       \n"
    "//!BUFFER buf_uniform                                                  \n"
    "//!VAR float foo                                                       \n"
    "//!VAR float bar                                                       \n"
    "0000000000000000                                                       \n"
    "                                                                       \n"
    "//!BUFFER buf_storage                                                  \n"
    "//!VAR vec2 bat                                                        \n"
    "//!VAR int big[32];                                                    \n"
    "//!STORAGE                                                             \n",

};

static const char *test_luts[] = {

    "TITLE \"1D identity\"  \n"
    "LUT_1D_SIZE 2          \n"
    "0.0 0.0 0.0            \n"
    "1.0 1.0 1.0            \n",

    "TITLE \"3D identity\"  \n"
    "LUT_3D_SIZE 2          \n"
    "0.0 0.0 0.0            \n"
    "1.0 0.0 0.0            \n"
    "0.0 1.0 0.0            \n"
    "1.0 1.0 0.0            \n"
    "0.0 0.0 1.0            \n"
    "1.0 0.0 1.0            \n"
    "0.0 1.0 1.0            \n"
    "1.0 1.0 1.0            \n"

};

static bool frame_passthrough(pl_gpu gpu, pl_tex *tex,
                              const struct pl_source_frame *src, struct pl_frame *out_frame)
{
    const struct pl_frame *frame = src->frame_data;
    *out_frame = *frame;
    return true;
}

static enum pl_queue_status get_frame_ptr(struct pl_source_frame *out_frame,
                                          const struct pl_queue_params *qparams)
{
    const struct pl_source_frame **pframe = qparams->priv;
    if (!(*pframe)->frame_data)
        return PL_QUEUE_EOF;

    *out_frame = *(*pframe)++;
    return PL_QUEUE_OK;
}

static void render_info_cb(void *priv, const struct pl_render_info *info)
{
    REQUIRE(info->pass);
    REQUIRE(info->pass->shader->description);
}

static void pl_render_tests(pl_gpu gpu)
{
    pl_tex img_tex = NULL, fbo = NULL;
    pl_renderer rr = NULL;
    printf("pl_render_tests:\n");

    enum { width = 50, height = 50 };
    static float data[width][height];
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++)
            data[y][x] = RANDOM;
    }

    struct pl_plane img_plane = {0};
    struct pl_plane_data plane_data = {
        .type = PL_FMT_FLOAT,
        .width = width,
        .height = height,
        .component_size = { 8 * sizeof(float) },
        .component_map  = { 0 },
        .pixel_stride = sizeof(float),
        .pixels = data,
    };

    if (!pl_recreate_plane(gpu, NULL, &fbo, &plane_data))
        return;

    if (!pl_upload_plane(gpu, &img_plane, &img_tex, &plane_data))
        goto error;

    rr = pl_renderer_create(gpu->log, gpu);
    pl_tex_clear_ex(gpu, fbo, (union pl_clear_color){0});

    struct pl_frame image = {
        .num_planes     = 1,
        .planes         = { img_plane },
        .repr = {
            .sys        = PL_COLOR_SYSTEM_BT_709,
            .levels     = PL_COLOR_LEVELS_FULL,
        },
        .color          = pl_color_space_srgb,
    };

    struct pl_frame target = {
        .num_planes     = 1,
        .planes         = {{
            .texture            = fbo,
            .components         = 3,
            .component_mapping  = {0, 1, 2},
        }},
        .repr = {
            .sys        = PL_COLOR_SYSTEM_RGB,
            .levels     = PL_COLOR_LEVELS_FULL,
            .bits.color_depth = 32,
        },
        .color          = pl_color_space_srgb,
    };

    REQUIRE(pl_render_image(rr, &image, &target, NULL));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

    // TODO: embed a reference texture and ensure it matches

    // Test a bunch of different params
#define TEST(SNAME, STYPE, DEFAULT, FIELD, LIMIT)                       \
    do {                                                                \
        for (int i = 0; i <= LIMIT; i++) {                              \
            printf("- testing `" #STYPE "." #FIELD " = %d`\n", i);        \
            struct pl_render_params params = pl_render_default_params;  \
            params.force_dither = true;                                 \
            struct STYPE tmp = DEFAULT;                                 \
            tmp.FIELD = i;                                              \
            params.SNAME = &tmp;                                        \
            REQUIRE(pl_render_image(rr, &image, &target, &params));     \
            pl_gpu_flush(gpu);                                          \
            REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE); \
        }                                                               \
    } while (0)

#define TEST_PARAMS(NAME, FIELD, LIMIT) \
    TEST(NAME##_params, pl_##NAME##_params, pl_##NAME##_default_params, FIELD, LIMIT)

    image.crop.x1 = width / 2.0;
    image.crop.y1 = height / 2.0;
    for (int i = 0; i < pl_num_scale_filters; i++) {
        struct pl_render_params params = pl_render_default_params;
        params.upscaler = pl_scale_filters[i].filter;
        printf("- testing `params.upscaler = /* %s */`\n", pl_scale_filters[i].name);
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        pl_gpu_flush(gpu);
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    }
    image.crop.x1 = image.crop.y1 = 0;

    target.crop.x1 = width / 2.0;
    target.crop.y1 = height / 2.0;
    for (int i = 0; i < pl_num_scale_filters; i++) {
        struct pl_render_params params = pl_render_default_params;
        params.downscaler = pl_scale_filters[i].filter;
        printf("- testing `params.downscaler = /* %s */`\n", pl_scale_filters[i].name);
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        pl_gpu_flush(gpu);
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    }
    target.crop.x1 = target.crop.y1 = 0;

    TEST_PARAMS(deband, iterations, 3);
    TEST_PARAMS(sigmoid, center, 1);
    TEST_PARAMS(color_map, intent, PL_INTENT_ABSOLUTE_COLORIMETRIC);
    TEST_PARAMS(dither, method, PL_DITHER_WHITE_NOISE);
    TEST_PARAMS(dither, temporal, true);
    TEST_PARAMS(distort, alpha_mode, PL_ALPHA_INDEPENDENT);
    TEST_PARAMS(distort, constrain, true);
    TEST_PARAMS(distort, bicubic, true);
    TEST(cone_params, pl_cone_params, pl_vision_deuteranomaly, strength, 0);

    // Test gamma-correct dithering
    target.repr.bits.color_depth = 2;
    TEST_PARAMS(dither, transfer, PL_COLOR_TRC_GAMMA22);
    target.repr.bits.color_depth = 32;

    // Test dithering with dynamic constants, which must leave the step count
    // a constant expression
    struct pl_render_params dyn_params = pl_render_default_params;
    dyn_params.force_dither = true;
    dyn_params.dynamic_constants = true;
    REQUIRE(pl_render_image(rr, &image, &target, &dyn_params));
    pl_gpu_flush(gpu);
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

    // Test HDR tone mapping
    image.color = pl_color_space_hdr10;
    TEST_PARAMS(color_map, visualize_lut, true);
    if (gpu->limits.max_ssbo_size)
        TEST_PARAMS(peak_detect, allow_delayed, true);

    // Test inverse tone-mapping and pure BPC
    image.color.hdr.max_luma = 1000;
    target.color.hdr.max_luma = 4000;
    target.color.hdr.min_luma = 0.02;
    TEST_PARAMS(color_map, inverse_tone_mapping, true);

    image.color = pl_color_space_srgb;
    target.color = pl_color_space_srgb;

    // Test some misc stuff
    struct pl_render_params params = pl_render_default_params;
    params.color_adjustment = &(struct pl_color_adjustment) {
        .brightness = 0.1,
        .contrast = 0.9,
        .saturation = 1.5,
        .gamma = 0.8,
        .temperature = 0.3,
    };
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    params = pl_render_default_params;

    struct pl_frame inferred_image = image, inferred_target = target;
    pl_frames_infer(rr, &inferred_image, &inferred_target);
    REQUIRE(pl_render_image(rr, &inferred_image, &inferred_target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

    // Test background blending and alpha transparency
    params.blend_against_tiles = true;
    params.corner_rounding = 0.25f;
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    params = pl_render_default_params;

    // Test film grain synthesis
    image.film_grain.type = PL_FILM_GRAIN_AV1;
    image.film_grain.params.av1 = av1_grain_data;
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

    image.film_grain.type = PL_FILM_GRAIN_H274;
    image.film_grain.params.h274 = h274_grain_data;
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    // H.274 film grain synthesis requires compute shaders
    if (gpu->glsl.compute) {
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    } else {
        const struct pl_render_errors rr_err = pl_renderer_get_errors(rr);
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_FILM_GRAIN);
        pl_renderer_reset_errors(rr, &rr_err);
    }
    image.film_grain = (struct pl_film_grain_data) {0};

    // Test mpv-style custom shaders
    for (int i = 0; i < PL_ARRAY_SIZE(user_shader_tests); i++) {
        printf("- testing user shader:\n\n%s\n", user_shader_tests[i]);
        const struct pl_hook *hook;
        hook = pl_mpv_user_shader_parse(gpu, user_shader_tests[i],
                                        strlen(user_shader_tests[i]));
        REQUIRE(hook);

        params.hooks = &hook;
        params.num_hooks = 1;
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

        pl_mpv_user_shader_destroy(&hook);
    }

    if (gpu->glsl.compute && gpu->limits.max_ssbo_size) {
        for (int i = 0; i < PL_ARRAY_SIZE(compute_shader_tests); i++) {
            printf("- testing user shader:\n\n%s\n", compute_shader_tests[i]);
            const struct pl_hook *hook;
            hook = pl_mpv_user_shader_parse(gpu, compute_shader_tests[i],
                                            strlen(compute_shader_tests[i]));
            REQUIRE(hook);

            params.hooks = &hook;
            params.num_hooks = 1;
            REQUIRE(pl_render_image(rr, &image, &target, &params));
            REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

            pl_mpv_user_shader_destroy(&hook);
        }
    }
    params = pl_render_default_params;

    // Test custom LUTs
    for (int i = 0; i < PL_ARRAY_SIZE(test_luts); i++) {
        printf("- testing custom lut %d\n", i);
        struct pl_custom_lut *lut;
        lut = pl_lut_parse_cube(gpu->log, test_luts[i], strlen(test_luts[i]));
        REQUIRE(lut);

        bool has_3dlut = gpu->limits.max_tex_3d_dim && gpu->glsl.version > 100;
        if (lut->size[2] && !has_3dlut) {
            pl_lut_free(&lut);
            continue;
        }

        // Test all three at the same time to reduce the number of tests
        image.lut = target.lut = params.lut = lut;

        for (enum pl_lut_type t = PL_LUT_UNKNOWN; t <= PL_LUT_CONVERSION; t++) {
            printf("- testing LUT method %d\n", t);
            image.lut_type = target.lut_type = params.lut_type = t;
            REQUIRE(pl_render_image(rr, &image, &target, &params));
            REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
        }

        image.lut = target.lut = params.lut = NULL;
        pl_lut_free(&lut);
    }

#ifdef PL_HAVE_LCMS

    // It doesn't fit without use of 3D textures on GLES2
    if (gpu->glsl.version > 100) {
        // Test ICC profiles
        image.profile = TEST_PROFILE(sRGB_v2_nano_icc);
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
        image.profile = (struct pl_icc_profile) {0};

        target.profile = TEST_PROFILE(sRGB_v2_nano_icc);
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
        target.profile = (struct pl_icc_profile) {0};

        image.profile = TEST_PROFILE(sRGB_v2_nano_icc);
        target.profile = image.profile;
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
        image.profile = (struct pl_icc_profile) {0};
        target.profile = (struct pl_icc_profile) {0};
    }

#endif

    // Test overlays
    image.num_overlays = 1;
    image.overlays = &(struct pl_overlay) {
        .tex = img_plane.texture,
        .mode = PL_OVERLAY_NORMAL,
        .num_parts = 2,
        .parts = (struct pl_overlay_part[]) {{
            .src = {0, 0, 2, 2},
            .dst = {30, 100, 40, 200},
        }, {
            .src = {2, 2, 5, 5},
            .dst = {1000, -1, 3, 5},
        }},
    };
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    params.disable_fbos = true;
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    image.num_overlays = 0;
    params = pl_render_default_params;

    target.num_overlays = 1;
    target.overlays = &(struct pl_overlay) {
        .tex = img_plane.texture,
        .mode = PL_OVERLAY_MONOCHROME,
        .num_parts = 1,
        .parts = &(struct pl_overlay_part) {
            .src = {5, 5, 15, 15},
            .dst = {5, 5, 15, 15},
            .color = {1.0, 0.5, 0.0},
        },
    };
    REQUIRE(pl_render_image(rr, &image, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    REQUIRE(pl_render_image(rr, NULL, &target, &params));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    target.num_overlays = 0;

    // Test rotation
    for (pl_rotation rot = 0; rot < PL_ROTATION_360; rot += PL_ROTATION_90) {
        image.rotation = rot;
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
    }

    // Attempt frame mixing, using the mixer queue helper
    printf("- testing frame mixing\n");
    struct pl_render_params mix_params = {
        .frame_mixer = &pl_filter_mitchell_clamp,
        .info_callback = render_info_cb,
    };

    struct pl_queue_params qparams = {
        .radius = pl_frame_mix_radius(&mix_params),
        .vsync_duration = 1.0 / 60.0,
    };

    // Test large PTS jumps in frame mix
    struct pl_frame_mix mix = (struct pl_frame_mix) {
        .num_frames = 2,
        .frames = (const struct pl_frame *[]) { &image, &image },
        .signatures = (uint64_t[]) { 0xFFF1, 0xFFF2 },
        .timestamps = (double[]) { -100, 100 },
        .vsync_duration = 1.6,
    };
    REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));

    // Test inferring frame mix
    inferred_target = target;
    pl_frames_infer_mix(rr, &mix, &inferred_target, &inferred_image);
    REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));

    // Test empty frame mix
    mix = (struct pl_frame_mix) {0};
    REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));

    // Test inferring empty frame mix
    inferred_target = target;
    pl_frames_infer_mix(rr, &mix, &inferred_target, &inferred_image);
    REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));

    // Test mixer queue
#define NUM_MIX_FRAMES 20
    const float frame_duration = 1.0 / 24.0;
    struct pl_source_frame srcframes[NUM_MIX_FRAMES+1];
    srcframes[NUM_MIX_FRAMES] = (struct pl_source_frame) {0};
    for (int i = 0; i < NUM_MIX_FRAMES; i++) {
        srcframes[i] = (struct pl_source_frame) {
            .pts = i * frame_duration,
            .duration = frame_duration,
            .map = frame_passthrough,
            .frame_data = &image,
        };
    }

    pl_queue queue = pl_queue_create(gpu);
    enum pl_queue_status ret;

    // Test pre-pushing all frames, with delayed EOF.
    for (int i = 0; i < NUM_MIX_FRAMES; i++) {
        const struct pl_source_frame *src = &srcframes[i];
        if (i > 10) // test pushing in reverse order
            src = &srcframes[NUM_MIX_FRAMES + 10 - i];
        if (!pl_queue_push_block(queue, 1, src)) // mini-sleep
            pl_queue_push(queue, src); // push it anyway, for testing
    }

    while ((ret = pl_queue_update(queue, &mix, &qparams)) != PL_QUEUE_EOF) {
        if (ret == PL_QUEUE_MORE) {
            REQUIRE_CMP(qparams.pts, >, 0.0f, "f");
            pl_queue_push(queue, NULL); // push delayed EOF
            continue;
        }

        REQUIRE_CMP(ret, ==, PL_QUEUE_OK, "u");
        REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));

        // Simulate advancing vsync
        qparams.pts += qparams.vsync_duration;
    }

    // Test dynamically pulling all frames, with oversample mixer
    const struct pl_source_frame *frame_ptr = &srcframes[0];
    mix_params.frame_mixer = &pl_oversample_frame_mixer;

    qparams = (struct pl_queue_params) {
        .radius = pl_frame_mix_radius(&mix_params),
        .vsync_duration = qparams.vsync_duration,
        .get_frame = get_frame_ptr,
        .priv = &frame_ptr,
    };

    pl_queue_reset(queue);
    while ((ret = pl_queue_update(queue, &mix, &qparams)) != PL_QUEUE_EOF) {
        REQUIRE_CMP(ret, ==, PL_QUEUE_OK, "u");
        REQUIRE_CMP(mix.num_frames, <=, 2, "d");
        REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));
        qparams.pts += qparams.vsync_duration;
    }

    // Test large PTS jump
    pl_queue_reset(queue);
    REQUIRE(pl_queue_update(queue, &mix, &qparams) == PL_QUEUE_EOF);

    // Test that advancing without a mix still reports missing frames
    const struct pl_filter_config *mixers[] = {
        &pl_oversample_frame_mixer, &pl_filter_mitchell_clamp,
    };
    for (int m = 0; m < PL_ARRAY_SIZE(mixers); m++) {
        mix_params.frame_mixer = mixers[m];
        qparams = (struct pl_queue_params) {
            .radius = pl_frame_mix_radius(&mix_params),
            .vsync_duration = qparams.vsync_duration,
        };

        pl_queue_reset(queue);
        for (int i = 0; i < 4; i++)
            pl_queue_push(queue, &srcframes[i]);
        REQUIRE_CMP(pl_queue_update(queue, NULL, &qparams), ==, PL_QUEUE_OK, "u");
        qparams.pts = 3.5 * frame_duration;
        REQUIRE_CMP(pl_queue_update(queue, NULL, &qparams), ==, PL_QUEUE_MORE, "u");
    }

    // Test deinterlacing
    pl_queue_reset(queue);
    printf("- testing deinterlacing\n");
    for (int i = 0; i < NUM_MIX_FRAMES; i++) {
        struct pl_source_frame *src = &srcframes[i];
        if (i > 10)
            src = &srcframes[NUM_MIX_FRAMES + 10 - i];
        src->first_field = PL_FIELD_EVEN;
        pl_queue_push(queue, src);
    }
    pl_queue_push(queue, NULL);

    qparams.pts = 0;
    qparams.get_frame = NULL;
    while ((ret = pl_queue_update(queue, &mix, &qparams)) != PL_QUEUE_EOF) {
        REQUIRE_CMP(ret, ==, PL_QUEUE_OK, "u");
        REQUIRE(pl_render_image_mix(rr, &mix, &target, &mix_params));
        qparams.pts += qparams.vsync_duration;
    }

    pl_queue_destroy(&queue);

error:
    pl_renderer_destroy(&rr);
    pl_tex_destroy(gpu, &img_tex);
    pl_tex_destroy(gpu, &fbo);
}

// Tests for the bit encoding logic, in both directions:
//  - encoding MSB-aligned output (e.g. P010) must produce the same value as
//    the LSB-aligned equivalent (e.g. yuv420p10), with zero padding bits
//  - decoding must survive a mismatch between the sample depth and the color
//    depth, for any way of padding the color samples into the texture
static void pl_render_bits_tests(pl_gpu gpu)
{
    pl_renderer rr = NULL;
    pl_dispatch dp = NULL;
    pl_tex src_tex = NULL, lsb_tex = NULL, msb_tex = NULL, fbo_tex = NULL;
    printf("pl_render_bits_tests:\n");

    // Need a true 16-bit UNORM render target we can read back bit-exactly
    pl_fmt fmt = pl_find_fmt(gpu, PL_FMT_UNORM, 4, 16, 16,
                             PL_FMT_CAP_RENDERABLE | PL_FMT_CAP_HOST_READABLE);
    if (!fmt || fmt->component_depth[0] != 16) {
        printf("- no suitable 16-bit UNORM format, skipping\n");
        return;
    }

    enum { width = 64, height = 64 };

    static uint16_t src_data[height][width][4];
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            uint16_t v = (uint16_t) ((x + y * width) * 0xFFFFu / (width * height - 1));
            for (int c = 0; c < 4; c++)
                src_data[y][x][c] = v;
        }
    }

    struct pl_plane src_plane = {0};
    struct pl_plane_data src_pdata = {
        .type           = PL_FMT_UNORM,
        .width          = width,
        .height         = height,
        .component_size = { 16, 16, 16, 16 },
        .component_map  = { 0, 1, 2, 3 },
        .pixel_stride   = 4 * sizeof(uint16_t),
        .pixels         = src_data,
    };
    if (!pl_upload_plane(gpu, &src_plane, &src_tex, &src_pdata))
        goto error;

    lsb_tex = pl_tex_create(gpu, pl_tex_params(
        .w = width, .h = height, .format = fmt,
        .renderable = true, .host_readable = true,
    ));
    msb_tex = pl_tex_create(gpu, pl_tex_params(
        .w = width, .h = height, .format = fmt,
        .renderable = true, .host_readable = true,
    ));
    REQUIRE(lsb_tex);
    REQUIRE(msb_tex);

    rr = pl_renderer_create(gpu->log, gpu);
    REQUIRE(rr);

    struct pl_frame image = {
        .num_planes = 1,
        .planes     = { src_plane },
        .repr       = pl_color_repr_rgb,
        .color      = pl_color_space_srgb,
    };

    struct pl_frame target = {
        .num_planes = 1,
        .planes     = {{
            .components        = 3,
            .component_mapping = {0, 1, 2},
        }},
        .repr = {
            .sys    = PL_COLOR_SYSTEM_BT_2020_NC,
            .levels = PL_COLOR_LEVELS_LIMITED,
            .bits   = { .sample_depth = 16, .color_depth = 10 },
        },
        .color = pl_color_space_srgb,
    };

    static uint16_t lsb_out[height][width][4];
    static uint16_t msb_out[height][width][4];

    // Dithering puts both encodings on the same 10-bit grid, so they must match
    // exactly.
    for (int dither = 1; dither >= 0; dither--) {
        struct pl_render_params params = pl_render_default_params;
        if (!dither)
            params.dither_params = NULL;

        target.planes[0].texture = lsb_tex;
        target.repr.bits.bit_shift = 0;
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

        target.planes[0].texture = msb_tex;
        target.repr.bits.bit_shift = 6;
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

        REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = lsb_tex, .ptr = lsb_out)));
        REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = msb_tex, .ptr = msb_out)));

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                for (int c = 0; c < 3; c++) {
                    int lsb = lsb_out[y][x][c];
                    int msb = msb_out[y][x][c];
                    REQUIRE_CMP(lsb, <=, 0x3FF, "d");    // fits in 10 bits
                    REQUIRE_CMP(msb & 0x3F, ==, 0, "d"); // padding bits are zero
                    if (dither)
                        REQUIRE_CMP(msb >> 6, ==, lsb, "d");
                }
            }
        }
    }

    // Dithering must land a flat gray on its exact code on average, and the
    // chroma on the neutral code, with the codes shifted up in the texture,
    // where their grid is not 2^depth - 1 steps. Error diffusion goes through
    // a 16-bit float FBO, which only holds 8-bit codes exactly enough.
    static const struct {
        int depth;
        const struct pl_error_diffusion_kernel *error_diffusion;
        double tolerance;
    } modes[] = {
        { 10, NULL, 0.02 },
        {  8, &pl_error_diffusion_sierra_lite, 0.2 },
    };

    const uint16_t gray = 0.6f * 0xFFFF;
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            for (int c = 0; c < 4; c++)
                src_data[y][x][c] = c < 3 ? gray : 0xFFFF;
        }
    }
    REQUIRE(pl_tex_upload(gpu, pl_tex_transfer_params(.tex = src_tex, .ptr = src_data)));
    target.planes[0].texture = msb_tex;

    for (int m = 0; m < PL_ARRAY_SIZE(modes); m++) {
        const int depth = modes[m].depth, shift = 16 - depth;
        struct pl_render_params params = pl_render_default_params;
        params.error_diffusion = modes[m].error_diffusion;
        target.repr.bits.color_depth = depth;
        target.repr.bits.bit_shift = shift;
        REQUIRE(pl_render_image(rr, &image, &target, &params));
        REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
        REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = msb_tex, .ptr = msb_out)));

        // Limited range luma and neutral chroma, at `depth` bits
        const double code[3] = {
            (16 + 219 * (gray / 65535.0)) * (1 << (depth - 8)),
            1 << (depth - 1),
            1 << (depth - 1),
        };
        for (int c = 0; c < 3; c++) {
            double error = 0.0;
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++)
                    error += (msb_out[y][x][c] >> shift) - code[c];
            }
            REQUIRE_CMP(fabs(error / (width * height)), <, modes[m].tolerance, "f");
        }
    }

    // The decode path has to survive a mismatch between the sample depth and
    // the color depth: neutral chroma must stay an exact grayscale, and the
    // nominal luma range must keep mapping onto exactly [0, 1], no matter how
    // the color samples are padded into the texture.
    pl_fmt f32 = pl_find_fmt(gpu, PL_FMT_FLOAT, 4, 32, 32,
                             PL_FMT_CAP_RENDERABLE | PL_FMT_CAP_HOST_READABLE);
    if (!f32 || !(fmt->caps & PL_FMT_CAP_SAMPLEABLE)) {
        printf("- no suitable f32 fmt, skipping decode tests\n");
        goto error;
    }

    dp = pl_dispatch_create(gpu->log, gpu);
    REQUIRE(dp);

    // Luma test points, as a fraction of the nominal luma range
    static const float points[] = { 0.0, 0.25, 0.5, 0.75, 1.0 };
    enum { num_points = PL_ARRAY_SIZE(points) };

    pl_tex_destroy(gpu, &src_tex);
    src_tex = pl_tex_create(gpu, pl_tex_params(
        .w = num_points, .h = 1, .format = fmt,
        .sampleable = true, .host_writable = true,
    ));

    fbo_tex = pl_tex_create(gpu, pl_tex_params(
        .w = num_points, .h = 1, .format = f32,
        .renderable = true, .host_readable = true,
    ));
    if (!fbo_tex)
        goto error;

    static const struct { int color_depth, bit_shift; } encodings[] = {
        { 16, 0 }, // control: no padding at all
        { 12, 0 }, // 12-bit LSB-aligned
        { 12, 4 }, // 12-bit MSB-aligned (e.g. xyz12)
        { 10, 0 }, // 10-bit LSB-aligned
        {  8, 0 }, //  8-bit reference
    };

    for (int e = 0; e < PL_ARRAY_SIZE(encodings); e++) {
        const int col = encodings[e].color_depth;
        const int shift = encodings[e].bit_shift;

        for (int l = 0; l < 2; l++) {
            const enum pl_color_levels levels = l ? PL_COLOR_LEVELS_FULL
                                                  : PL_COLOR_LEVELS_LIMITED;
            const struct pl_color_repr repr0 = {
                .sys    = PL_COLOR_SYSTEM_BT_709,
                .levels = levels,
                .bits   = {
                    .sample_depth = 16,
                    .color_depth  = col,
                    .bit_shift    = shift,
                },
            };
            struct pl_color_repr repr = repr0;

            // Nominal luma range and neutral chroma point, at `col` bits
            const int ylo = levels == PL_COLOR_LEVELS_LIMITED ?  16 << (col - 8) : 0;
            const int yhi = levels == PL_COLOR_LEVELS_LIMITED ? 235 << (col - 8)
                                                              : (1 << col) - 1;
            const int neutral = 1 << (col - 1);

            uint16_t data[num_points][4];
            float expected[num_points];
            for (int i = 0; i < num_points; i++) {
                // Derive the expectation from the rounded code, not from the
                // fraction, so that the test pins the exact mapping
                const int luma = roundf(ylo + points[i] * (yhi - ylo));
                expected[i] = (float) (luma - ylo) / (yhi - ylo);
                data[i][0] = luma    << shift;
                data[i][1] = neutral << shift;
                data[i][2] = neutral << shift;
                data[i][3] = 0xFFFF;
            }

            REQUIRE(pl_tex_upload(gpu, pl_tex_transfer_params(
                .tex = src_tex,
                .ptr = data,
            )));

            pl_shader sh = pl_dispatch_begin(dp);
            pl_shader_sample_direct(sh, pl_sample_src( .tex = src_tex ));
            pl_shader_decode_color_ex(sh, pl_color_decode_args( .repr = &repr ));
            REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(
                .shader = &sh,
                .target = fbo_tex,
            )));

            float out[num_points][4];
            REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(
                .tex = fbo_tex,
                .ptr = out,
            )));

            printf("- %s range, color_depth=%d bit_shift=%d\n",
                   levels == PL_COLOR_LEVELS_FULL ? "full" : "limited",
                   col, shift);

            for (int i = 0; i < num_points; i++) {
                const float r = out[i][0], g = out[i][1], b = out[i][2];
                REQUIRE_FEQ(g, expected[i], 1e-6);
                REQUIRE_FEQ(r, g, 1e-6);
                REQUIRE_FEQ(r, b, 1e-6);
            }

            // The same through the renderer, which normalizes the planes
            // before the decode, and makes up the neutral chroma of a
            // luma-only image itself
            for (int luma_only = 0; luma_only < 2; luma_only++) {
                struct pl_frame src_frame = {
                    .num_planes = 1,
                    .planes = {{
                        .texture           = src_tex,
                        .components        = luma_only ? 1 : 3,
                        .component_mapping = {0, 1, 2},
                    }},
                    .repr  = repr0,
                    .color = pl_color_space_bt709,
                };
                struct pl_frame dst_frame = {
                    .num_planes = 1,
                    .planes = {{
                        .texture           = fbo_tex,
                        .components        = 3,
                        .component_mapping = {0, 1, 2},
                    }},
                    .repr  = pl_color_repr_rgb,
                    .color = pl_color_space_bt709,
                };
                struct pl_render_params params = pl_render_default_params;
                params.dither_params = NULL;
                REQUIRE(pl_render_image(rr, &src_frame, &dst_frame, &params));
                REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
                REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(
                    .tex = fbo_tex,
                    .ptr = out,
                )));

                for (int i = 0; i < num_points; i++) {
                    const float r = out[i][0], g = out[i][1], b = out[i][2];
                    REQUIRE_FEQ(g, expected[i], 1e-6);
                    REQUIRE_FEQ(r, g, 1e-6);
                    REQUIRE_FEQ(r, b, 1e-6);
                }
            }
        }
    }

error:
    pl_dispatch_destroy(&dp);
    pl_renderer_destroy(&rr);
    pl_tex_destroy(gpu, &src_tex);
    pl_tex_destroy(gpu, &lsb_tex);
    pl_tex_destroy(gpu, &msb_tex);
    pl_tex_destroy(gpu, &fbo_tex);
}

// The deband grain is relative to the reference white of the image. An SDR
// signal peaks at its white, whatever luminance that is tagged with, so the
// grain must not depend on it. An HDR signal gets the grain scaled down by its
// peak relative to the reference white.
static void pl_render_deband_tests(pl_gpu gpu)
{
    pl_renderer rr = NULL;
    pl_tex src_tex = NULL, fbo = NULL;
    printf("pl_render_deband_tests:\n");

    pl_fmt fmt = pl_find_fmt(gpu, PL_FMT_FLOAT, 4, 32, 32,
                             PL_FMT_CAP_RENDERABLE | PL_FMT_CAP_HOST_READABLE);
    if (!fmt) {
        printf("- no suitable f32 fmt, skipping\n");
        return;
    }

    enum { width = 64, height = 64 };
    static const float gray = 0.5f;

    // No alpha, the image is not to be blended against anything
    static float src_data[height][width][4];
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            for (int c = 0; c < 3; c++)
                src_data[y][x][c] = gray;
        }
    }

    struct pl_plane src_plane = {0};
    struct pl_plane_data src_pdata = {
        .type           = PL_FMT_FLOAT,
        .width          = width,
        .height         = height,
        .component_size = { 32, 32, 32 },
        .component_map  = { 0, 1, 2 },
        .pixel_stride   = 4 * sizeof(float),
        .pixels         = src_data,
    };
    if (!pl_upload_plane(gpu, &src_plane, &src_tex, &src_pdata))
        goto error;

    fbo = pl_tex_create(gpu, pl_tex_params(
        .w = width, .h = height, .format = fmt,
        .renderable = true, .host_readable = true,
    ));
    if (!fbo)
        goto error;

    rr = pl_renderer_create(gpu->log, gpu);
    REQUIRE(rr);

    static const struct {
        enum pl_color_transfer trc;
        float image_luma, target_luma;  // tagged peak in cd/m^2, 0 if untagged
        float scale;                    // expected grain, 1 is the configured one
    } tests[] = {
        { PL_COLOR_TRC_SRGB,       0,    0, 1.0f },
        { PL_COLOR_TRC_SRGB,       0,  100, 1.0f },
        { PL_COLOR_TRC_SRGB,      80,    0, 1.0f },
        { PL_COLOR_TRC_SRGB,     480,  480, 1.0f },
        { PL_COLOR_TRC_BT_1886,  100,    0, 1.0f },
        { PL_COLOR_TRC_GAMMA22,  300,  300, 1.0f },
        { PL_COLOR_TRC_LINEAR,    80,    0, 1.0f },
        { PL_COLOR_TRC_PQ,         0,    0, PL_COLOR_SDR_WHITE / 10000 },
        { PL_COLOR_TRC_PQ,      1000, 1000, PL_COLOR_SDR_WHITE / 1000 },
        { PL_COLOR_TRC_HLG,        0,    0, PL_COLOR_SDR_WHITE / PL_COLOR_HLG_PEAK },
        { PL_COLOR_TRC_HLG,      400,  400, PL_COLOR_SDR_WHITE / 400 },
    };

    // Peak to peak amplitude of the grain. The grain is configured to come
    // out the same in every test, so that they are equally precise.
    static const float amplitude = 0.2f;

    for (int i = 0; i < PL_ARRAY_SIZE(tests); i++) {
        struct pl_frame image = {
            .num_planes = 1,
            .planes     = { src_plane },
            .repr       = pl_color_repr_rgb,
            .color      = {
                .primaries    = PL_COLOR_PRIM_BT_709,
                .transfer     = tests[i].trc,
                .hdr.max_luma = tests[i].image_luma,
            },
        };

        // Same color space, to get the image out the way it went in
        struct pl_frame target = {
            .num_planes = 1,
            .planes     = {{
                .texture           = fbo,
                .components        = 3,
                .component_mapping = {0, 1, 2},
            }},
            .repr       = pl_color_repr_rgb,
            .color      = image.color,
        };
        target.color.hdr.max_luma = tests[i].target_luma;

        struct pl_deband_params deband = pl_deband_default_params;
        deband.grain = 1000 * amplitude / tests[i].scale;

        printf("- %s image at %g cd/m^2, target at %g cd/m^2\n",
               pl_color_transfer_name(tests[i].trc), tests[i].image_luma,
               tests[i].target_luma);

        static float out[height][width][4];
        for (int grain = 0; grain < 2; grain++) {
            struct pl_render_params params = {
                .deband_params = grain ? &deband : NULL,
            };
            REQUIRE(pl_render_image(rr, &image, &target, &params));
            REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);
            REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(
                .tex = fbo,
                .ptr = out,
            )));

            float min = gray, max = gray;
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    for (int c = 0; c < 3; c++) {
                        REQUIRE(isfinite(out[y][x][c]));
                        min = PL_MIN(min, out[y][x][c]);
                        max = PL_MAX(max, out[y][x][c]);
                    }
                }
            }

            if (grain) {
                REQUIRE_FEQ((max - min) / amplitude, 1.0, 1e-2);
            } else {
                REQUIRE_FEQ(min, gray, 1e-6);
                REQUIRE_FEQ(max, gray, 1e-6);
            }
        }
    }

error:
    pl_renderer_destroy(&rr);
    pl_tex_destroy(gpu, &src_tex);
    pl_tex_destroy(gpu, &fbo);
}

static struct pl_hook_res noop_hook(void *priv, const struct pl_hook_params *params)
{
    return (struct pl_hook_res) {0};
}

static void pl_ycbcr_tests(pl_gpu gpu)
{
    const int depth = 16;
    struct pl_plane_data data[3];
    for (int i = 0; i < 3; i++) {
        const int sub = i > 0 ? 1 : 0;
        const int width = (323 + sub) >> sub;
        const int height = (255 + sub) >> sub;

        data[i] = (struct pl_plane_data) {
            .type = PL_FMT_UNORM,
            .width = width,
            .height = height,
            .component_size = {depth},
            .component_map = {i},
            .pixel_stride = sizeof(uint16_t),
            .row_stride = PL_ALIGN2(width * sizeof(uint16_t),
                                    gpu->limits.align_tex_xfer_pitch),
        };
    }

    pl_fmt fmt = pl_plane_find_fmt(gpu, NULL, &data[0]);
    enum pl_fmt_caps caps = PL_FMT_CAP_RENDERABLE | PL_FMT_CAP_HOST_READABLE;
    if (!fmt || (fmt->caps & caps) != caps)
        return;

    printf("pl_ycbcr_tests:\nfmt=%s\n", fmt->name);

    pl_renderer rr = pl_renderer_create(gpu->log, gpu);
    if (!rr)
        return;

    pl_tex src_tex[3] = {0};
    pl_tex dst_tex[3] = {0};
    struct pl_frame img = {
        .num_planes = 3,
        .repr = pl_color_repr_hdtv,
        .color = pl_color_space_bt709,
    };

    struct pl_frame target = {
        .num_planes = 3,
        .repr = pl_color_repr_hdtv,
        .color = pl_color_space_bt709,
    };

    uint8_t *src_buffer[3] = {0};
    uint8_t *dst_buffer = NULL;
    for (int i = 0; i < 3; i++) {
        // Generate some arbitrary data for the buffer
        src_buffer[i] = malloc(data[i].height * data[i].row_stride);
        if (!src_buffer[i])
            goto error;

        data[i].pixels = src_buffer[i];
        for (int y = 0; y < data[i].height; y++) {
            for (int x = 0; x < data[i].width; x++) {
                size_t off = y * data[i].row_stride + x * data[i].pixel_stride;
                uint16_t *pixel = (uint16_t *) &src_buffer[i][off];
                int gx = 200 + 100 * i, gy = 300 + 150 * i;
                *pixel = (gx * x) ^ (gy * y); // whatever
            }
        }

        REQUIRE(pl_upload_plane(gpu, &img.planes[i], &src_tex[i], &data[i]));
    }

    // This co-sites chroma pixels with pixels in the RGB image, meaning we
    // get an exact round-trip when sampling both ways. This makes it useful
    // as a test case, even though it's not common in the real world.
    pl_frame_set_chroma_location(&img, PL_CHROMA_TOP_LEFT);

    for (int i = 0; i < 3; i++) {
        dst_tex[i] = pl_tex_create(gpu, &(struct pl_tex_params) {
            .format = fmt,
            .w = data[i].width,
            .h = data[i].height,
            .renderable = true,
            .host_readable = true,
            .storable = fmt->caps & PL_FMT_CAP_STORABLE,
            .blit_dst = fmt->caps & PL_FMT_CAP_BLITTABLE,
        });

        if (!dst_tex[i])
            goto error;

        target.planes[i] = img.planes[i];
        target.planes[i].texture = dst_tex[i];
    }

    REQUIRE(pl_render_image(rr, &img, &target, &(struct pl_render_params) {
        .num_hooks = 1,
        .hooks = &(const struct pl_hook *){&(struct pl_hook) {
            // Forces chroma merging, to test the chroma merging code
            .stages = PL_HOOK_CHROMA_INPUT,
            .hook = noop_hook,
        }},
    }));
    REQUIRE(pl_renderer_get_errors(rr).errors == PL_RENDER_ERR_NONE);

    size_t buf_size = data[0].height * data[0].row_stride;
    dst_buffer = malloc(buf_size);
    if (!dst_buffer)
        goto error;

    for (int i = 0; i < 3; i++) {
        memset(dst_buffer, 0xAA, buf_size);
        REQUIRE(pl_tex_download(gpu, &(struct pl_tex_transfer_params) {
            .tex = dst_tex[i],
            .ptr = dst_buffer,
            .row_pitch = data[i].row_stride,
        }));

        for (int y = 0; y < data[i].height; y++) {
            for (int x = 0; x < data[i].width; x++) {
                size_t off = y * data[i].row_stride + x * data[i].pixel_stride;
                uint16_t *src_pixel = (uint16_t *) &src_buffer[i][off];
                uint16_t *dst_pixel = (uint16_t *) &dst_buffer[off];
                // Test that the dst_pixel is correctly clamped to the
                // legal signal range (footroom and headroom included)
                const uint16_t min_val = 1 << (depth - 8);
                const uint16_t max_val = (255 << (depth - 8)) - 1;
                uint16_t src_clamped = PL_CLAMP(*src_pixel, min_val, max_val);
                int diff = abs((int) src_clamped - (int) *dst_pixel);
                REQUIRE_CMP(diff, <=, 150, "d"); // a little over 0.2%
            }
        }
    }

error:
    pl_renderer_destroy(&rr);
    free(dst_buffer);
    for (int i = 0; i < 3; i++) {
        free(src_buffer[i]);
        pl_tex_destroy(gpu, &src_tex[i]);
        pl_tex_destroy(gpu, &dst_tex[i]);
    }
}

static void pl_test_export_import(pl_gpu gpu,
                                  enum pl_handle_type handle_type)
{
    printf("pl_test_export_import:\n");
    // Test texture roundtrip

    if (!(gpu->export_caps.tex & handle_type) ||
        !(gpu->import_caps.tex & handle_type))
        goto skip_tex;

    pl_fmt fmt = pl_find_fmt(gpu, PL_FMT_UNORM, 4, 0, 0, PL_FMT_CAP_BLITTABLE);
    if (!fmt || (handle_type == PL_HANDLE_DMA_BUF && !fmt->num_modifiers))
        goto skip_tex;

    printf("- testing texture import/export with fmt %s\n", fmt->name);

    pl_tex export = pl_tex_create(gpu, &(struct pl_tex_params) {
        .w = 32,
        .h = 32,
        .format = fmt,
        .export_handle = handle_type,
    });
    REQUIRE(export);
    REQUIRE_HANDLE(export->shared_mem, handle_type);

    pl_tex import = pl_tex_create(gpu, &(struct pl_tex_params) {
        .w = export->params.w,
        .h = export->params.h,
        .format = fmt,
        .import_handle = handle_type,
        .shared_mem = export->shared_mem,
    });
    REQUIRE(import);

    pl_tex_destroy(gpu, &import);
    pl_tex_destroy(gpu, &export);

skip_tex: ;

    // Test buffer roundtrip

    if (!(gpu->export_caps.buf & handle_type) ||
        !(gpu->import_caps.buf & handle_type))
        return;

    printf("- testing buffer import/export\n");

    pl_buf exp_buf = pl_buf_create(gpu, &(struct pl_buf_params) {
        .size = 32,
        .export_handle = handle_type,
    });
    REQUIRE(exp_buf);
    REQUIRE_HANDLE(exp_buf->shared_mem, handle_type);

    pl_buf imp_buf = pl_buf_create(gpu, &(struct pl_buf_params) {
        .size = 32,
        .import_handle = handle_type,
        .shared_mem = exp_buf->shared_mem,
    });
    REQUIRE(imp_buf);

    pl_buf_destroy(gpu, &imp_buf);
    pl_buf_destroy(gpu, &exp_buf);
}

static void pl_test_host_ptr(pl_gpu gpu)
{
    if (!(gpu->import_caps.buf & PL_HANDLE_HOST_PTR))
        return;

    printf("pl_test_host_ptr:\n");

#ifdef __unix__

    printf("- testing host ptr\n");
    REQUIRE(gpu->limits.max_mapped_size);

    const size_t size = 2 << 20;
    const size_t offset = 2 << 10;
    const size_t slice = 2 << 16;

    uint8_t *data = aligned_alloc(0x1000, size);
    for (int i = 0; i < size; i++)
        data[i] = (uint8_t) i;

    pl_buf buf = pl_buf_create(gpu, &(struct pl_buf_params) {
        .size = slice,
        .import_handle = PL_HANDLE_HOST_PTR,
        .shared_mem = {
            .handle.ptr = data,
            .size = size,
            .offset = offset,
        },
        .host_mapped = true,
    });

    REQUIRE(buf);
    REQUIRE_MEMEQ(data + offset, buf->data, slice);

    pl_buf_destroy(gpu, &buf);
    free(data);

#endif // unix
}

// At 1:1 scale, the renderer drops sub-pixel offsets from the source crop,
// so these must round to the nearest pixel. In particular, float error just
// below a whole pixel must not shift the image by an entire pixel.
static void pl_render_offset_tests(pl_gpu gpu)
{
    pl_fmt fmt = pl_find_named_fmt(gpu, "rgba8");
    if (!fmt || !(fmt->caps & PL_FMT_CAP_RENDERABLE) ||
        !(fmt->caps & PL_FMT_CAP_HOST_READABLE))
        return;

    enum { W = 16, N = 8 };
    uint8_t data[W * 4];
    for (int x = 0; x < W; x++) {
        data[x * 4 + 0] = x * 16;
        data[x * 4 + 1] = 255 - x * 16;
        data[x * 4 + 2] = 0;
        data[x * 4 + 3] = 255;
    }

    pl_tex src = pl_tex_create(gpu, pl_tex_params(
        .w = W, .h = 1, .format = fmt, .sampleable = true, .initial_data = data,
    ));
    pl_tex dst = pl_tex_create(gpu, pl_tex_params(
        .w = N, .h = 1, .format = fmt, .renderable = true, .host_readable = true,
    ));
    REQUIRE(src && dst);
    pl_renderer rr = pl_renderer_create(gpu->log, gpu);

    static const float offsets[] = { 3.99999976f, 4.0f, 3.6f, 4.4f };
    for (int i = 0; i < PL_ARRAY_SIZE(offsets); i++) {
        const float x0 = offsets[i];
        printf("- testing source crop offset %.8f at 1:1 scale\n", x0);
        struct pl_frame image = {
            .num_planes = 1,
            .planes[0]  = { .texture = src, .components = 4,
                            .component_mapping = {0, 1, 2, 3} },
            .repr       = pl_color_repr_rgb,
            .color      = pl_color_space_srgb,
            .crop       = { x0, 0, x0 + N, 1 },
        };
        struct pl_frame target = image;
        target.planes[0].texture = dst;
        target.crop = (pl_rect2df) { 0, 0, N, 1 };

        REQUIRE(pl_render_image(rr, &image, &target, &pl_render_fast_params));
        uint8_t out[N * 4];
        REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(.tex = dst, .ptr = out)));
        for (int x = 0; x < N; x++) {
            // Expect texel 4 + x, the nearest to every offset tested
            REQUIRE_CMP(abs(out[x * 4 + 0] - data[(4 + x) * 4 + 0]), <=, 1, "d");
            REQUIRE_CMP(abs(out[x * 4 + 1] - data[(4 + x) * 4 + 1]), <=, 1, "d");
        }
    }

    pl_renderer_destroy(&rr);
    pl_tex_destroy(gpu, &src);
    pl_tex_destroy(gpu, &dst);
}

#ifdef PL_HAVE_DOVI

// The composer of ETSI GS CCM 001 V1.1.1 clause 5.4, in its integer arithmetic
struct dovi_ref_curve {
    int num_pivots;
    int pivots[9];
    int mapping_idc[8]; // 0: polynomial, 1: MMR
    int poly_order[8];
    int64_t poly_coef[8][3];
    int mmr_order[8];
    int64_t mmr_constant[8];
    int64_t mmr_coef[8][3][7];
};

struct dovi_ref {
    int bl_bit_depth, el_bit_depth, coef_log2_denom;
    struct dovi_ref_curve curve[3];
    struct {
        int offset;
        int64_t slope, threshold, hdr_in_max;
    } nlq[3];
};

// 5.4.2.2, taking the last piece for a sample at or above the last pivot
static int dovi_ref_piece(const struct dovi_ref_curve *cv, int s)
{
    for (int i = 0; i < cv->num_pivots - 1; i++) {
        if (s < cv->pivots[i + 1])
            return i;
    }
    return cv->num_pivots - 2;
}

static int64_t dovi_ref_clamp(const struct dovi_ref_curve *cv, int s)
{
    return PL_CLAMP(s, cv->pivots[0], cv->pivots[cv->num_pivots - 1]);
}

// 5.4.2.3.2
static int64_t dovi_ref_poly(const struct dovi_ref *ref, int cmp, int piece, int s)
{
    const struct dovi_ref_curve *cv = &ref->curve[cmp];
    const int64_t sc = dovi_ref_clamp(cv, s);
    int64_t ss = 1, vv = 0;
    int shift = 20;
    for (int i = 0; i <= cv->poly_order[piece]; i++) {
        vv += cv->poly_coef[piece][i] * (ss << shift);
        ss *= sc;
        shift -= ref->bl_bit_depth;
    }
    vv = PL_MAX(vv, 0);
    return PL_MIN(vv >> (4 + ref->coef_log2_denom), 0xffff);
}

// 5.4.2.3.3, with the luma of the sample itself as the down-sampled luma
static int64_t dovi_ref_mmr(const struct dovi_ref *ref, int cmp, int piece,
                            const int sample[3])
{
    const struct dovi_ref_curve *cv = &ref->curve[cmp];
    const int n = ref->bl_bit_depth;
    int64_t s[3];
    for (int c = 0; c < 3; c++)
        s[c] = dovi_ref_clamp(&ref->curve[c], sample[c]);

    int64_t tt[22];
    tt[0] = 1 << 20;
    tt[1] = s[0] << (20 - n);
    tt[2] = s[1] << (20 - n);
    tt[3] = s[2] << (20 - n);
    tt[4] = (s[0] * s[1]) << (20 - 2 * n);
    tt[5] = (s[0] * s[2]) << (20 - 2 * n);
    tt[6] = (s[1] * s[2]) << (20 - 2 * n);
    tt[7] = (tt[4] * tt[3]) >> 20;
    tt[8] = (s[0] * s[0]) << (20 - 2 * n);
    tt[9] = (s[1] * s[1]) << (20 - 2 * n);
    tt[10] = (s[2] * s[2]) << (20 - 2 * n);
    tt[11] = (tt[4] * tt[4]) >> 20;
    tt[12] = (tt[5] * tt[5]) >> 20;
    tt[13] = (tt[6] * tt[6]) >> 20;
    tt[14] = (tt[7] * tt[7]) >> 20;
    tt[15] = (tt[1] * tt[8]) >> 20;
    tt[16] = (tt[2] * tt[9]) >> 20;
    tt[17] = (tt[3] * tt[10]) >> 20;
    tt[18] = (tt[4] * tt[11]) >> 20;
    tt[19] = (tt[5] * tt[12]) >> 20;
    tt[20] = (tt[6] * tt[13]) >> 20;
    tt[21] = (tt[7] * tt[14]) >> 20;

    int64_t rr = cv->mmr_constant[piece] * tt[0];
    int cnt = 1;
    for (int i = 0; i < cv->mmr_order[piece]; i++) {
        for (int j = 0; j < 7; j++)
            rr += cv->mmr_coef[piece][i][j] * tt[cnt++];
    }
    rr = PL_MAX(rr, 0);
    return PL_MIN(rr >> (4 + ref->coef_log2_denom), 0xffff);
}

// 5.4.3.2
static int64_t dovi_ref_nlq(const struct dovi_ref *ref, int cmp, int e)
{
    const int64_t T = ref->nlq[cmp].threshold, S = ref->nlq[cmp].slope,
                  R = ref->nlq[cmp].hdr_in_max;
    const int eld = ref->el_bit_depth;
    int64_t rr = e - ref->nlq[cmp].offset;
    if (rr == 0)
        return 0;

    const int64_t sign = rr < 0 ? -1 : 1;
    rr = (2 * rr - sign) * (1 << (10 - eld));
    int64_t dq = rr * S + (T << (10 - eld + 1)) * sign;
    const int64_t RR = R << (10 - eld + 1);
    dq = PL_CLAMP(dq, -RR, RR);

    // arithmetic shift, rounding towards minus infinity
    const int64_t div = (int64_t) 1 << (ref->coef_log2_denom - 5 - eld);
    int64_t r = dq / div;
    if (dq % div && dq < 0)
        r--;
    return r;
}

// The composed signal h of 5.4.3.3 of component `cmp`, before its rounding to
// hdr_bit_depth, as a fraction of 2^16. At an interior pivot the float
// rounding of the sample may select either piece, so both are returned.
static int dovi_ref_compose(const struct dovi_ref *ref, int cmp, const int bl[3],
                            int el, double out[2], bool *mmr)
{
    const struct dovi_ref_curve *cv = &ref->curve[cmp];
    const int piece = dovi_ref_piece(cv, bl[cmp]);
    const int64_t r = dovi_ref_nlq(ref, cmp, el);
    int num = 0;
    *mmr = false;
    for (int p = piece; p >= PL_MAX(piece - 1, 0); p--) {
        if (p < piece && bl[cmp] != cv->pivots[piece])
            break;
        int64_t v = cv->mapping_idc[p] ? dovi_ref_mmr(ref, cmp, p, bl)
                                       : dovi_ref_poly(ref, cmp, p, bl[cmp]);
        *mmr |= cv->mapping_idc[p] == 1;
        out[num++] = PL_CLAMP((v + r) / 65536.0, 0.0, 1.0);
    }
    return num;
}

// SMPTE ST 2084, relative to 10000 cd/m^2
static double dovi_pq_eotf(double x)
{
    const double m1 = 2610.0 / 16384, m2 = 2523.0 / 32, c1 = 3424.0 / 4096,
                 c2 = 2413.0 / 128, c3 = 2392.0 / 128;
    const double y = pow(PL_CLAMP(x, 0.0, 1.0), 1.0 / m2);
    return pow(fmax(y - c1, 0.0) / (c2 - c3 * y), 1.0 / m1);
}

static double dovi_pq_oetf(double lin)
{
    const double m1 = 2610.0 / 16384, m2 = 2523.0 / 32, c1 = 3424.0 / 4096,
                 c2 = 2413.0 / 128, c3 = 2392.0 / 128;
    const double y = pow(fmax(lin, 0.0), m1);
    return pow((c1 + c2 * y) / (1.0 + c3 * y), m2);
}

// The decoding of the composed signal by pl_shader_decode_color: the PQ EOTF,
// the matrix `mat` and the PQ OETF
static void dovi_ref_decode(const pl_matrix3x3 *mat, const double h[3], double out[3])
{
    double lin[3];
    for (int c = 0; c < 3; c++)
        lin[c] = dovi_pq_eotf(h[c]);
    for (int c = 0; c < 3; c++) {
        double sum = 0.0;
        for (int k = 0; k < 3; k++)
            sum += mat->m[c][k] * lin[k];
        out[c] = dovi_pq_oetf(sum);
    }
}

#define Q23(x) ((int64_t) llround((x) * (double) (1 << 23)))

// Mappings of all kinds, with pivots inside the code range and a residual
// bound that bites often (luma), at the largest codes only (Cr) or never (Cb),
// given for 10-bit codes and shifted down for 8-bit ones
static void dovi_test_ref(int depth, struct dovi_ref *ref)
{
    const int sh = 10 - depth;
    *ref = (struct dovi_ref) {
        .bl_bit_depth = depth,
        .el_bit_depth = depth,
        .coef_log2_denom = 23,
        .curve = {
            {
                .num_pivots = 5,
                .pivots = {64 >> sh, 128 >> sh, 300 >> sh, 700 >> sh, 940 >> sh},
                .mapping_idc = {0, 0, 0, 0},
                .poly_order = {1, 2, 2, 1},
                .poly_coef = {
                    {Q23(0.02), Q23(0.9), 0},
                    {Q23(-0.05), Q23(1.6), Q23(-1.2)},
                    {Q23(0.157), Q23(0.636), Q23(-0.113)},
                    {Q23(-0.3), Q23(1.5), 0},
                },
            }, {
                .num_pivots = 3,
                .pivots = {0, 512 >> sh, 1023 >> sh},
                .mapping_idc = {1, 1},
                .mmr_order = {2, 3},
                .mmr_constant = {Q23(0.3), Q23(0.2)},
                .mmr_coef = {
                    {
                        {Q23(0.35), Q23(0.6), Q23(0.08), Q23(-0.45), Q23(-0.2), Q23(-0.3), Q23(0.25)},
                        {Q23(-0.12), Q23(-0.4), Q23(-0.05), Q23(0.3), Q23(0.2), Q23(0.15), Q23(-0.3)},
                    }, {
                        {Q23(0.3), Q23(0.5), Q23(0.2), Q23(-0.3), Q23(-0.25), Q23(0.1), Q23(0.15)},
                        {Q23(-0.1), Q23(-0.2), Q23(-0.15), Q23(0.25), Q23(0.2), Q23(-0.05), Q23(-0.1)},
                        {Q23(0.12), Q23(0.08), Q23(0.1), Q23(-0.15), Q23(-0.1), Q23(0.05), Q23(0.2)},
                    },
                },
            }, {
                .num_pivots = 3,
                .pivots = {0, 400 >> sh, 1023 >> sh},
                .mapping_idc = {0, 1},
                .poly_order = {2},
                .poly_coef = {{Q23(0.5), Q23(0.3), Q23(-0.2)}},
                .mmr_order = {0, 1},
                .mmr_constant = {0, Q23(0.1)},
                .mmr_coef = {
                    {{0}},
                    {{Q23(0.2), Q23(0.45), Q23(0.35), Q23(-0.15), Q23(0.1), Q23(-0.3), Q23(0.5)}},
                },
            },
        },
        .nlq = {
            {.offset = 512 >> sh, .slope = 1 << 15, .threshold = 1 << 13, .hdr_in_max = 1 << 17},
            {.offset = 512 >> sh, .slope = 3 << 13, .threshold = 1 << 12, .hdr_in_max = 1 << 19},
            {.offset = 512 >> sh, .slope = 5 << 12, .threshold = 0,       .hdr_in_max = 1 << 16},
        },
    };
}

// The same metadata as pl_map_dovi_metadata() makes of an RPU, with the
// inverse of the LMS to RGB matrix of pl_shader_decode_color as the RGB to
// LMS matrix, so that the decoding returns the composed signal up to the
// float rounding of their product, which is returned in `mat`
static void dovi_test_metadata(const struct dovi_ref *ref,
                               struct pl_dovi_metadata *out, pl_matrix3x3 *mat)
{
    const double coef = ldexp(1.0, -ref->coef_log2_denom);
    const double pivot = ldexp(1.0, -ref->bl_bit_depth);

    const pl_matrix3x3 lms2rgb = {{
        { 3.06441879, -2.16597676,  0.10155818},
        {-0.65612108,  1.78554118, -0.12943749},
        { 0.01736321, -0.04725154,  1.03004253},
    }};
    pl_matrix3x3 rgb2lms = lms2rgb;
    pl_matrix3x3_invert(&rgb2lms);
    *mat = lms2rgb;
    pl_matrix3x3_mul(mat, &rgb2lms);

    *out = (struct pl_dovi_metadata) {
        .nonlinear  = pl_matrix3x3_identity,
        .linear     = rgb2lms,
        .nlq_active = true,
    };

    for (int c = 0; c < 3; c++) {
        const struct dovi_ref_curve *cv = &ref->curve[c];
        struct pl_reshape_data *comp = &out->comp[c];
        comp->num_pivots = cv->num_pivots;
        for (int i = 0; i < cv->num_pivots; i++)
            comp->pivots[i] = pivot * cv->pivots[i];
        for (int i = 0; i < cv->num_pivots - 1; i++) {
            comp->method[i] = cv->mapping_idc[i];
            if (cv->mapping_idc[i] == 0) {
                for (int k = 0; k <= cv->poly_order[i]; k++)
                    comp->poly_coeffs[i][k] = coef * cv->poly_coef[i][k];
            } else {
                comp->mmr_order[i] = cv->mmr_order[i];
                comp->mmr_constant[i] = coef * cv->mmr_constant[i];
                for (int j = 0; j < cv->mmr_order[i]; j++) {
                    for (int k = 0; k < 7; k++)
                        comp->mmr_coeffs[i][j][k] = coef * cv->mmr_coef[i][j][k];
                }
            }
        }

        out->nlq[c].offset = ref->nlq[c].offset;
        out->nlq[c].deadzone_slope = coef * ref->nlq[c].slope;
        out->nlq[c].deadzone_threshold = coef * ref->nlq[c].threshold;
        out->nlq[c].hdr_in_max = coef * ref->nlq[c].hdr_in_max;
    }
}

// Every luma code, with chroma and enhancement layer codes that differ per
// sample, the latter on both sides of the offset and at it
static void dovi_test_codes(int x, int y, int depth, int offset, int bl[3], int el[3])
{
    const int max = (1 << depth) - 1;
    bl[0] = x;
    bl[1] = (x * 7 + y * 131) & max;
    bl[2] = (x * 13 + y * 257 + 100) & max;
    el[0] = PL_CLAMP(offset + (x + y) % 61 - 30, 0, max);
    el[1] = PL_CLAMP(offset + (x * 3 + y) % 23 - 11, 0, max);
    el[2] = PL_CLAMP(offset + (x * 5 + y * 7) % 9 - 4, 0, max);
}

static void pl_dovi_tests(pl_gpu gpu)
{
    pl_fmt fbo_fmt = pl_find_fmt(gpu, PL_FMT_FLOAT, 4, 32, 32,
                                 PL_FMT_CAP_RENDERABLE | PL_FMT_CAP_HOST_READABLE);
    if (!fbo_fmt)
        return;
    pl_fmt f32_fmt = pl_find_fmt(gpu, PL_FMT_FLOAT, 4, 32, 32,
                                 PL_FMT_CAP_SAMPLEABLE);
    printf("pl_dovi_tests:\n");

    pl_dispatch dp = pl_dispatch_create(gpu->log, gpu);
    REQUIRE(dp);

    static const struct {
        int depth, tex_bits, shift;
        enum pl_color_levels levels;
        bool normalized; // by the renderer, into a float texture
    } variants[] = {
        {10, 16, 0, PL_COLOR_LEVELS_FULL},
        {10, 16, 0, PL_COLOR_LEVELS_LIMITED},
        {10, 16, 6, PL_COLOR_LEVELS_LIMITED},
        { 8,  8, 0, PL_COLOR_LEVELS_FULL},
        { 8, 16, 0, PL_COLOR_LEVELS_LIMITED},
        { 8, 16, 8, PL_COLOR_LEVELS_FULL},
        {10, 16, 0, PL_COLOR_LEVELS_FULL,    true},
        {10, 16, 6, PL_COLOR_LEVELS_LIMITED, true},
        { 8, 16, 8, PL_COLOR_LEVELS_FULL,    true},
    };

    for (int i = 0; i < PL_ARRAY_SIZE(variants); i++) {
        const int depth = variants[i].depth, tex_bits = variants[i].tex_bits,
                  shift = variants[i].shift;
        const bool normalized = variants[i].normalized;
        pl_fmt tex_fmt = pl_find_fmt(gpu, PL_FMT_UNORM, 4, tex_bits, tex_bits,
                                     PL_FMT_CAP_SAMPLEABLE);
        if (!tex_fmt || (normalized && !f32_fmt)) {
            printf("- no %d-bit texture format, skipping\n",
                   tex_fmt ? 32 : tex_bits);
            continue;
        }

        struct dovi_ref ref;
        dovi_test_ref(depth, &ref);
        struct pl_dovi_metadata meta;
        pl_matrix3x3 mat;
        dovi_test_metadata(&ref, &meta, &mat);

        struct pl_color_repr repr = {
            .sys    = PL_COLOR_SYSTEM_DOLBYVISION,
            .levels = variants[i].levels,
            .dovi   = &meta,
            .bits   = {
                .sample_depth = tex_bits,
                .color_depth  = depth,
                .bit_shift    = shift,
            },
        };

        // The renderer normalizes every plane before the decode
        const float norm = normalized ? pl_color_repr_normalize(&repr) : 1.0f;
        if (normalized)
            REQUIRE_CMP(repr.bits.sample_depth, ==, depth, "d");

        const int W = 1 << depth, H = 8;
        uint16_t *bl_data = malloc(W * H * 4 * sizeof(uint16_t));
        uint16_t *el_data = malloc(W * H * 4 * sizeof(uint16_t));
        float *bl_float = malloc(W * H * 4 * sizeof(float));
        uint8_t *bl_data8 = (uint8_t *) bl_data, *el_data8 = (uint8_t *) el_data;
        REQUIRE(bl_data && el_data && bl_float);
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int bl[3], el[3];
                dovi_test_codes(x, y, depth, ref.nlq[0].offset, bl, el);
                for (int c = 0; c < 4; c++) {
                    const int bv = c < 3 ? bl[c] << shift : 0,
                              ev = c < 3 ? el[c] << shift : 0;
                    if (tex_bits == 16) {
                        bl_data[(y * W + x) * 4 + c] = bv;
                        el_data[(y * W + x) * 4 + c] = ev;
                    } else {
                        bl_data8[(y * W + x) * 4 + c] = bv;
                        el_data8[(y * W + x) * 4 + c] = ev;
                    }
                    bl_float[(y * W + x) * 4 + c] = norm * bv /
                                                    (float) ((1 << tex_bits) - 1);
                }
            }
        }

        pl_tex bl_tex = pl_tex_create(gpu, pl_tex_params(
            .format = normalized ? f32_fmt : tex_fmt,
            .w = W,
            .h = H,
            .sampleable = true,
            .initial_data = normalized ? (void *) bl_float : (void *) bl_data,
        ));
        pl_tex el_tex = pl_tex_create(gpu, pl_tex_params(
            .format = tex_fmt,
            .w = W,
            .h = H,
            .sampleable = true,
            .initial_data = el_data,
        ));
        pl_tex fbo = pl_tex_create(gpu, pl_tex_params(
            .format = fbo_fmt,
            .w = W,
            .h = H,
            .renderable = true,
            .host_readable = true,
        ));
        REQUIRE(bl_tex && el_tex && fbo);

        // The enhancement layer sub-shader returns the EL codes
        pl_shader el_sh = pl_dispatch_begin_ex(dp, true);
        pl_shader_sample_nearest(el_sh, pl_sample_src(
            .tex   = el_tex,
            .scale = ldexpf((1 << tex_bits) - 1, -shift),
        ));

        pl_shader sh = pl_dispatch_begin_ex(dp, true);
        pl_shader_sample_nearest(sh, pl_sample_src( .tex = bl_tex ));
        pl_shader_decode_color_ex(sh, pl_color_decode_args(
            .repr              = &repr,
            .enhancement_layer = el_sh,
        ));
        pl_dispatch_abort(dp, &el_sh);
        REQUIRE(pl_dispatch_finish(dp, pl_dispatch_params(
            .shader = &sh,
            .target = fbo,
        )));

        float *out = malloc(W * H * 4 * sizeof(float));
        REQUIRE(out);
        REQUIRE(pl_tex_download(gpu, pl_tex_transfer_params(
            .tex = fbo,
            .ptr = out,
        )));

        // The specification truncates the mapped signal and the residual to
        // integers of 2^16 and the MMR terms to 2^20, the shader does not
        int bad = 0;
        double max_err = 0.0;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int bl[3], el[3], num[3];
                double h[3][2];
                bool mmr[3];
                dovi_test_codes(x, y, depth, ref.nlq[0].offset, bl, el);
                for (int c = 0; c < 3; c++)
                    num[c] = dovi_ref_compose(&ref, c, bl, el[c], h[c], &mmr[c]);

                // The closest of the decodings of all candidate signals
                double err[3] = { INFINITY, INFINITY, INFINITY };
                for (int k = 0; k < num[0] * num[1] * num[2]; k++) {
                    const double hk[3] = {
                        h[0][k % num[0]],
                        h[1][k / num[0] % num[1]],
                        h[2][k / num[0] / num[1]],
                    };
                    double expect[3];
                    dovi_ref_decode(&mat, hk, expect);
                    for (int c = 0; c < 3; c++) {
                        const float got = out[(y * W + x) * 4 + c];
                        err[c] = fmin(err[c], fabs(got - expect[c]));
                    }
                }

                for (int c = 0; c < 3; c++) {
                    const double tol = mmr[c] ? 1e-4 : 5e-5;
                    if (!(err[c] <= tol)) {
                        if (bad < 5) {
                            printf("  sample (%d, %d) component %d: codes %d %d %d, "
                                   "EL %d: got %f, expected %f\n", x, y, c,
                                   bl[0], bl[1], bl[2], el[c],
                                   out[(y * W + x) * 4 + c], h[c][0]);
                        }
                        bad++;
                    }
                    max_err = fmax(max_err, err[c]);
                }
            }
        }

        printf("- %d-bit codes in %d-bit textures, shift %d, %s range%s: "
               "max error %.2g\n", depth, tex_bits, shift,
               variants[i].levels == PL_COLOR_LEVELS_FULL ? "full" : "limited",
               normalized ? ", normalized" : "", max_err);
        REQUIRE_CMP(bad, ==, 0, "d");

        free(out);
        free(bl_data);
        free(el_data);
        free(bl_float);
        pl_tex_destroy(gpu, &bl_tex);
        pl_tex_destroy(gpu, &el_tex);
        pl_tex_destroy(gpu, &fbo);
    }

    pl_dispatch_destroy(&dp);
}

#endif // PL_HAVE_DOVI

void gpu_shader_tests(pl_gpu gpu)
{
    if (getenv("PL_TEST_PEAK_ANALYSIS_CROP_ONLY")) {
        pl_shader_tests(gpu);
        REQUIRE(!pl_gpu_is_failed(gpu));
        return;
    }

    pl_buffer_tests(gpu);
    pl_texture_tests(gpu);
    pl_planar_tests(gpu);
    pl_shader_tests(gpu);
#ifdef PL_HAVE_DOVI
    pl_dovi_tests(gpu);
#endif
    pl_scaler_tests(gpu);
    pl_render_tests(gpu);
    pl_render_offset_tests(gpu);
    pl_render_bits_tests(gpu);
    pl_render_deband_tests(gpu);
    pl_ycbcr_tests(gpu);

    REQUIRE(!pl_gpu_is_failed(gpu));
}

void gpu_interop_tests(pl_gpu gpu)
{
    pl_test_export_import(gpu, PL_HANDLE_DMA_BUF);
    pl_test_host_ptr(gpu);

    REQUIRE(!pl_gpu_is_failed(gpu));
}
